=== LaDo-AI – Giải ngân vốn đầu tư công Lâm Đồng ===

Plugin WordPress: bảng điều khiển (dashboard) trực quan hóa số liệu giải ngân vốn
đầu tư công tỉnh Lâm Đồng, kèm trợ lý ảo LaDo-AI (Claude API) và nút tải báo cáo
tuần/tháng.

== CÀI ĐẶT ==
1. Nén thư mục "lado-ai" thành lado-ai.zip (hoặc dùng file zip đính kèm).
2. WordPress > Plugins > Add New > Upload Plugin > chọn lado-ai.zip > Install > Activate.
   (Hoặc giải nén vào wp-content/plugins/ rồi kích hoạt.)
3. Vào menu "LaDo-AI" ở thanh quản trị bên trái để cấu hình.

== CẤU HÌNH (trang LaDo-AI) ==
1) Kết nối Claude API:
   - API key: dán khóa API của Anthropic (lưu phía máy chủ, không lộ ra trình duyệt).
   - Mô hình Claude: NHẬP THỦ CÔNG, ví dụ claude-opus-4-8 / claude-sonnet-4-6 /
     claude-haiku-4-5-20251001…
   - max_tokens, temperature, giới hạn số câu hỏi / 10 phút / IP.
2) Trợ lý ảo: đổi tên (mặc định LaDo-AI) và chỉnh "tính cách / chỉ dẫn".
3) Cơ sở dữ liệu ngữ cảnh: tải lên .docx / .xlsx / .csv / .txt — hệ thống tự trích
   xuất văn bản làm ngữ cảnh để LaDo-AI trả lời. Có thể nối thêm hoặc xóa.
4) File báo cáo: chọn từ Thư viện file 02 báo cáo .docx (TUẦN và THÁNG) cho nút tải.
   => Cập nhật định kỳ: chỉ cần thay file ở mục này, người dùng luôn tải bản mới nhất.
5) Số liệu biểu đồ (JSON): cập nhật số liệu hiển thị trên dashboard (đơn vị: triệu đồng).

== HIỂN THỊ RA TRANG ==
- Tạo một Trang (Page) mới, dán shortcode:  [lado_ai_dashboard]
- Nên dùng mẫu trang full-width. Bấm "⛶ Toàn màn hình" để hiển thị dạng phần mềm.

== TÍNH NĂNG ==
- KPI + biểu đồ (Chart.js): vòng tỷ lệ toàn tỉnh, cột theo nhóm chủ đầu tư,
  so với kế hoạch giao (TTg/HĐND/UBND), cơ cấu giải ngân, bảng xếp hạng tốt/kém.
- Trợ lý ảo LaDo-AI: hỏi đáp về phân bổ, giải ngân; trả lời dựa trên số liệu +
  file ngữ cảnh; gọi Claude API phía máy chủ.
- Nút tải báo cáo: hiệu ứng "LaDo-AI đang tổng hợp dữ liệu & xuất .docx" rồi tải
  file do quản trị viên đính kèm.
- Responsive: đẹp trên điện thoại và máy tính; chế độ toàn màn hình.

== BẢO MẬT ==
- API key không bao giờ gửi xuống trình duyệt (chỉ dùng ở máy chủ qua admin-ajax).
- Chat có giới hạn tần suất theo IP (cấu hình ở mục 1).
- Mọi thao tác dùng nonce; trang cấu hình yêu cầu quyền manage_options.

Phiên bản 1.0.0
