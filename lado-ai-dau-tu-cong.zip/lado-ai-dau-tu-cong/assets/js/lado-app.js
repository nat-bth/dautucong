(function () {
  'use strict';
  if (typeof LADO_AI === 'undefined') return;
  var D = LADO_AI.data || {};
  var NAME = LADO_AI.name || 'LaDo-AI';
  var app = document.getElementById('lado-app');
  if (!app) return;

  /* ---------- helpers ---------- */
  function vn(n) { try { return Math.round(n).toLocaleString('vi-VN'); } catch (e) { return n; } }
  function pc(n) { return (Number(n).toFixed(2)).replace('.', ',') + '%'; }
  function tyd(n) { return (n / 1000).toLocaleString('vi-VN', { maximumFractionDigits: 0 }); }
  function el(html) { var d = document.createElement('div'); d.innerHTML = html.trim(); return d.firstChild; }
  function esc(s){return (s==null?'':String(s)).replace(/[&<>"]/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c];});}

  var tong = D.tong || {}, khoi = D.khoi || [], giao = D.kehoach_giao || [];
  var color = { navy:'#0f2c52', blue:'#2563eb', sky:'#38bdf8', green:'#16a34a', amber:'#d97706', red:'#dc2626', line:'#e2e8f0' };

  /* ---------- build shell ---------- */
  app.classList.remove('lado-loading');
  app.innerHTML = ''
  + '<div class="lado-top">'
  +   '<div class="lado-brand"><div class="lado-logo">📊</div>'
  +     '<div><h1>Hệ thống dữ liệu giải ngân vốn đầu tư công tỉnh ' + esc(D.tinh || 'Lâm Đồng') + '</h1>'
  +     '<p>Phát triển bới NAT ' + esc(NAME) + '</p></div></div>'
  +   '<div class="lado-spacer"></div>'
  +   '<div class="lado-asof">🗓️ Lũy kế đến ' + esc(D.as_of || '') + '</div>'
  + '</div>'
  + '<div class="lado-body">'
  +   '<div class="lado-kpis"></div>'
  +   '<div class="card"><h3>📥 Tải báo cáo</h3><p class="hint">Bấm để ' + esc(NAME) + ' tổng hợp và xuất báo cáo định kỳ (.docx).</p>'
  +     '<div class="lado-actions">'
  +       '<button class="dlbtn week" data-type="week"><span class="ic">📄</span><span>Tải báo cáo TUẦN<small>Bản cập nhật mới nhất</small></span></button>'
  +       '<button class="dlbtn month" data-type="month"><span class="ic">📑</span><span>Tải báo cáo THÁNG<small>Tổng hợp theo tháng</small></span></button>'
  +     '</div></div>'
  +   '<div class="lado-grid">'
  +     '<div class="card gauge"><h3>🎯 Tỷ lệ giải ngân toàn tỉnh</h3><p class="hint">Tổng kế hoạch ' + vn(tong.kh) + ' • đã giải ngân ' + vn(tong.gn) + ' (triệu đồng)</p>'
  +       '<div class="chart-wrap"><canvas id="c-gauge"></canvas><div class="gauge-center"><div class="pct">' + pc(tong.tl || 0) + '</div><div class="cap">lũy kế giải ngân</div></div></div></div>'
  +     '<div class="card"><h3>🏗️ Theo nhóm chủ đầu tư</h3><p class="hint">Kế hoạch vốn và đã giải ngân (tỷ đồng)</p><div class="chart-wrap"><canvas id="c-khoi"></canvas></div></div>'
  +   '</div>'
  +   '<div class="lado-grid">'
  +     '<div class="card"><h3>📐 So với kế hoạch giao (vốn 2026)</h3><p class="hint">Tỷ lệ giải ngân theo từng mức kế hoạch được giao</p><div class="chart-wrap"><canvas id="c-giao"></canvas></div></div>'
  +     '<div class="card"><h3>🧭 Cơ cấu theo nhóm</h3><p class="hint">Tỷ trọng giá trị đã giải ngân</p><div class="chart-wrap"><canvas id="c-pie"></canvas></div></div>'
  +   '</div>'
  +   '<div class="two-col">'
  +     '<div class="card"><h3>🥇 Ban QLDA giải ngân tốt nhất</h3><div class="rank" id="r-topban"></div></div>'
  +     '<div class="card"><h3>🐢 Ban QLDA giải ngân thấp nhất</h3><div class="rank bad" id="r-botban"></div></div>'
  +   '</div>'
  +   '<div class="two-col">'
  +     '<div class="card"><h3>🏆 Xã/phường tiêu biểu</h3><div class="rank" id="r-topxa"></div></div>'
  +     '<div class="card"><h3>🏢 Sở, ngành, đơn vị tiêu biểu</h3><div class="rank" id="r-topso"></div></div>'
  +   '</div>'
  +   '<div class="card lado-detail"><h3>📋 Bảng kết quả giải ngân chi tiết (toàn bộ đơn vị)</h3>'
  +     '<p class="hint">Số liệu lũy kế theo từng chủ đầu tư (triệu đồng). Chọn nhóm và gõ để lọc theo tên.</p>'
  +     '<div class="ld-tabs">'
  +       '<button class="ld-tab on" data-g="ban">Ban QLDA (<span id="cnt-ban">0</span>)</button>'
  +       '<button class="ld-tab" data-g="so">Sở, ngành (<span id="cnt-so">0</span>)</button>'
  +       '<button class="ld-tab" data-g="xa">Xã, phường (<span id="cnt-xa">0</span>)</button>'
  +     '</div>'
  +     '<input type="search" class="ld-search" id="ld-search" placeholder="🔍 Tìm theo tên đơn vị…">'
  +     '<div class="ld-table-wrap" id="ld-table"></div>'
  +   '</div>'
  +   '<div class="card"><h3>🚫 Đơn vị chưa giải ngân (0%)</h3><p class="hint">Danh sách đầy đủ các đơn vị/địa phương được giao vốn nhưng đến nay chưa phát sinh giải ngân.</p><div id="zero-box"></div></div>'
  + '</div>'
  /* download overlay */
  + '<div class="lado-ov" id="lado-ov"><div class="ov-box">'
  +   '<div class="ov-orb"></div>'
  +   '<h4><span class="who">' + esc(NAME) + '</span> đang tổng hợp dữ liệu</h4>'
  +   '<div id="ov-sub" style="font-size:13px;opacity:.85">Vui lòng đợi trong giây lát…</div>'
  +   '<div class="ov-steps">'
  +     '<div class="ov-step" data-s="0"><span class="dot">1</span> Kết nối cơ sở dữ liệu giải ngân</div>'
  +     '<div class="ov-step" data-s="1"><span class="dot">2</span> Tổng hợp số liệu Kho bạc &amp; Sở Tài chính</div>'
  +     '<div class="ov-step" data-s="2"><span class="dot">3</span> Dựng biểu đồ &amp; bảng phân tích</div>'
  +     '<div class="ov-step" data-s="3"><span class="dot">4</span> Xuất báo cáo định dạng .docx</div>'
  +   '</div>'
  +   '<div class="ov-prog"><i id="ov-prog"></i></div>'
  +   '<button class="ov-cancel" id="ov-cancel">Hủy</button>'
  + '</div></div>'
  /* chat */
  + '<button class="lado-fab" id="lado-fab"><span class="av">🤖</span> Hỏi ' + esc(NAME) + '</button>'
  + '<div class="lado-chat" id="lado-chat">'
  +   '<div class="chat-head"><div class="av">🤖</div><div><b>' + esc(NAME) + '</b><span>Trợ lý ảo giải ngân vốn ĐTC Lâm Đồng</span></div><button class="x" id="chat-x">✕</button></div>'
  +   '<div class="chat-body" id="chat-body"></div>'
  +   '<div class="chat-foot"><textarea id="chat-in" rows="1" placeholder="Nhập câu hỏi về phân bổ, giải ngân…"></textarea><button id="chat-send">➤</button></div>'
  +   '<div class="foot-note">' + esc(NAME) + ' có thể trả lời chưa đầy đủ. Vui lòng đối chiếu văn bản chính thức.</div>'
  + '</div>';

  /* ---------- KPIs ---------- */
  var kpis = app.querySelector('.lado-kpis');
  var nguon = D.nguon || [];
  var v26 = (nguon[0] && nguon[0].gn) || 0, vkd = (nguon[1] && nguon[1].gn) || 0;
  kpis.appendChild(el('<div class="kpi n"><div class="lab">Tổng kế hoạch vốn</div><div class="val">' + tyd(tong.kh) + '<span style="font-size:14px"> tỷ</span></div><div class="sub">gồm vốn kéo dài 2025</div></div>'));
  kpis.appendChild(el('<div class="kpi"><div class="lab">Lũy kế giải ngân</div><div class="val">' + tyd(tong.gn) + '<span style="font-size:14px"> tỷ</span></div><div class="sub"><span class="up">▲ +' + vn(tong.tang) + '</span> so tháng trước</div></div>'));
  kpis.appendChild(el('<div class="kpi g"><div class="lab">Tỷ lệ giải ngân</div><div class="val">' + pc(tong.tl || 0) + '</div><div class="sub">+' + pc(tong.tang_pc || 0).replace('%','') + '% so tháng trước</div></div>'));
  kpis.appendChild(el('<div class="kpi a"><div class="lab">Đơn vị chưa giải ngân</div><div class="val">' + ((D.zero && D.zero.tong) || 0) + '</div><div class="sub">' + ((D.zero && D.zero.so) || 0) + ' sở/ngành • ' + ((D.zero && D.zero.xa) || 0) + ' xã/phường</div></div>'));

  /* ---------- charts ---------- */
  if (window.Chart) {
    Chart.defaults.font.family = "'Inter','Segoe UI',sans-serif";
    Chart.defaults.font.size = 12.5;

    var g = (tong.tl || 0);
    new Chart(document.getElementById('c-gauge'), {
      type: 'doughnut',
      data: { datasets: [{ data: [g, 100 - g], backgroundColor: [color.navy, '#e8eef6'], borderWidth: 0 }] },
      options: { cutout: '74%', plugins: { legend: { display: false }, tooltip: { enabled: false } }, animation: { animateRotate: true } }
    });

    new Chart(document.getElementById('c-khoi'), {
      type: 'bar',
      data: {
        labels: khoi.map(function (k) { return k.ten.replace(/\s*\(.*\)/, ''); }),
        datasets: [
          { label: 'Kế hoạch', data: khoi.map(function (k) { return k.kh / 1000; }), backgroundColor: '#cdddf0', borderRadius: 6 },
          { label: 'Đã giải ngân', data: khoi.map(function (k) { return k.gn / 1000; }), backgroundColor: color.navy, borderRadius: 6 }
        ]
      },
      options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'bottom' }, tooltip: { callbacks: { label: function (c) { return c.dataset.label + ': ' + vn(c.raw) + ' tỷ'; } } } }, scales: { y: { ticks: { callback: function (v) { return vn(v); } } } } }
    });

    new Chart(document.getElementById('c-giao'), {
      type: 'bar',
      data: { labels: giao.map(function (x) { return x.ten; }), datasets: [{ label: 'Tỷ lệ giải ngân', data: giao.map(function (x) { return x.tl; }), backgroundColor: [color.blue, color.sky, '#6366f1'], borderRadius: 6 }] },
      options: { indexAxis: 'y', responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false }, tooltip: { callbacks: { label: function (c) { return pc(c.raw); } } } }, scales: { x: { ticks: { callback: function (v) { return v + '%'; } }, suggestedMax: 12 } } }
    });

    new Chart(document.getElementById('c-pie'), {
      type: 'doughnut',
      data: { labels: khoi.map(function (k) { return k.ten.replace(/\s*\(.*\)/, ''); }), datasets: [{ data: khoi.map(function (k) { return k.gn; }), backgroundColor: [color.navy, color.blue, color.sky], borderWidth: 2, borderColor: '#fff' }] },
      options: { responsive: true, maintainAspectRatio: false, cutout: '55%', plugins: { legend: { position: 'bottom' }, tooltip: { callbacks: { label: function (c) { return c.label + ': ' + vn(c.raw) + ' tr.đ'; } } } } }
    });
  }

  /* ---------- ranking lists ---------- */
  function fillRank(id, arr, bad) {
    var box = document.getElementById(id); if (!box || !arr) return;
    var max = Math.max.apply(null, arr.map(function (x) { return x.tl; }).concat([1]));
    arr.forEach(function (x) {
      var w = Math.max(4, (x.tl / max) * 100);
      box.appendChild(el('<div class="row"><div class="nm">' + esc(x.ten) + '</div><div class="bar"><i style="width:' + w + '%"></i></div><div class="pc">' + pc(x.tl) + '</div></div>'));
    });
  }
  fillRank('r-topban', D.top_ban); fillRank('r-botban', D.bottom_ban, true);
  fillRank('r-topxa', D.top_xa); fillRank('r-topso', D.top_so);

  /* ---------- full 0% list ---------- */
  (function () {
    var box = document.getElementById('zero-box'); if (!box) return;
    var so = D.zero_list_so || [], xa = D.zero_list_xa || [];
    var tot = (D.zero && D.zero.tong) || (so.length + xa.length);
    var head = '<div class="zero-head"><span class="zero-stat">Tổng: ' + tot + ' đơn vị</span><span class="zero-stat">Sở, ngành: ' + so.length + '</span><span class="zero-stat">Xã, phường: ' + xa.length + '</span></div>';
    function col(title, arr) {
      var h = '<div class="zero-col"><h4>' + title + ' (' + arr.length + ')</h4><div class="zero-list">';
      if (!arr.length) { h += '<div class="zero-item"><span>—</span></div>'; }
      arr.forEach(function (n, idx) { h += '<div class="zero-item"><span class="i">' + (idx + 1) + '</span><span>' + esc(n) + '</span></div>'; });
      return h + '</div></div>';
    }
    box.innerHTML = head + '<div class="zero-grid">' + col('Khối sở, ngành, đơn vị', so) + col('Khối xã, phường, đặc khu', xa) + '</div>';
  })();

  /* ---------- full detail tables (3 nhóm) ---------- */
  (function () {
    var wrap = document.getElementById('ld-table'); if (!wrap) return;
    var groups = {
      ban: { rows: D.all_ban || [], cols: ['kh', 'gn'], head: ['Chủ đầu tư (Ban QLDA)', 'Kế hoạch', 'Giải ngân', 'Tỷ lệ'] },
      so:  { rows: D.all_so || [],  cols: ['gn'],       head: ['Đơn vị', 'Giải ngân', 'Tỷ lệ'] },
      xa:  { rows: D.all_xa || [],  cols: ['kh', 'gn'], head: ['Xã / phường / đặc khu', 'Kế hoạch', 'Giải ngân', 'Tỷ lệ'] }
    };
    var setc = function (id, n) { var e = document.getElementById(id); if (e) e.textContent = n; };
    setc('cnt-ban', groups.ban.rows.length); setc('cnt-so', groups.so.rows.length); setc('cnt-xa', groups.xa.rows.length);
    var cur = 'ban';
    function tlCls(t) { return t >= 20 ? 'g' : (t < 5 ? 'r' : 'a'); }
    function render(g, filter) {
      var info = groups[g], f = (filter || '').toLowerCase().trim();
      var rows = info.rows.filter(function (r) { return !f || (r.ten || '').toLowerCase().indexOf(f) > -1; });
      var h = '<table class="ld-table"><thead><tr><th class="c-tt">#</th><th>' + info.head[0] + '</th>';
      info.cols.forEach(function (c, i) { h += '<th class="num">' + info.head[i + 1] + '</th>'; });
      h += '<th class="num">Tỷ lệ</th></tr></thead><tbody>';
      if (!rows.length) {
        h += '<tr><td colspan="6" style="text-align:center;color:var(--muted);padding:16px">Không tìm thấy đơn vị phù hợp.</td></tr>';
      }
      rows.forEach(function (r, idx) {
        h += '<tr><td class="c-tt">' + (idx + 1) + '</td><td>' + esc(r.ten) + '</td>';
        info.cols.forEach(function (c) { h += '<td class="num">' + (r[c] != null ? vn(r[c]) : '—') + '</td>'; });
        h += '<td class="num"><span class="tl-badge ' + tlCls(r.tl) + '">' + pc(r.tl) + '</span></td></tr>';
      });
      wrap.innerHTML = h + '</tbody></table>';
    }
    app.querySelectorAll('.ld-tab').forEach(function (b) {
      b.addEventListener('click', function () {
        app.querySelectorAll('.ld-tab').forEach(function (x) { x.classList.remove('on'); });
        b.classList.add('on'); cur = b.dataset.g;
        render(cur, document.getElementById('ld-search').value);
        wrap.scrollTop = 0;
      });
    });
    document.getElementById('ld-search').addEventListener('input', function () { render(cur, this.value); });
    render('ban', '');
  })();

  /* ---------- download experience ---------- */
  var ov = document.getElementById('lado-ov'), ovProg = document.getElementById('ov-prog'), ovSub = document.getElementById('ov-sub');
  var dlTimer = null, dlCancelled = false;
  function steps(on){ app.querySelectorAll('.ov-step').forEach(function(s){ var i=+s.dataset.s; s.classList.toggle('on', i===on); s.classList.toggle('done', i<on); }); }
  app.querySelectorAll('.dlbtn').forEach(function (b) {
    b.addEventListener('click', function () { startDownload(b.dataset.type); });
  });
  document.getElementById('ov-cancel').addEventListener('click', function(){ dlCancelled = true; clearTimeout(dlTimer); ov.classList.remove('on'); });

  function startDownload(type) {
    dlCancelled = false;
    ov.classList.add('on'); ovProg.style.width = '0'; ovSub.textContent = 'Vui lòng đợi trong giây lát…';
    var seq = [0, 1, 2, 3], i = 0;
    steps(0); ovProg.style.width = '12%';
    function tick() {
      if (dlCancelled) return;
      steps(seq[i]); ovProg.style.width = (18 + i * 24) + '%';
      i++;
      if (i < seq.length) { dlTimer = setTimeout(tick, 850); }
      else { dlTimer = setTimeout(finish, 850); }
    }
    dlTimer = setTimeout(tick, 500);

    function finish() {
      if (dlCancelled) return;
      var fd = new FormData();
      fd.append('action', 'lado_report'); fd.append('nonce', LADO_AI.nonce); fd.append('type', type);
      fetch(LADO_AI.ajax, { method: 'POST', body: fd }).then(function (r) { return r.json(); }).then(function (res) {
        ovProg.style.width = '100%';
        app.querySelectorAll('.ov-step').forEach(function (s) { s.classList.add('done'); s.classList.remove('on'); });
        if (res && res.success && res.data && res.data.url) {
          ovSub.innerHTML = '✅ Hoàn tất! Đang tải <b>' + esc(res.data.name) + '</b>…';
          var a = document.createElement('a'); a.href = res.data.url; a.download = res.data.name || ''; document.body.appendChild(a); a.click(); a.remove();
          setTimeout(function () { ov.classList.remove('on'); }, 1400);
        } else {
          ovSub.innerHTML = '⚠️ ' + esc((res && res.data && res.data.message) || 'Chưa có file báo cáo.');
          setTimeout(function () { ov.classList.remove('on'); }, 2600);
        }
      }).catch(function () { ovSub.textContent = '⚠️ Lỗi kết nối. Vui lòng thử lại.'; setTimeout(function () { ov.classList.remove('on'); }, 2400); });
    }
  }

  /* ---------- chat ---------- */
  var fab = document.getElementById('lado-fab'), chat = document.getElementById('lado-chat');
  var body = document.getElementById('chat-body'), input = document.getElementById('chat-in'), send = document.getElementById('chat-send');
  var history = [], busy = false, greeted = false;

  fab.addEventListener('click', function () { chat.classList.add('on'); fab.style.display = 'none'; if (!greeted) greet(); input.focus(); });
  document.getElementById('chat-x').addEventListener('click', function () { chat.classList.remove('on'); fab.style.display = 'flex'; });

  function splitRow(s) { s = s.trim().replace(/^\|/, '').replace(/\|$/, ''); return s.split('|').map(function (x) { return x.trim(); }); }
  function inlineMd(t) {
    t = esc(t);
    t = t.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
    t = t.replace(/`([^`]+)`/g, '<code>$1</code>');
    t = t.replace(/(\d[\d.,]*\s?%)/g, '<span class="hl">$1</span>');
    t = t.replace(/\*/g, '');
    return t;
  }
  function mdToHtml(src) {
    var lines = String(src).replace(/\r/g, '').split('\n'), html = [], i = 0;
    while (i < lines.length) {
      var ln = lines[i];
      if (/^\s*$/.test(ln)) { i++; continue; }
      if (ln.indexOf('|') > -1 && i + 1 < lines.length && /^[\s|:\-]+$/.test(lines[i + 1]) && lines[i + 1].indexOf('-') > -1) {
        var head = splitRow(ln); i += 2; var rows = [];
        while (i < lines.length && lines[i].indexOf('|') > -1 && !/^\s*$/.test(lines[i])) { rows.push(splitRow(lines[i])); i++; }
        var t = '<table><thead><tr>' + head.map(function (h) { return '<th>' + inlineMd(h) + '</th>'; }).join('') + '</tr></thead><tbody>';
        rows.forEach(function (r) { t += '<tr>' + r.map(function (c) { var num = /\d/.test(c) && /^[\d.,%\s+\-]+$/.test(c.trim()); return '<td class="' + (num ? 'num' : '') + '">' + inlineMd(c) + '</td>'; }).join('') + '</tr>'; });
        html.push(t + '</tbody></table>'); continue;
      }
      var hm = ln.match(/^\s*#{1,4}\s+(.*)$/);
      if (hm) { html.push('<h4>' + inlineMd(hm[1]) + '</h4>'); i++; continue; }
      if (/^\s*[-*•]\s+/.test(ln)) {
        var items = [];
        while (i < lines.length && /^\s*[-*•]\s+/.test(lines[i])) { items.push(inlineMd(lines[i].replace(/^\s*[-*•]\s+/, ''))); i++; }
        html.push('<ul>' + items.map(function (x) { return '<li>' + x + '</li>'; }).join('') + '</ul>'); continue;
      }
      if (/^\s*\d+[.)]\s+/.test(ln)) {
        var its = [];
        while (i < lines.length && /^\s*\d+[.)]\s+/.test(lines[i])) { its.push(inlineMd(lines[i].replace(/^\s*\d+[.)]\s+/, ''))); i++; }
        html.push('<ol>' + its.map(function (x) { return '<li>' + x + '</li>'; }).join('') + '</ol>'); continue;
      }
      var para = [ln]; i++;
      while (i < lines.length && !/^\s*$/.test(lines[i]) && lines[i].indexOf('|') < 0 && !/^\s*[-*•]\s+/.test(lines[i]) && !/^\s*\d+[.)]\s+/.test(lines[i]) && !/^\s*#{1,4}\s+/.test(lines[i])) { para.push(lines[i]); i++; }
      html.push('<p>' + para.map(inlineMd).join('<br>') + '</p>');
    }
    return html.join('');
  }

  function bubble(text, cls) { var m = el('<div class="msg ' + cls + '"></div>'); if (cls === 'bot') { m.innerHTML = mdToHtml(text); } else { m.textContent = text; } body.appendChild(m); body.scrollTop = body.scrollHeight; return m; }
  function greet() {
    greeted = true;
    bubble('Xin chào! Tôi là ' + NAME + ', trợ lý ảo về giải ngân vốn đầu tư công tỉnh Lâm Đồng. Bạn muốn hỏi điều gì?', 'bot');
    var sug = el('<div class="chips"></div>');
    ['Tỷ lệ giải ngân toàn tỉnh hiện nay?', 'Khối nào giải ngân thấp nhất?', '5 Ban QLDA kém nhất là ai?', 'So với kế hoạch Thủ tướng giao đạt bao nhiêu?'].forEach(function (q) {
      var c = el('<button class="chip"></button>'); c.textContent = q; c.addEventListener('click', function () { input.value = q; doSend(); }); sug.appendChild(c);
    });
    body.appendChild(sug); body.scrollTop = body.scrollHeight;
  }
  input.addEventListener('input', function () { this.style.height = 'auto'; this.style.height = Math.min(90, this.scrollHeight) + 'px'; });
  input.addEventListener('keydown', function (e) { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); doSend(); } });
  send.addEventListener('click', doSend);

  function doSend() {
    var q = input.value.trim(); if (!q || busy) return;
    var chips = body.querySelector('.chips'); if (chips) chips.remove();
    bubble(q, 'me'); history.push({ role: 'user', content: q });
    input.value = ''; input.style.height = 'auto';
    busy = true; send.disabled = true;
    var typ = el('<div class="typing"><span></span><span></span><span></span></div>'); body.appendChild(typ); body.scrollTop = body.scrollHeight;

    var fd = new FormData();
    fd.append('action', 'lado_chat'); fd.append('nonce', LADO_AI.nonce); fd.append('history', JSON.stringify(history));
    fetch(LADO_AI.ajax, { method: 'POST', body: fd }).then(function (r) { return r.json(); }).then(function (res) {
      typ.remove();
      if (res && res.success) { bubble(res.data.reply, 'bot'); history.push({ role: 'assistant', content: res.data.reply }); }
      else { bubble('LaDo-AI gặp lỗi kết nối.', 'err'); }
    }).catch(function () { typ.remove(); bubble('LaDo-AI gặp lỗi kết nối.', 'err'); })
      .finally(function () { busy = false; send.disabled = false; input.focus(); });
  }
})();
