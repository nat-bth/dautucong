(function () {
  'use strict';
  if (typeof LADO_AI === 'undefined') return;
  var D = LADO_AI.data || {};
  var NAME = LADO_AI.name || 'LaDo-AI';
  var AV = LADO_AI.avatar || '';
  function avHtml() { return AV ? '<img src="' + AV.replace(/"/g, '') + '" alt="">' : '🤖'; }
  var app = document.getElementById('lado-app');
  if (!app) return;

  /* ---------- helpers ---------- */
  function vn(n) { try { return Math.round(n).toLocaleString('vi-VN'); } catch (e) { return n; } }
  function pc(n) { return (Number(n).toFixed(2)).replace('.', ',') + '%'; }
  function tyd(n) { return (n / 1000).toLocaleString('vi-VN', { maximumFractionDigits: 0 }); }
  function el(html) { var d = document.createElement('div'); d.innerHTML = html.trim(); return d.firstChild; }
  function esc(s){s=(s==null?'':String(s)).replace(/&apos;/g,"'").replace(/&#0?39;/g,"'");return s.replace(/[&<>"]/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c];});}
  var DV_ON = !!(LADO_AI.donvi && LADO_AI.donvi.has);
  function unrm(s){
    s=(s==null?'':String(s)).toLowerCase().trim();
    var map={'à':'a','á':'a','ạ':'a','ả':'a','ã':'a','â':'a','ầ':'a','ấ':'a','ậ':'a','ẩ':'a','ẫ':'a','ă':'a','ằ':'a','ắ':'a','ặ':'a','ẳ':'a','ẵ':'a','è':'e','é':'e','ẹ':'e','ẻ':'e','ẽ':'e','ê':'e','ề':'e','ế':'e','ệ':'e','ể':'e','ễ':'e','ì':'i','í':'i','ị':'i','ỉ':'i','ĩ':'i','ò':'o','ó':'o','ọ':'o','ỏ':'o','õ':'o','ô':'o','ồ':'o','ố':'o','ộ':'o','ổ':'o','ỗ':'o','ơ':'o','ờ':'o','ớ':'o','ợ':'o','ở':'o','ỡ':'o','ù':'u','ú':'u','ụ':'u','ủ':'u','ũ':'u','ư':'u','ừ':'u','ứ':'u','ự':'u','ử':'u','ữ':'u','ỳ':'y','ý':'y','ỵ':'y','ỷ':'y','ỹ':'y','đ':'d'};
    s=s.replace(/./g,function(c){return map[c]||c;});
    s=s.replace(/lam cdt$/,'').replace(/[^a-z0-9 ]/g,' ').replace(/\s+/g,' ');
    return s.trim();
  }
  function fullCDT(name){ return (name==null?'':String(name)).replace(/Ban QLDA ĐTXD số (\d+) làm CĐT/gi,'Ban Quản lý dự án số $1 làm chủ đầu tư').replace(/ làm CĐT$/i,' làm chủ đầu tư'); }
  function xlDate(v){ var s=(v==null?'':String(v)).trim(); if(/^\d+(\.0+)?$/.test(s)){ var n=Math.floor(parseFloat(s)); if(n>=20000&&n<=80000){ var d=new Date(Date.UTC(1899,11,30)+n*86400000); var p=function(x){return(x<10?'0':'')+x;}; return p(d.getUTCDate())+'/'+p(d.getUTCMonth()+1)+'/'+d.getUTCFullYear(); } } return s; }
  function unitLink(name){ return DV_ON ? '<span class="lk" data-u="' + esc(unrm(name)) + '">' + esc(fullCDT(name)) + '</span>' : esc(fullCDT(name)); }

  /* ---------- xuất Excel / Word (dùng chung) ---------- */
  function ladoDL(blob, fname) {
    var a = document.createElement('a'), url = URL.createObjectURL(blob);
    a.href = url; a.download = fname; document.body.appendChild(a); a.click();
    setTimeout(function () { document.body.removeChild(a); URL.revokeObjectURL(url); }, 200);
  }
  function ladoExportXlsx(rows, fname, sheet) {
    if (!rows || !rows.length) { alert('Không có dữ liệu để xuất.'); return; }
    if (window.XLSX) {
      var ws = XLSX.utils.json_to_sheet(rows);
      var keys = Object.keys(rows[0]);
      ws['!cols'] = keys.map(function (k) {
        var w = k.length; rows.forEach(function (r) { w = Math.max(w, String(r[k] == null ? '' : r[k]).length); });
        return { wch: Math.min(60, w + 2) };
      });
      var wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, (sheet || 'Sheet1').substring(0, 28));
      XLSX.writeFile(wb, fname + '.xlsx');
      return;
    }
    // fallback CSV (Excel mở được) nếu SheetJS chưa tải
    var keys2 = Object.keys(rows[0]);
    var csv = keys2.join(',') + '\n' + rows.map(function (r) {
      return keys2.map(function (k) { var v = r[k] == null ? '' : String(r[k]); return /[",\n]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v; }).join(',');
    }).join('\n');
    ladoDL(new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8;' }), fname + '.csv');
  }
  function ladoExportDoc(rows, fname, title) {
    if (!rows || !rows.length) { alert('Không có dữ liệu để xuất.'); return; }
    var keys = Object.keys(rows[0]);
    var th = keys.map(function (k) { return '<th>' + esc(k) + '</th>'; }).join('');
    var tb = rows.map(function (r) {
      return '<tr>' + keys.map(function (k) { return '<td>' + esc(r[k] == null ? '' : r[k]) + '</td>'; }).join('') + '</tr>';
    }).join('');
    var html = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns="http://www.w3.org/TR/REC-html40">'
      + '<head><meta charset="utf-8"><style>'
      + 'body{font-family:"Times New Roman",serif;font-size:13pt}'
      + 'h2{text-align:center;font-size:14pt}'
      + 'table{border-collapse:collapse;width:100%}th,td{border:1px solid #444;padding:5px 7px;font-size:11pt}'
      + 'th{background:#0f2c52;color:#fff}td{vertical-align:top}'
      + '</style></head><body><h2>' + esc(title || fname) + '</h2>'
      + '<table><thead><tr>' + th + '</tr></thead><tbody>' + tb + '</tbody></table>'
      + '<p style="font-size:10pt;font-style:italic">Nguồn: Hệ thống dữ liệu giải ngân vốn đầu tư công tỉnh Lâm Đồng.</p></body></html>';
    ladoDL(new Blob(['\ufeff' + html], { type: 'application/msword' }), fname + '.doc');
  }

  var tong = D.tong || {}, khoi = D.khoi || [], giao = D.kehoach_giao || [];
  var color = { navy:'#0f2c52', blue:'#2563eb', sky:'#38bdf8', green:'#16a34a', amber:'#d97706', red:'#dc2626', line:'#e2e8f0' };

  /* ---------- build shell ---------- */
  app.classList.remove('lado-loading');
  app.innerHTML = ''
  + '<div class="lado-top">'
  +   '<div class="lado-brand"><div class="lado-logo">' + (LADO_AI.avatar ? '<img src="' + esc(LADO_AI.avatar) + '" alt="">' : '📊') + '</div>'
  +     '<div><h1>Hệ thống dữ liệu giải ngân vốn đầu tư công tỉnh ' + esc(D.tinh || 'Lâm Đồng') + '</h1>'
  +     '<p>Văn phòng UBND tỉnh</p></div></div>'
  +   '<div class="lado-spacer"></div>'
  +   '<div class="lado-asof">🗓️ Lũy kế đến ' + esc(D.as_of || '') + '</div>'
  + '</div>'
  + '<nav class="lado-nav"><button class="ln-arrow ln-prev" id="ln-prev" aria-label="Trái">‹</button><div class="ln-track" id="lado-nav"></div><button class="ln-arrow ln-next" id="ln-next" aria-label="Phải">›</button></nav>'
  + '<div class="lado-body">'
  +   '<div class="lado-kpis" id="sec-tong"></div>'
  +   '<div class="card" id="sec-dl"><h3>📥 Tải báo cáo</h3><p class="hint">Bấm để ' + esc(NAME) + ' tổng hợp và xuất báo cáo định kỳ (.docx).</p>'
  +     '<div class="lado-actions">'
  +       (LADO_AI.has_day ? '<button class="dlbtn day" data-type="day"><span class="ic">📆</span><span>Tải báo cáo NGÀY<small>Cập nhật mới nhất</small></span></button>' : '')
  +       '<button class="dlbtn week" data-type="week"><span class="ic">📄</span><span>Tải báo cáo TUẦN<small>Bản cập nhật mới nhất</small></span></button>'
  +       '<button class="dlbtn month" data-type="month"><span class="ic">📑</span><span>Tải báo cáo THÁNG<small>Tổng hợp theo tháng</small></span></button>'
  +     '</div><div id="pl-dlbar"></div></div>'
  +   '<div class="card day-card" id="sec-day"><h3>📈 Tỷ lệ giải ngân theo ngày — phấn đấu đạt 40% vào 01/7/2026</h3><p class="hint">So với kế hoạch vốn Thủ tướng Chính phủ giao. Ba đường: <b>kế hoạch phấn đấu</b> (mục tiêu theo ngày để đạt 40% vào 01/7), <b>kế hoạch đăng ký</b> (tổng hợp theo file danh mục) và <b>kết quả thực hiện thực tế</b> theo ngày.</p>'
  +     '<div class="day-banner" id="c-day-banner"></div>'
  +     '<div class="day-scroll"><div class="day-chart-inner" id="c-day-inner"><div class="day-canvas-box"><canvas id="c-day"></canvas></div><div class="day-axis" id="c-day-axis"></div></div></div>'
  +     '<div class="day-info" id="c-day-info"></div>'
  +     '<div class="day-scroll-hint">← Kéo ngang để xem các ngày · bấm vào một ngày bên dưới để xem chi tiết →</div>'
  +     '<div class="day-legend" id="c-day-legend"></div>'
  +     '<div class="day-dl" id="day-dl"></div></div>'
  +   '<div class="lado-grid" id="sec-khoi">'
  +     '<div class="card gauge"><h3>🎯 Tỷ lệ giải ngân toàn tỉnh</h3><p class="hint">Tổng kế hoạch ' + vn(tong.kh) + ' • đã giải ngân ' + vn(tong.gn) + ' (triệu đồng)</p>'
  +       '<div class="chart-wrap"><canvas id="c-gauge"></canvas><div class="gauge-center"><div class="pct">' + pc(tong.tl || 0) + '</div><div class="cap">lũy kế giải ngân</div></div></div></div>'
  +     '<div class="card"><h3>🏗️ Theo nhóm chủ đầu tư</h3><p class="hint">Kế hoạch vốn và đã giải ngân (tỷ đồng)</p><div class="chart-wrap"><canvas id="c-khoi"></canvas></div></div>'
  +   '</div>'
  +   '<div class="card barkhoi-card" id="sec-barkhoi"><h3>📊 Tỷ lệ giải ngân theo khối chủ đầu tư (đến ' + esc(D.as_of || '') + ')</h3>'
  +     '<div class="chart-wrap" style="height:340px"><canvas id="c-barkhoi"></canvas></div></div>'
  +   '<div class="card giao-card" id="sec-giao"><h3>🎯 Tiến độ giải ngân so với kế hoạch giao</h3>'
  +     '<p class="hint">So sánh tỷ lệ giải ngân theo từng mức kế hoạch: Thủ tướng Chính phủ giao, HĐND tỉnh giao và UBND tỉnh phân bổ chi tiết.</p>'
  +     '<div id="giao-table"></div>'
  +     '<div class="chart-wrap" style="height:210px;margin-top:8px"><canvas id="c-giao"></canvas></div></div>'
  +   '<div class="card src-card" id="sec-nguon"><h3>🎯 Tỷ lệ giải ngân theo nguồn vốn</h3><p class="hint">Tách riêng tiến độ vốn năm 2026 và vốn kéo dài năm 2025.</p>'
  +     '<div class="src-gauges" id="src-gauges"></div></div>'
  +   '<div class="card pie-card" id="sec-cocau"><h3>🧭 Cơ cấu theo nhóm chủ đầu tư</h3><p class="hint">Tỷ trọng giá trị đã giải ngân giữa các khối.</p>'
  +     '<div class="pie-wrap"><div class="pie-canvas"><canvas id="c-pie"></canvas></div><div class="pie-legend" id="pie-legend"></div></div></div>'
  +   '<div class="card bigzero-card" id="sec-bigzero"><h3>💰 Các dự án chưa giải ngân (0%)</h3><p class="hint">Danh sách các dự án được giao vốn nhưng chưa giải ngân, mặc định xếp theo kế hoạch vốn lớn → nhỏ. Lọc theo số lượng, nhóm/chủ đầu tư và xuất Excel. Bấm để xem chủ đầu tư, liên hệ và khó khăn.</p>'
  +     '<div id="bigzero-box"></div></div>'
  +   '<div class="card week-card" id="sec-week"><h3>📅 Tỷ lệ giải ngân theo tuần</h3><p class="hint">Diễn biến tỷ lệ giải ngân lũy kế toàn tỉnh qua các tuần. Bấm để tải báo cáo từng tuần.</p>'
  +     '<div class="chart-wrap" style="height:240px"><canvas id="c-week"></canvas></div>'
  +     '<div class="week-list" id="week-list"></div></div>'
  +   '<div class="card banqlda-card" id="sec-banqlda"><h3>🏛️ Ban Quản lý dự án — tổng hợp theo từng Ban</h3><p class="hint">Tổng kế hoạch vốn và giải ngân của 03 Ban QLDA; chi tiết phần Ban trực tiếp làm chủ đầu tư và các Ban khu vực trực thuộc. Bấm tên Ban để xem danh mục dự án.</p>'
  +     '<div id="banqlda-box"></div></div>'
  +   '<div class="two-col" id="sec-rank">'
  +     '<div class="card"><h3>🥇 Ban QLDA giải ngân tốt nhất</h3><div class="rank" id="r-topban"></div></div>'
  +     '<div class="card"><h3>🐢 Ban QLDA giải ngân thấp nhất</h3><div class="rank bad" id="r-botban"></div></div>'
  +   '</div>'
  +   '<div class="two-col">'
  +     '<div class="card"><h3>🏆 Xã/phường tiêu biểu</h3><div class="rank" id="r-topxa"></div></div>'
  +     '<div class="card"><h3>🏢 Sở, ngành, đơn vị tiêu biểu</h3><div class="rank" id="r-topso"></div></div>'
  +   '</div>'
  +   '<div class="card lado-detail" id="sec-detail"><h3>📋 Bảng kết quả giải ngân chi tiết (toàn bộ đơn vị)</h3>'
  +     '<p class="hint">Số liệu lũy kế theo từng chủ đầu tư (triệu đồng). Mặc định sắp theo tỷ lệ giải ngân giảm dần. Bấm tiêu đề cột để sắp xếp, dùng ô lọc bên dưới.</p>'
  +     '<div class="ld-tabs">'
  +       '<button class="ld-tab on" data-g="ban">Ban QLDA (<span id="cnt-ban">0</span>)</button>'
  +       '<button class="ld-tab" data-g="so">Sở, ngành (<span id="cnt-so">0</span>)</button>'
  +       '<button class="ld-tab" data-g="xa">Xã, phường (<span id="cnt-xa">0</span>)</button>'
  +     '</div>'
  +     '<div class="ld-controls">'
  +       '<input type="search" class="ld-search" id="ld-search" placeholder="🔍 Tìm theo tên đơn vị…">'
  +       '<select class="ld-filter" id="ld-filter"><option value="">Tất cả tỷ lệ</option><option value="ge20">Tốt (≥ 20%)</option><option value="5to20">Trung bình (5–20%)</option><option value="lt5">Thấp (< 5%)</option><option value="zero">Chưa giải ngân (0%)</option></select>'
  +       '<div class="ld-exports"><button class="ld-exp xls" id="ld-xls">⬇ Excel</button><button class="ld-exp doc" id="ld-doc">⬇ Word</button></div>'
  +     '</div>'
  +     '<div class="ld-table-wrap" id="ld-table"></div>'
  +   '</div>'
  +   '<div class="card sixto-card" id="sec-6to"><div class="sixto-top"><h3>🧩 Thống kê theo 06 tổ công tác</h3><button class="sixto-toggle" id="sixto-toggle">Hiển thị thống kê 6 tổ ▾</button></div>'
  +     '<div class="sixto-body" id="sixto-body" style="display:none"></div></div>'
  +   '<div class="card wkstat-card" id="sec-wkstat"><h3>📊 Thực hiện kế hoạch giải ngân tuần</h3><p class="hint" id="wkstat-ky"></p><div class="wk-stats" id="wk-stats"></div></div>'
  +   '<div class="card" id="sec-zero"><h3>🚫 Đơn vị chưa giải ngân (0%)</h3><p class="hint">Danh sách đầy đủ các đơn vị/địa phương được giao vốn nhưng đến nay chưa phát sinh giải ngân.</p><div id="zero-box"></div></div>'
  +   '<div class="card kn-card" id="kn-card"><h3>💡 Kiến nghị, đề xuất tổng hợp</h3>'
  +     '<p class="hint" id="kn-sub"></p>'
  +     '<div class="kn-controls">'
  +       '<input type="search" id="kn-q" placeholder="🔍 Tìm theo đơn vị, dự án, nội dung…">'
  +       '<select id="kn-khoi"><option value="">Tất cả khối</option><option value="Ban QLDA">Ban QLDA</option><option value="Sở, ngành">Sở, ngành</option><option value="Xã, phường, đặc khu">Xã, phường, đặc khu</option></select>'
  +       '<select id="kn-nhom"><option value="">Tất cả nhóm khó khăn</option></select>'
  +     '</div>'
  +     '<div class="kn-chips" id="kn-chips"></div>'
  +     '<div class="kn-list" id="kn-list"></div>'
  +     '<div class="kn-more-wrap"><button id="kn-more" class="kn-more" style="display:none">Xem thêm</button></div>'
  +   '</div>'
  +   '<div class="lado-footer">Phát triển bởi <b>Nguyễn Anh Trung</b></div>'
  + '</div>'
  /* stats popup modal */
  + '<div class="lado-modal" id="lado-modal"><div class="lm-box"><div class="lm-head"><h4 id="lm-title"></h4><button class="lm-x" id="lm-x">✕</button></div><div class="lm-body" id="lm-body"></div></div></div>'
  + '<div class="lado-modal lado-unit" id="lado-unit"><div class="lu-box"><div class="lu-head"><div id="lu-title"></div><button class="lm-x" id="lu-x">✕</button></div><div class="lu-body" id="lu-body"></div></div></div>'
  /* download overlay */
  + '<div class="lado-ov" id="lado-ov"><div class="ov-box">'
  +   '<div class="ov-orb"></div>'
  +   '<h4><span class="who">' + esc(NAME) + '</span> đang tổng hợp dữ liệu</h4>'
  +   '<div id="ov-sub" style="font-size:13px;opacity:.85">Vui lòng đợi trong giây lát…</div>'
  +   '<div class="ov-steps">'
  +     '<div class="ov-step" data-s="0"><span class="dot">1</span> Kết nối cơ sở dữ liệu giải ngân</div>'
  +     '<div class="ov-step" data-s="1"><span class="dot">2</span> Tổng hợp số liệu Kho bạc &amp; Sở Tài chính</div>'
  +     '<div class="ov-step" data-s="2"><span class="dot">3</span> Dựng biểu đồ &amp; bảng phân tích</div>'
  +     '<div class="ov-step" data-s="3"><span class="dot">4</span> Xuất báo cáo định dạng .docx</div>'
  +   '</div>'
  +   '<div class="ov-prog"><i id="ov-prog"></i></div>'
  +   '<button class="ov-cancel" id="ov-cancel">Hủy</button>'
  + '</div></div>'
  /* chat */
  + '<button class="lado-fab" id="lado-fab"><span class="av">' + avHtml() + '</span> Hỏi ' + esc(NAME) + '</button>'
  + '<div class="lado-chat" id="lado-chat">'
  +   '<div class="chat-head"><div class="av">' + avHtml() + '</div><div class="ch-meta"><b>' + esc(NAME) + '</b><span><i class="dot-on"></i> Trực tuyến • Trợ lý giải ngân ĐTC</span></div><button class="x" id="chat-clear" title="Xóa toàn bộ cuộc trò chuyện">🗑</button><button class="x" id="chat-fs" title="Phóng to toàn màn hình">⛶</button><button class="x" id="chat-x">✕</button></div>'
  +   '<div class="chat-body" id="chat-body"></div>'
  +   '<div class="chat-foot"><textarea id="chat-in" rows="1" placeholder="Nhập câu hỏi về phân bổ, giải ngân…"></textarea><button id="chat-send">➤</button></div>'
  +   '<div class="foot-note">' + esc(NAME) + ' có thể trả lời chưa đầy đủ. Vui lòng đối chiếu văn bản chính thức.</div>'
  + '</div>';

  /* ---------- KPIs ---------- */
  var kpis = app.querySelector('.lado-kpis');
  var nguon = D.nguon || [];
  var v26 = (nguon[0] && nguon[0].gn) || 0, vkd = (nguon[1] && nguon[1].gn) || 0;
  var _days = LADO_AI.days || [];
  var _dDelta = (_days.length >= 2) ? ((+_days[_days.length - 1].tl) - (+_days[_days.length - 2].tl)) : null;
  var _dMoney = (_dDelta != null) ? ((+tong.kh || 0) * _dDelta / 100) : null;
  var gnSub = D.as_of ? ('Lũy kế đến ' + esc(D.as_of)) : 'Lũy kế đến nay';
  var tlSub = (_dDelta != null)
    ? '<span class="' + (_dDelta >= 0 ? 'up' : 'down') + '">' + (_dDelta >= 0 ? '▲ +' : '▼ ') + pc(Math.abs(_dDelta)) + '</span> so với hôm qua'
      + (_dMoney ? ' <span class="' + (_dMoney >= 0 ? 'up' : 'down') + '">(' + (_dMoney >= 0 ? '+' : '−') + vn(Math.abs(Math.round(_dMoney))) + ' tr.đ)</span>' : '')
    : 'So với hôm qua: chưa đủ dữ liệu';
  kpis.appendChild(el('<div class="kpi n"><div class="lab">Tổng kế hoạch vốn</div><div class="val">' + tyd(tong.kh) + '<span style="font-size:14px"> tỷ</span></div><div class="sub">gồm vốn kéo dài 2025</div></div>'));
  kpis.appendChild(el('<div class="kpi"><div class="lab">Lũy kế giải ngân</div><div class="val">' + tyd(tong.gn) + '<span style="font-size:14px"> tỷ</span></div><div class="sub">' + gnSub + '</div></div>'));
  kpis.appendChild(el('<div class="kpi g"><div class="lab">Tỷ lệ giải ngân</div><div class="val">' + pc(tong.tl || 0) + '</div><div class="sub">' + tlSub + '</div></div>'));
  kpis.appendChild(el('<div class="kpi a"><div class="lab">Đơn vị chưa giải ngân</div><div class="val">' + ((D.zero && D.zero.tong) || 0) + '</div><div class="sub">' + ((D.zero && D.zero.so) || 0) + ' sở/ngành • ' + ((D.zero && D.zero.xa) || 0) + ' xã/phường</div></div>'));

  /* ---------- charts ---------- */
  if (window.Chart) {
    Chart.defaults.font.family = "'Inter','Segoe UI',sans-serif";
    Chart.defaults.font.size = 12.5;

    var g = (tong.tl || 0);
    new Chart(document.getElementById('c-gauge'), {
      type: 'doughnut',
      data: { datasets: [{ data: [g, 100 - g], backgroundColor: [color.navy, '#e8eef6'], borderWidth: 0 }] },
      options: { cutout: '74%', plugins: { legend: { display: false }, tooltip: { enabled: false } }, animation: { animateRotate: true } }
    });

    new Chart(document.getElementById('c-khoi'), {
      type: 'bar',
      data: {
        labels: khoi.map(function (k) { return k.ten.replace(/\s*\(.*\)/, ''); }),
        datasets: [
          { label: 'Kế hoạch', data: khoi.map(function (k) { return k.kh / 1000; }), backgroundColor: '#cdddf0', borderRadius: 6 },
          { label: 'Đã giải ngân', data: khoi.map(function (k) { return k.gn / 1000; }), backgroundColor: color.navy, borderRadius: 6 }
        ]
      },
      options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'bottom' }, tooltip: { callbacks: { label: function (c) { return c.dataset.label + ': ' + vn(c.raw) + ' tỷ'; } } } }, scales: { y: { ticks: { callback: function (v) { return vn(v); } } } } }
    });

    (function () {
      var cv = document.getElementById('c-giao'); if (!cv) return;
      var short = giao.map(function (x) {
        if (/Thủ tướng/i.test(x.ten)) return 'Thủ tướng CP giao';
        if (/HĐND|Hội đồng/i.test(x.ten)) return 'HĐND tỉnh giao';
        if (/UBND/i.test(x.ten)) return 'UBND tỉnh phân bổ';
        return x.ten;
      });
      var vals = giao.map(function (x) { return +x.tl || 0; });
      var cols = ['#2563eb', '#0ea5e9', '#6366f1'];
      var mx = Math.max.apply(null, vals.concat([5]));
      var lab = {
        id: 'giaoLabels',
        afterDatasetsDraw: function (ch) {
          var ctx = ch.ctx, meta = ch.getDatasetMeta(0);
          ctx.save(); ctx.font = '700 13px Inter, Segoe UI, sans-serif'; ctx.fillStyle = '#0f172a'; ctx.textBaseline = 'middle'; ctx.textAlign = 'left';
          meta.data.forEach(function (bar, i) { ctx.fillText(pc(vals[i]), bar.x + 8, bar.y); });
          ctx.restore();
        }
      };
      new Chart(cv, {
        type: 'bar',
        data: { labels: short, datasets: [{ data: vals, backgroundColor: cols, borderRadius: 6, maxBarThickness: 44 }] },
        options: {
          indexAxis: 'y', responsive: true, maintainAspectRatio: false, layout: { padding: { right: 56 } },
          plugins: { legend: { display: false }, tooltip: { callbacks: { label: function (c) { return 'Tỷ lệ giải ngân: ' + pc(c.raw); } } } },
          scales: { x: { beginAtZero: true, max: Math.ceil((mx + 2) / 2) * 2, ticks: { callback: function (v) { return v + '%'; } }, grid: { color: '#eef2f7' } }, y: { grid: { display: false }, ticks: { font: { size: 12.5, weight: '600' }, color: '#334155' } } }
        },
        plugins: [lab]
      });
    })();

    (function () {
      var box = document.getElementById('giao-table'); if (!box) return;
      // "Đã giải ngân" lấy theo từng dòng mức giao (cột giải ngân vốn 2026 trong báo cáo) — cùng nguồn với biểu đồ ngày
      var nguon = D.nguon || [];
      var gnFallback = 0;
      nguon.forEach(function (n) { if (/2026/.test(n.ten) && !/kéo dài/i.test(n.ten)) gnFallback = +n.gn || 0; });
      if (!gnFallback) gnFallback = +tong.gn || 0;
      var gnTTg = 0;
      (giao || []).forEach(function (x) { if (/Thủ tướng/i.test(x.ten) && (+x.gn || 0) > 0) gnTTg = +x.gn || 0; });
      var rows = giao.map(function (x) {
        var kh = +x.kh || 0, tl = +x.tl || 0;
        var gn = (+x.gn || 0) > 0 ? (+x.gn) : gnFallback;
        var conlai = Math.max(0, kh - gn);
        return '<tr><td class="gt-name">' + esc(x.ten) + '</td>'
          + '<td class="num">' + vn(kh) + '</td>'
          + '<td class="num">' + vn(gn) + '</td>'
          + '<td class="num">' + vn(conlai) + '</td>'
          + '<td class="gt-progcell"><div class="gt-prog"><div class="gt-bar" style="width:' + Math.max(2, Math.min(100, tl)) + '%"></div></div><span class="gt-pc">' + pc(tl) + '</span></td></tr>';
      }).join('');
      box.innerHTML = '<div class="gt-wrap"><table class="gt-table"><thead><tr><th>Mức kế hoạch giao</th><th class="num">KH vốn (tr.đ)</th><th class="num">Đã giải ngân</th><th class="num">Còn lại</th><th>Tiến độ</th></tr></thead><tbody>' + rows + '</tbody></table></div>'
        + '<div class="lu-unit-note">Đơn vị: triệu đồng • "Đã giải ngân" theo <b>vốn năm 2026</b> (so kế hoạch Thủ tướng giao: ' + vn(gnTTg || gnFallback) + ' tr.đ) — khớp với biểu đồ theo ngày (đến ' + esc(D.as_of || '') + ').</div>';
    })();

    (function () {
      var cv = document.getElementById('c-barkhoi'); if (!cv) return;
      var labels = ['Ban QLDA', 'Sở, ngành', 'Xã, phường', 'TOÀN TỈNH'];
      var vals = [ (khoi[0] && khoi[0].tl) || 0, (khoi[1] && khoi[1].tl) || 0, (khoi[2] && khoi[2].tl) || 0, (tong.tl || 0) ];
      var cols = ['#2e74b5', '#e8702a', '#4e8f3a', '#8031a7'];
      var mx = Math.max.apply(null, vals.concat([10]));
      var top = Math.ceil((mx + 3) / 5) * 5;
      var labelPlugin = {
        id: 'barLabels',
        afterDatasetsDraw: function (ch) {
          var ctx = ch.ctx, meta = ch.getDatasetMeta(0);
          ctx.save();
          ctx.font = '700 15px Inter, Segoe UI, sans-serif';
          ctx.fillStyle = '#0f172a';
          ctx.textAlign = 'center';
          meta.data.forEach(function (bar, i) { ctx.fillText(pc(vals[i]), bar.x, bar.y - 9); });
          ctx.restore();
        }
      };
      new Chart(cv, {
        type: 'bar',
        data: { labels: labels, datasets: [{ data: vals, backgroundColor: cols, borderRadius: 4, maxBarThickness: 96 }] },
        options: {
          responsive: true, maintainAspectRatio: false,
          layout: { padding: { top: 24 } },
          plugins: { legend: { display: false }, tooltip: { callbacks: { label: function (c) { return 'Tỷ lệ giải ngân: ' + pc(c.raw); } } } },
          scales: {
            y: { beginAtZero: true, max: top, title: { display: true, text: 'Tỷ lệ giải ngân (%)', font: { size: 12.5, weight: '600' } }, ticks: { stepSize: 5, callback: function (v) { return v; } }, grid: { color: '#eef2f7' } },
            x: { grid: { display: false }, ticks: { font: { size: 13, weight: '600' }, color: '#334155' } }
          }
        },
        plugins: [labelPlugin]
      });
    })();

    new Chart(document.getElementById('c-pie'), {
      type: 'doughnut',
      data: { labels: khoi.map(function (k) { return k.ten.replace(/\s*\(.*\)/, ''); }), datasets: [{ data: khoi.map(function (k) { return k.gn; }), backgroundColor: [color.navy, color.blue, color.sky], borderWidth: 2, borderColor: '#fff' }] },
      options: { responsive: true, maintainAspectRatio: false, cutout: '58%', plugins: { legend: { display: false }, tooltip: { callbacks: { label: function (c) { return c.label + ': ' + vn(c.raw) + ' tr.đ'; } } } } }
    });
    (function () {
      var lg = document.getElementById('pie-legend'); if (!lg) return;
      var totGn = khoi.reduce(function (s, k) { return s + (+k.gn || 0); }, 0) || 1;
      var cols = [color.navy, color.blue, color.sky];
      lg.innerHTML = khoi.map(function (k, i) {
        var share = (+k.gn || 0) / totGn * 100;
        return '<div class="pl-item"><span class="pl-dot" style="background:' + cols[i % 3] + '"></span>'
          + '<div class="pl-info"><div class="pl-name">' + esc(k.ten) + '</div>'
          + '<div class="pl-nums"><b>' + vn(k.gn) + '</b> / ' + vn(k.kh) + ' tr.đ • TL <b>' + pc(k.tl) + '</b> • cơ cấu ' + pc(share) + '</div></div></div>';
      }).join('');
    })();

    /* source-vốn gauges (2026 / 2025) */
    (function () {
      var host = document.getElementById('src-gauges'); if (!host) return;
      if (nguon.length === 2 && tong.kh) {
        if (nguon[1].kh && nguon[0].kh == null) nguon[0].kh = tong.kh - nguon[1].kh;
        if (nguon[0].kh && nguon[1].kh == null) nguon[1].kh = tong.kh - nguon[0].kh;
      }
      var palette = [color.blue, '#7c3aed', color.sky];
      (nguon || []).forEach(function (s, i) {
        var tl = (s.tl != null) ? s.tl : (s.kh ? (s.gn / s.kh * 100) : null);
        if (tl == null) return;
        var cell = el('<div class="src-item"><div class="src-canv"><canvas></canvas><div class="src-mid"><b>' + pc(tl) + '</b></div></div>'
          + '<div class="src-meta"><div class="src-name">' + esc(s.ten) + '</div><div class="src-sub">GN ' + vn(s.gn) + (s.kh ? ' / ' + vn(s.kh) : '') + ' tr.đ</div></div></div>');
        host.appendChild(cell);
        new Chart(cell.querySelector('canvas'), {
          type: 'doughnut',
          data: { datasets: [{ data: [tl, Math.max(0, 100 - tl)], backgroundColor: [palette[i % palette.length], '#e8eef6'], borderWidth: 0 }] },
          options: { cutout: '72%', plugins: { legend: { display: false }, tooltip: { enabled: false } } }
        });
      });
    })();

    /* weekly trend line */
    (function () {
      var weeks = (LADO_AI.weeks || []).filter(function (w) { return w.tl != null; });
      var cv = document.getElementById('c-week'); if (!cv || !weeks.length) { var wc = document.querySelector('.week-card .chart-wrap'); if (wc && !weeks.length) wc.style.display = 'none'; return; }
      new Chart(cv, {
        type: 'line',
        data: {
          labels: weeks.map(function (w) { return w.ky; }),
          datasets: [{
            label: 'Tỷ lệ giải ngân', data: weeks.map(function (w) { return w.tl; }),
            borderColor: color.blue, backgroundColor: 'rgba(37,99,235,.12)', fill: true,
            tension: .3, pointRadius: 4, pointBackgroundColor: color.blue, borderWidth: 2.5
          }]
        },
        options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false }, tooltip: { callbacks: { label: function (c) { return pc(c.raw); } } } }, scales: { y: { ticks: { callback: function (v) { return v + '%'; } }, beginAtZero: true } } }
      });
    })();

    /* daily trend */
    (function () {
      var cv = document.getElementById('c-day');
      if (!cv) return;
      var giaoArr = D.kehoach_giao || [];
      var TTg = 0;
      giaoArr.forEach(function (g) { if (/Thủ tướng/i.test(g.ten)) TTg = +g.kh || 0; });
      var traj = (LADO_AI.donvi && LADO_AI.donvi.dk_traj) || [];
      var days = (LADO_AI.days || []).filter(function (d) { return d.tl != null; });
      if (!TTg && !days.length && !traj.length) { var dc0 = document.querySelector('.day-card'); if (dc0) dc0.style.display = 'none'; return; }

      // mốc thời gian: số ngày kể từ ngày gốc
      function parseD(s) { var m = String(s || '').match(/(\d{1,2})\/(\d{1,2})(?:\/(\d{2,4}))?/); if (!m) return null; var y = m[3] ? (+m[3] < 100 ? 2000 + +m[3] : +m[3]) : 2026; return Date.UTC(y, (+m[2]) - 1, +m[1]); }
      var TARGET = Date.UTC(2026, 6, 1); // 01/7/2026
      var START = Date.UTC(2026, 5, 4);  // theo dõi từ 04/6/2026
      var dayMs = 86400000;

      // Theo dõi từ 04/6/2026 + khử trùng ngày (giữ bản ghi mới nhất của mỗi ngày)
      var seen = {};
      days.forEach(function (d) { var t = parseD(d.date); if (t != null && t >= START) { seen[t] = d; } });
      days = Object.keys(seen).map(function (t) { var d = seen[t]; d.__t = +t; return d; }).sort(function (a, b) { return a.__t - b.__t; });

      var base = START;
      var X = function (t) { return Math.round((t - base) / dayMs); };
      var fmtD = function (t) { var d = new Date(t); return ('0' + d.getUTCDate()).slice(-2) + '/' + ('0' + (d.getUTCMonth() + 1)).slice(-2); };

      // Quy đổi mọi ngày về cùng cơ sở: tỷ lệ so với KH Thủ tướng giao.
      // Ưu tiên ttg (lưu khi nhập báo cáo); ngày cũ chỉ có tỷ lệ chung -> nhân hệ số quy đổi.
      var ttgNow = 0; giaoArr.forEach(function (g) { if (/Thủ tướng/i.test(g.ten)) ttgNow = +g.tl || 0; });
      var tlNow = (+tong.tl) || (days.length ? (+days[days.length - 1].tl || 0) : 0);
      var ratio = (ttgNow > 0 && tlNow > 0) ? (ttgNow / tlNow) : 1;
      var actY = function (d) { return (d.ttg != null && +d.ttg > 0) ? (+d.ttg) : (Math.round((+d.tl || 0) * ratio * 100) / 100); };
      // Đường THỰC HIỆN (kho bạc, theo ngày) — vs Thủ tướng giao, từ 04/6
      // Đường THỰC HIỆN: tỷ lệ & số tiền theo VỐN NĂM 2026 (khớp mục "Tiến độ so kế hoạch giao").
      // Ưu tiên gn26 lưu theo ngày; ngày cũ chưa có gn26 thì quy đổi từ tỷ lệ (ttg/tl).
      var actual = days.map(function (d) {
        var t = d.__t;
        var has26 = (+d.gn26 || 0) > 0;
        var amt26, y;
        if (has26 && TTg > 0) {
          // Nguồn chuẩn: số giải ngân vốn 2026 thực tế / KH Thủ tướng giao
          amt26 = (+d.gn26);
          y = Math.round(amt26 / TTg * 10000) / 100;
        } else {
          // Ngày cũ chưa lưu gn26: dùng tỷ lệ ttg (so Thủ tướng) đã lưu, hoặc quy đổi từ tl chung
          y = actY(d);
          amt26 = TTg > 0 ? (TTg * y / 100) : 0;
        }
        return { x: X(t), y: y, amt: amt26, amtReal: amt26, gnAll: (+d.gn || 0), t: t };
      }).sort(function (a, b) { return a.x - b.x; });

      // Đường ĐĂNG KÝ (theo danh mục) — lũy kế đăng ký / Thủ tướng, từ 04/6
      var reg = traj.map(function (r) { var t = parseD(r.date); return (t != null && t >= START) ? { x: X(t), y: TTg > 0 ? (Math.round(+r.amt / TTg * 10000) / 100) : 0, amt: +r.amt, t: t } : null; }).filter(Boolean).sort(function (a, b) { return a.x - b.x; });

      // Đường PHẤN ĐẤU đạt 40% vào 01/7 — đường CỐ ĐỊNH từ điểm đầu kỳ (04/6) đến 40% ngày 01/7
      var startT = actual.length ? actual[0].t : START;
      var startY = actual.length ? actual[0].y : 0;
      var goal = [];
      var totalDays = Math.max(1, Math.round((TARGET - startT) / dayMs));
      for (var i = 0; i <= totalDays; i++) {
        var t = startT + i * dayMs;
        var y = startY + (40 - startY) * (i / totalDays);
        goal.push({ x: X(t), y: Math.round(y * 100) / 100, amt: TTg * y / 100, t: t });
      }
      var goalAt = function (t) { var i2 = Math.round((t - startT) / dayMs); if (i2 < 0) i2 = 0; if (i2 >= goal.length) i2 = goal.length - 1; return goal[i2]; };

      // ===== Băng-rôn kết quả hôm nay =====
      (function () {
        var bn = document.getElementById('c-day-banner'); if (!bn || !actual.length) { if (bn) bn.style.display = 'none'; return; }
        var last = actual[actual.length - 1];
        // Dùng THẲNG điểm cuối của đường thực tế (đã chuẩn hóa từ gn26) — một nguồn duy nhất
        var lastAmt = last.amtReal || last.amt || 0;
        var lastY = last.y;
        var exp = goalAt(last.t);
        var gap = Math.round((lastY - exp.y) * 100) / 100;
        var gapAmt = Math.round(lastAmt - exp.amt);
        var ok = gap >= 0;
        var need40 = Math.round(TTg * 0.4 - lastAmt);
        bn.innerHTML = '<div class="db-row">'
          + '<div class="db-cell main"><div class="db-lab">📅 Ngày ' + fmtD(last.t) + ' — kết quả so KH Thủ tướng giao</div>'
          + '<div class="db-val">' + pc(lastY) + '<span class="db-amt">' + vn(Math.round(lastAmt)) + ' tr.đ (vốn năm 2026)</span></div></div>'
          + '<div class="db-cell ' + (ok ? 'ok' : 'bad') + '"><div class="db-lab">So kế hoạch kỳ vọng hôm nay (' + pc(exp.y) + ')</div>'
          + '<div class="db-val">' + (ok ? '▲ vượt ' : '▼ chậm ') + pc(Math.abs(gap)) + '<span class="db-amt">' + (ok ? '+' : '−') + vn(Math.abs(gapAmt)) + ' tr.đ</span></div></div>'
          + '<div class="db-cell goal"><div class="db-lab">🎯 Còn lại để đạt 40% (01/7)</div>'
          + '<div class="db-val">' + pc(Math.max(0, Math.round((40 - lastY) * 100) / 100)) + '<span class="db-amt">' + vn(Math.max(0, need40)) + ' tr.đ</span></div></div>'
          + '</div>';
      })();

      var fmtAmt = function (a) { return vn(Math.round(a)) + ' tr.đ'; };
      var mark = { id: 'goalMark', afterDatasetsDraw: function (ch) {
        var sc = ch.scales.x, sy = ch.scales.y, ctx = ch.ctx;
        var px = sc.getPixelForValue(X(TARGET)), py = sy.getPixelForValue(40);
        ctx.save(); ctx.fillStyle = '#b45309'; ctx.font = '700 12px Inter, sans-serif'; ctx.textAlign = 'right';
        ctx.fillText('🎯 40% • 01/7', px - 4, py - 8); ctx.restore();
      } };

      // chiều rộng vùng cuộn: đủ để xem từng ngày tới 01/7
      var totalSpan = X(TARGET) + 2;
      var pxPerDay = 30;
      var innerEl = document.getElementById('c-day-inner');
      if (innerEl) innerEl.style.width = Math.max(720, Math.round(totalSpan * pxPerDay)) + 'px';
      // gradient nền cho đường thực hiện
      var gctx = cv.getContext('2d');
      var grad = gctx.createLinearGradient(0, 0, 0, 300);
      grad.addColorStop(0, 'rgba(22,163,74,.28)'); grad.addColorStop(1, 'rgba(22,163,74,.02)');

      var chart = new Chart(cv, {
        type: 'line',
        data: { datasets: [
          { label: 'Kế hoạch phấn đấu (40% ngày 01/7)', data: goal, borderColor: '#f59e0b', backgroundColor: 'rgba(245,158,11,.06)', borderDash: [9, 6], borderWidth: 3, pointRadius: 0, pointHoverRadius: 6, tension: 0, fill: false, order: 3 },
          { label: 'Kế hoạch đăng ký (theo danh mục)', data: reg, borderColor: '#2563eb', backgroundColor: 'rgba(37,99,235,.05)', borderWidth: 3, pointRadius: 4.5, pointHoverRadius: 7, pointBackgroundColor: '#2563eb', pointBorderColor: '#fff', pointBorderWidth: 2, tension: .3, fill: false, order: 2 },
          { label: 'Kết quả thực hiện thực tế', data: actual, borderColor: '#16a34a', backgroundColor: grad, borderWidth: 4, pointRadius: 5.5, pointHoverRadius: 8, pointBackgroundColor: '#16a34a', pointBorderColor: '#fff', pointBorderWidth: 2.5, tension: .3, fill: true, order: 1 }
        ] },
        options: {
          responsive: true, maintainAspectRatio: false,
          layout: { padding: { top: 10, right: 16, left: 4 } },
          interaction: { mode: 'index', intersect: false },
          plugins: {
            legend: { display: false },
            tooltip: {
              backgroundColor: 'rgba(15,23,42,.92)', titleFont: { size: 13, weight: '700' }, bodyFont: { size: 12.5 }, padding: 11, cornerRadius: 8, displayColors: true, usePointStyle: true,
              callbacks: {
                title: function (items) { return '📅 Ngày ' + fmtD(items[0].raw.t); },
                label: function (c) { return '  ' + c.dataset.label + ': ' + pc(c.raw.y) + ' (' + fmtAmt(c.raw.amt) + ')'; }
              }
            }
          },
          scales: {
            x: { type: 'linear', min: 0, max: X(TARGET) + 1, ticks: { display: false }, grid: { color: '#f1f5f9' }, border: { color: '#e2e8f0' } },
            y: { beginAtZero: true, suggestedMax: 45, ticks: { stepSize: 5, callback: function (v) { return v + '%'; }, font: { size: 12, weight: '600' }, color: '#475569' }, grid: { color: '#eef2f7' }, border: { display: false } }
          }
        },
        plugins: [mark]
      });

      // ----- Chú thích màu (rõ ràng) -----
      var legBox = document.getElementById('c-day-legend');
      if (legBox) {
        legBox.innerHTML = [
          { c: '#f59e0b', dash: 1, t: 'Kế hoạch phấn đấu', d: 'mục tiêu theo từng ngày để đạt 40% vào 01/7/2026' },
          { c: '#2563eb', dash: 0, t: 'Kế hoạch đăng ký', d: 'tổng hợp theo file danh mục' },
          { c: '#16a34a', dash: 0, t: 'Kết quả thực hiện thực tế', d: 'theo báo cáo ngày (Kho bạc), so với KH Thủ tướng giao' }
        ].map(function (it) {
          return '<div class="dl-item"><span class="dl-line' + (it.dash ? ' dash' : '') + '" style="--c:' + it.c + '"></span><span class="dl-tx"><b>' + it.t + '</b> — ' + it.d + '</span></div>';
        }).join('');
      }

      // ----- Hàng ngày/tháng click được (canh theo điểm biểu đồ) -----
      var axisEl = document.getElementById('c-day-axis');
      var scEl = cv.closest ? cv.closest('.day-scroll') : null;
      function highlightDay(xi, px) {
        var acts = [];
        var gi = goal.findIndex(function (p) { return p.x === xi; }); if (gi >= 0) acts.push({ datasetIndex: 0, index: gi });
        var ai = actual.findIndex(function (p) { return p.x === xi; }); if (ai >= 0) acts.push({ datasetIndex: 2, index: ai });
        var ri = reg.findIndex(function (p) { return p.x === xi; }); if (ri >= 0) acts.push({ datasetIndex: 1, index: ri });
        try { chart.setActiveElements(acts); chart.update(); } catch (e) {}
        // Panel chi tiết cố định dưới biểu đồ (đọc tốt trên di động — không tràn)
        var info = document.getElementById('c-day-info'); if (!info) return;
        var t = base + xi * dayMs;
        function findAt(arr) { for (var i2 = 0; i2 < arr.length; i2++) { if (arr[i2].x === xi) return arr[i2]; } return null; }
        function lastBefore(arr) { var b = null; for (var i3 = 0; i3 < arr.length; i3++) { if (arr[i3].x <= xi) b = arr[i3]; } return b; }
        var g = findAt(goal), a = findAt(actual), r = findAt(reg) || lastBefore(reg);
        var rows = '';
        if (g) rows += '<div class="di-row"><span class="di-dot goal"></span><span class="di-lab">Kế hoạch phấn đấu</span><b>' + pc(g.y) + '</b><small>' + vn(Math.round(g.amt)) + ' tr.đ</small></div>';
        rows += '<div class="di-row"><span class="di-dot reg"></span><span class="di-lab">Kế hoạch đăng ký</span>' + (r ? '<b>' + pc(r.y) + '</b><small>' + vn(Math.round(r.amt)) + ' tr.đ' + (r.x !== xi ? ' (lũy kế đến ' + fmtD(r.t) + ')' : '') + '</small>' : '<small>chưa có số liệu</small>') + '</div>';
        rows += '<div class="di-row"><span class="di-dot act"></span><span class="di-lab">Thực hiện thực tế (Kho bạc)</span>' + (a ? '<b>' + pc(a.y) + '</b><small>giải ngân vốn năm 2026: ' + vn(Math.round(a.amtReal || a.amt)) + ' tr.đ' + (a.gnAll && a.gnAll > (a.amtReal || a.amt) ? ' • toàn tỉnh (mọi nguồn): ' + vn(Math.round(a.gnAll)) + ' tr.đ' : '') + '</small>' : '<small>chưa có số liệu ngày này</small>') + '</div>';
        info.innerHTML = '<div class="di-head">📅 Ngày ' + fmtD(t) + ' — tỷ lệ so với KH Thủ tướng giao</div>' + rows
          + '<div class="di-note">Tỷ lệ (%) và số giải ngân tính trên <b>vốn năm 2026</b> theo kế hoạch Thủ tướng giao (' + vn(Math.round(TTg)) + ' tr.đ) — khớp với mục “Tiến độ so kế hoạch giao”. Phần “toàn tỉnh (mọi nguồn)” gồm cả vốn kéo dài 2025 nên lớn hơn.</div>';
        info.classList.add('on');
      }
      function buildAxis() {
        if (!axisEl) return;
        axisEl.innerHTML = '';
        var lastM = null;
        for (var i = 0; i <= totalSpan - 1; i++) {
          var t = base + i * dayMs, d = new Date(t), px = chart.scales.x.getPixelForValue(i);
          if (px == null || isNaN(px)) continue;
          var dd = d.getUTCDate(), mm = d.getUTCMonth() + 1, isM = mm !== lastM;
          var chip = document.createElement('button');
          chip.className = 'day-tick' + (isM ? ' mstart' : '');
          chip.style.left = px + 'px';
          chip.setAttribute('data-x', i);
          chip.title = ('0' + dd).slice(-2) + '/' + ('0' + mm).slice(-2) + '/2026';
          chip.innerHTML = '<span class="dt-d">' + dd + '</span>' + (isM ? '<span class="dt-m">Th' + mm + '</span>' : '');
          lastM = mm;
          (function (xi, pxx, el) {
            el.addEventListener('click', function () {
              if (scEl) scEl.scrollTo({ left: Math.max(0, pxx - scEl.clientWidth / 2), behavior: 'smooth' });
              var prev = axisEl.querySelector('.day-tick.active'); if (prev) prev.classList.remove('active');
              el.classList.add('active');
              highlightDay(xi, pxx);
            });
          })(i, px, chip);
          axisEl.appendChild(chip);
        }
      }
      buildAxis();
      var _rzt;
      window.addEventListener('resize', function () { clearTimeout(_rzt); _rzt = setTimeout(function () { try { chart.resize(); } catch (e) {} buildAxis(); }, 220); });
    })();
  }

  /* ---------- phụ lục giải ngân từng dự án: tải theo ngày ---------- */
  (function () {
    var box = document.getElementById('pl-dlbar'); if (!box) return;
    var files = (LADO_AI.phuluc_files || []).slice().reverse();
    if (!files.length) { box.style.display = 'none'; return; }
    box.innerHTML = '<div class="sx-dlbar pl">📎 <b>Tải phụ lục giải ngân TỪNG DỰ ÁN (Kho bạc):</b> '
      + '<select id="pl-dl-date" class="ld-filter">'
      + files.map(function (f, i) { return '<option value="' + esc(f.url) + '"' + (i === 0 ? ' selected' : '') + '>Ngày ' + esc(f.date) + '</option>'; }).join('')
      + '</select> <a id="pl-dl-btn" class="ld-exp doc" href="' + esc(files[0].url) + '" download>⬇ Tải file (.docx)</a></div>';
    var sel = document.getElementById('pl-dl-date');
    if (sel) sel.addEventListener('change', function () { var b = document.getElementById('pl-dl-btn'); if (b) b.href = sel.value; });
  })();

  /* ---------- daily report download-by-date chooser ---------- */
  (function () {
    var box = document.getElementById('day-dl'); if (!box) return;
    var dls = (LADO_AI.days || []).filter(function (d) { return d.dl; });
    if (!dls.length) { box.style.display = 'none'; return; }
    var opts = dls.slice().reverse().map(function (d) { return '<option value="' + d.idx + '">' + esc(d.date) + '</option>'; }).join('');
    box.innerHTML = '<span class="day-dl-lab">📆 Tải báo cáo theo ngày:</span>'
      + '<select id="day-sel" class="day-sel">' + opts + '</select>'
      + '<button class="day-go" id="day-go">⬇ Tải về</button>';
    document.getElementById('day-go').addEventListener('click', function () {
      var idx = +document.getElementById('day-sel').value;
      startDownload('day_idx', idx);
    });
  })();

  /* ---------- ranking lists ---------- */
  function fillRank(id, arr, bad) {
    var box = document.getElementById(id); if (!box || !arr) return;
    var max = Math.max.apply(null, arr.map(function (x) { return x.tl; }).concat([1]));
    arr.forEach(function (x) {
      var w = Math.max(4, (x.tl / max) * 100);
      box.appendChild(el('<div class="row"><div class="nm">' + unitLink(x.ten) + '</div><div class="bar"><i style="width:' + w + '%"></i></div><div class="pc">' + pc(x.tl) + '</div></div>'));
    });
  }
  fillRank('r-topban', D.top_ban); fillRank('r-botban', D.bottom_ban, true);
  fillRank('r-topxa', D.top_xa); fillRank('r-topso', D.top_so);

  /* ---------- full 0% list ---------- */
  (function () {
    var box = document.getElementById('zero-box'); if (!box) return;
    var so = D.zero_list_so || [], xa = D.zero_list_xa || [];
    var tot = (D.zero && D.zero.tong) || (so.length + xa.length);
    var head = '<div class="zero-head"><span class="zero-stat">Tổng: ' + tot + ' đơn vị</span><span class="zero-stat">Sở, ngành: ' + so.length + '</span><span class="zero-stat">Xã, phường: ' + xa.length + '</span></div>';
    function col(title, arr) {
      var h = '<div class="zero-col"><h4>' + title + ' (' + arr.length + ')</h4><div class="zero-list">';
      if (!arr.length) { h += '<div class="zero-item"><span>—</span></div>'; }
      arr.forEach(function (n, idx) { h += '<div class="zero-item"><span class="i">' + (idx + 1) + '</span><span>' + unitLink(n) + '</span></div>'; });
      return h + '</div></div>';
    }
    box.innerHTML = head + '<div class="zero-grid">' + col('Khối sở, ngành, đơn vị', so) + col('Khối xã, phường, đặc khu', xa) + '</div>';
  })();

  /* ---------- stats popup modal ---------- */
  var modal = document.getElementById('lado-modal');
  function openModal(title, items) {
    document.getElementById('lm-title').textContent = title;
    var b = document.getElementById('lm-body');
    if (!items || !items.length) { b.innerHTML = '<p class="hint" style="margin:0">Không có đơn vị nào.</p>'; }
    else {
      b.innerHTML = '<ol class="lm-list">' + items.map(function (n) { return '<li>' + unitLink(n) + '</li>'; }).join('') + '</ol>';
    }
    modal.classList.add('on');
  }
  document.getElementById('lm-x').addEventListener('click', function () { modal.classList.remove('on'); });
  modal.addEventListener('click', function (e) { if (e.target === modal) modal.classList.remove('on'); });

  /* ---------- chủ đầu tư popup (dự án + liên hệ) ---------- */
  (function () {
    if (!DV_ON) return;
    var umodal = document.getElementById('lado-unit');
    var unitsCache = null, unitIndex = null, contactsCache = null, contactIndex = null, bigZero = null, loading = false, pending = null, phulucCache = null, phulucIndex = null;
    function phulucOf(ten) {
      if (!phulucCache || !phulucCache.units) return null;
      if (!phulucIndex) {
        phulucIndex = {};
        (phulucCache.units || []).forEach(function (u) { phulucIndex[unrm(u.ten)] = u; });
      }
      return phulucIndex[unrm(ten || '')] || null;
    }

    // Tách vốn theo chủ đầu tư: gộp kh25/gn25/kh26/gn26 từ dự án trong báo cáo Tổ công tác
    var _cdtSplitMap = null;
    function buildCdtSplit() {
      _cdtSplitMap = {};
      var T = (D.tct && D.tct.tos) ? D.tct.tos : [];
      T.forEach(function (to) {
        (to.nhom || []).forEach(function (g) {
          (g.projects || []).forEach(function (p) {
            var key = unrm(p.cdt || '');
            if (!key) return;
            var m = _cdtSplitMap[key] || { kh25: 0, gn25: 0, kh26: 0, gn26: 0, kh: 0, gn: 0, n: 0 };
            m.kh25 += (+p.kh25 || 0); m.gn25 += (+p.gn25 || 0);
            m.kh26 += (+p.kh26 || 0); m.gn26 += (+p.gn26 || 0);
            m.kh += (+p.kh || 0); m.gn += (+p.gn || 0); m.n++;
            _cdtSplitMap[key] = m;
          });
        });
      });
    }
    function cdtSplit(ten) {
      if (_cdtSplitMap === null) buildCdtSplit();
      var m = _cdtSplitMap[unrm(ten || '')];
      if (m && (m.kh25 > 0 || m.kh26 > 0 || m.gn25 > 0 || m.gn26 > 0)) return m;
      return null;
    }

    // --- khớp gần đúng theo token đặc trưng (xử lý viết tắt: KV/Khu vực, QLDA/Quản lý dự án...) ---
    var STOP = {ban:1,quan:1,ly:1,du:1,an:1,dau:1,tu:1,xay:1,dung:1,so:1,nganh:1,don:1,vi:1,
      ubnd:1,hdnd:1,xa:1,phuong:1,dac:1,khu:1,vuc:1,trung:1,tam:1,cong:1,ty:1,tnhh:1,mtv:1,
      phong:1,van:1,va:1,cua:1,tinh:1,huyen:1,thanh:1,pho:1,thi:1,tran:1,kinh:1,te:1,ha:1,
      tang:1,do:1,ke:1,hoach:1,dich:1,vu:1,tong:1,hop:1,lam:1,nghiep:1,bql:1,ql:1,dtxd:1,
      qlda:1,qlrph:1,kv:1,bộ:1,bo:1,chi:1,huy:1,uy:1,cdt:1};
    var EXP = {kv:'khu vuc',qlda:'quan ly du an',dtxd:'dau tu xay dung',qlrph:'quan ly rung phong ho',
      bql:'ban quan ly',tp:'thanh pho',tt:'thi tran',bch:'ban chi huy'};
    function toks(name) {
      var s = unrm(name).split(' '), out = [];
      for (var i = 0; i < s.length; i++) {
        var t = s[i]; if (!t) continue;
        (EXP[t] || t).split(' ').forEach(function (x) { if (x) out.push(x); });
      }
      return out;
    }
    function tokSets(name) {
      var all = {}, dist = {};
      toks(name).forEach(function (t) { all[t] = 1; if (!STOP[t]) dist[t] = 1; });
      return {all: all, dist: dist};
    }
    function buildIdx(map) {
      var arr = [];
      Object.keys(map || {}).forEach(function (k) {
        var ts = tokSets((map[k] && map[k].ten) || k);
        arr.push({key: k, all: ts.all, dist: ts.dist});
      });
      return arr;
    }
    function fuzzyIn(idx, name, minJ) {
      if (!idx) return null;
      minJ = minJ || 0.4;
      var ts = tokSets(name);
      var distArr = Object.keys(ts.dist), allArr = Object.keys(ts.all);
      if (!distArr.length) return null;
      var best = null, bestJ = 0, bestD = 0;
      idx.forEach(function (it) {
        var d = 0; distArr.forEach(function (t) { if (it.dist[t]) d++; });
        if (!d) return; // phải có ít nhất 1 token đặc trưng chung
        var uni = {}, inter = 0;
        allArr.forEach(function (t) { uni[t] = 1; });
        Object.keys(it.all).forEach(function (t) { uni[t] = 1; });
        allArr.forEach(function (t) { if (it.all[t]) inter++; });
        var j = inter / Object.keys(uni).length; // Jaccard trên TOÀN BỘ token
        if (j > bestJ || (j === bestJ && d > bestD)) { bestJ = j; bestD = d; best = it.key; }
      });
      return (bestJ >= minJ) ? best : null;
    }
    function lookup(key, name) {
      if (!unitIndex) unitIndex = buildIdx(unitsCache);
      var u = unitsCache[key];
      if (!u && name) { var fk = fuzzyIn(unitIndex, name, 0.38); if (fk) u = unitsCache[fk]; }
      return u;
    }
    function getContact(name) {
      if (!contactsCache) return null;
      var c = contactsCache[unrm(name)];
      if (c) return c;
      if (!contactIndex) contactIndex = buildIdx(contactsCache);
      var fk = fuzzyIn(contactIndex, name, 0.5); // liên hệ: yêu cầu khớp chặt hơn để tránh nhầm
      return fk ? contactsCache[fk] : null;
    }

    document.getElementById('lu-x').addEventListener('click', function () { umodal.classList.remove('on'); });
    umodal.addEventListener('click', function (e) { if (e.target === umodal) umodal.classList.remove('on'); });

    function moneyTr(n){ return vn(n); }
    function personRow(label, val, phone) {
      val = (val || '').trim();
      var name = val, role = '';
      var m = val.split(/\s*[—–-]\s+/);
      if (m.length > 1) { name = m[0].trim(); role = m.slice(1).join(' — ').trim(); }
      var tel = phone ? '<a class="lu-tel" href="tel:' + esc(('' + phone).replace(/\s/g, '')) + '">📞 ' + esc(phone) + '</a>' : '';
      return '<div class="lu-person"><span class="lu-role">' + esc(label) + '</span>'
        + '<div class="lu-pmain"><span class="lu-pn">' + esc(name) + '</span>'
        + (role ? '<span class="lu-prole">' + esc(role) + '</span>' : '') + '</div>'
        + tel + '</div>';
    }
    function contactHtml(c) {
      if (!c) return '<div class="lu-contact lu-nocontact">Chưa có thông tin liên hệ trong danh bạ.</div>';
      var h = '<div class="lu-contact">';
      if (c.bithu || c.chutich) {
        if (c.bithu) h += personRow('Bí thư', c.bithu, c.bithu_phone);
        if (c.chutich) h += personRow('Chủ tịch', c.chutich, c.chutich_phone);
      } else if (c.head) {
        h += personRow('Người đứng đầu', c.head, c.head_phone);
      } else {
        h += '<div class="lu-nocontact">Chưa có thông tin liên hệ.</div>';
      }
      return h + '</div>';
    }
    // Số chính thức (Kho bạc) của đơn vị từ bảng chi tiết báo cáo ngày
    function officialOf(ten) {
      var k = unrm(ten || '');
      if (!k) return null;
      var lists = [D.all_ban, D.all_so, D.all_xa];
      for (var i = 0; i < lists.length; i++) {
        var arr = lists[i] || [];
        for (var j = 0; j < arr.length; j++) {
          if (unrm(arr[j].ten) === k) return arr[j];
        }
      }
      return null;
    }
    function render(u) {
      var t = document.getElementById('lu-title');
      var b = document.getElementById('lu-body');
      var khoiBadge = u.khoi ? '<span class="lu-badge">' + esc(u.khoi) + '</span>' : '';
      t.innerHTML = '<div class="lu-name">🏢 ' + esc(fullCDT(u.ten || 'Đơn vị')) + '</div>' + khoiBadge;
      var html = '';
      var off = officialOf(u.ten || '');
      var pl = phulucOf(u.ten || '');
      var hd = pl ? { kh: pl.kh, gn: pl.gn, tl: pl.tl, as: (phulucCache && phulucCache.as_of) || '' } : (off ? { kh: off.kh, gn: off.gn, tl: off.tl, as: D.as_of || '' } : null);
      if (hd) {
        html += '<div class="lu-official"><div class="lu-of-h">🏦 Số liệu Kho bạc Nhà nước — chính thức' + (hd.as ? ', đến ' + esc(hd.as) : '') + '</div>'
          + '<div class="lu-of-row">'
          + '<div class="lu-of-item"><span>Kế hoạch vốn</span><b>' + moneyTr(hd.kh) + '</b></div>'
          + '<div class="lu-of-item"><span>Đã giải ngân</span><b class="gn">' + moneyTr(hd.gn) + '</b></div>'
          + '<div class="lu-of-item"><span>Tỷ lệ</span><b class="tl">' + pc(hd.tl) + '</b></div>'
          + '</div></div>';
      }
      // Phân theo nguồn vốn (2025 kéo dài / 2026) — kèm giải ngân, gộp từ báo cáo Tổ công tác
      var sp = cdtSplit(u.ten || '');
      if (sp) {
        var spTl = function (g, k) { return k > 0 ? pc(Math.round(g / k * 10000) / 100) : '—'; };
        // Ưu tiên KH tổng theo phụ lục (chính thức) nếu có; nếu lệch nhỏ với tổng tách thì vẫn hiển thị tách
        var totKh = sp.kh, totGn = sp.gn;
        html += '<div class="lu-split lu-split-cdt"><div class="lu-split-h">💧 Phân theo nguồn vốn (' + sp.n + ' dự án trong Tổ công tác)</div>'
          + '<table class="lu-split-tbl"><thead><tr><th>Nguồn vốn</th><th class="r">Kế hoạch</th><th class="r">Đã giải ngân</th><th class="r">Tỷ lệ</th></tr></thead><tbody>'
          + '<tr><td>Vốn 2025 kéo dài</td><td class="r">' + moneyTr(sp.kh25) + '</td><td class="r">' + moneyTr(sp.gn25) + '</td><td class="r">' + spTl(sp.gn25, sp.kh25) + '</td></tr>'
          + '<tr><td>Vốn năm 2026</td><td class="r">' + moneyTr(sp.kh26) + '</td><td class="r">' + moneyTr(sp.gn26) + '</td><td class="r">' + spTl(sp.gn26, sp.kh26) + '</td></tr>'
          + '<tr class="lu-split-sum"><td>Tổng kế hoạch</td><td class="r"><b>' + moneyTr(totKh) + '</b></td><td class="r"><b>' + moneyTr(totGn) + '</b></td><td class="r"><b>' + spTl(totGn, totKh) + '</b></td></tr>'
          + '</tbody></table>'
          + '<div class="lu-split-note">Vốn năm 2026 hiện chưa phân khai cho các dự án thuộc chương trình mục tiêu quốc gia; phần đó đang nằm ở cột vốn 2025 kéo dài.</div></div>';
      }
      html += contactHtml(u.contact || getContact(u.ten || ''));
      var ps = u.projects || [];
      var exportRows = null, exportName = 'Du_an';
      if (pl && pl.projects && pl.projects.length) {
        // ----- BẢNG CHÍNH: số Kho bạc theo từng dự án (phụ lục), kèm cột đối chiếu tự nhập -----
        var dmMap = {};
        ps.forEach(function (p) { dmMap[unrm(p.ten)] = (+p.gn || 0); });
        var hasDm = ps.length > 0;
        var sKh = 0, sGn = 0, sDm = 0, nDm = 0;
        html += '<div class="lu-projhead">📊 Giải ngân từng dự án — Kho bạc (' + pl.projects.length + ' dự án) <button class="lu-xls" id="lu-xls" title="Xuất ra Excel">⬇ Xuất Excel</button></div>';
        if (hasDm) html += '<div class="lu-selfnote">📝 Cột <b>"Tự nhập (DM)"</b> là số do đơn vị tự nhập trong danh mục tuần — chỉ để <b>đối chiếu</b>; ô <span class="lu-dm-diff">vàng</span> là dự án có chênh lệch so với Kho bạc.</div>';
        html += '<div class="lu-tablewrap"><table class="lu-table"><thead><tr><th>Tên dự án / Mã DA</th><th class="r">KH vốn</th><th class="r">Giải ngân<br><small>Kho bạc</small></th><th class="r">Tỷ lệ</th>' + (hasDm ? '<th class="r">Tự nhập<br><small>(DM)</small></th>' : '') + '</tr></thead><tbody>';
        pl.projects.forEach(function (p) {
          sKh += (+p.kh || 0); sGn += (+p.gn || 0);
          var dmCell = '';
          if (hasDm) {
            var k = unrm(p.ten);
            if (k in dmMap) {
              var dv2 = dmMap[k]; sDm += dv2; nDm++;
              var dd2 = Math.round((+p.gn || 0) - dv2);
              dmCell = Math.abs(dd2) < 1
                ? '<td class="r lu-dm-eq">✓ khớp</td>'
                : '<td class="r lu-dm-diff" title="Chênh ' + (dd2 > 0 ? '+' : '−') + vn(Math.abs(dd2)) + ' tr.đ so với Kho bạc">' + moneyTr(dv2) + '<small>' + (dd2 > 0 ? '−' : '+') + vn(Math.abs(dd2)) + '</small></td>';
            } else { dmCell = '<td class="r lu-dm-na">—</td>'; }
          }
          html += '<tr><td>' + esc(p.ten) + (p.ma && p.ma !== '-' ? '<span class="lu-ma">Mã DA: ' + esc(p.ma) + '</span>' : '') + '</td>'
            + '<td class="r">' + moneyTr(p.kh) + '</td><td class="r"><b>' + moneyTr(p.gn) + '</b></td>'
            + '<td class="r"><span class="lu-pc">' + esc(p.tl || '—') + '</span></td>' + dmCell + '</tr>';
        });
        html += '</tbody><tfoot><tr><td>TỔNG (' + pl.projects.length + ' dự án)</td><td class="r">' + moneyTr(sKh) + '</td><td class="r">' + moneyTr(sGn) + '</td><td class="r">' + (sKh > 0 ? pc(sGn / sKh * 100) : '—') + '</td>' + (hasDm ? '<td class="r">' + (nDm ? moneyTr(sDm) : '—') + '</td>' : '') + '</tr></tfoot></table></div>';
        if (hasDm && nDm) {
          var diffT = Math.round(sGn - sDm);
          var clsT = Math.abs(diffT) < 1 ? 'eq' : (diffT > 0 ? 'up' : 'down');
          html += '<div class="lu-compare ' + clsT + '">🔁 <b>Đối chiếu tổng giải ngân:</b> Kho bạc <b>' + moneyTr(sGn) + '</b> • Tự nhập (danh mục) <b>' + moneyTr(sDm) + '</b> → ' + (Math.abs(diffT) < 1 ? '✓ Khớp' : ('chênh <b>' + (diffT > 0 ? '+' : '−') + vn(Math.abs(diffT)) + ' tr.đ</b> (Kho bạc ' + (diffT > 0 ? 'cao hơn' : 'thấp hơn') + ')')) + '</div>';
        }
        html += '<div class="lu-unit-note">Đơn vị: triệu đồng • Nguồn chính: Phụ lục kết quả giải ngân từng dự án (Kho bạc, theo mã dự án)' + (hd && hd.as ? ', đến ' + esc(hd.as) : '') + '.</div>';
        html += '<div class="lu-disclaimer">⚠️ <b>Lưu ý:</b> Số giải ngân từng dự án lấy theo <b>Kho bạc Nhà nước</b> (chính thức). Cột "Tự nhập (DM)" do đơn vị tự cập nhật trong danh mục tuần, chỉ dùng để đối chiếu; nếu chênh lệch, lấy theo số Kho bạc.</div>';
        exportRows = pl.projects.map(function (p, i) {
          var row = { 'TT': i + 1, 'Tên dự án': p.ten, 'Mã dự án': p.ma || '', 'KH vốn (tr.đ)': (+p.kh || 0), 'Giải ngân Kho bạc (tr.đ)': (+p.gn || 0), 'Tỷ lệ': (p.tl || '') };
          if (hasDm) { var k2 = unrm(p.ten); row['Tự nhập DM (tr.đ)'] = (k2 in dmMap) ? dmMap[k2] : ''; }
          return row;
        });
        exportName = 'PhuLuc_KhoBac_';
      } else if (ps.length) {
        var sumKh = 0, sumGn = 0;
        ps.forEach(function (p) { sumKh += (+p.kh || 0); sumGn += (+p.gn || 0); });
        html += '<div class="lu-projhead">📁 Danh mục dự án (' + ps.length + ') <button class="lu-xls" id="lu-xls" title="Xuất danh mục dự án ra Excel">⬇ Xuất Excel</button></div>';
        html += '<div class="lu-selfnote">📝 Số liệu từng dự án dưới đây theo <b>danh mục kế hoạch giải ngân tuần</b> do <b>đơn vị tự nhập</b> — chỉ dùng để <b>đối chiếu</b>, không phải số chính thức.</div>';
        html += '<div class="lu-tablewrap"><table class="lu-table"><thead><tr><th>Tên dự án</th><th class="r">KH vốn</th><th class="r">Giải ngân <span class="lu-tag">tự nhập</span></th><th class="r">Tỷ lệ</th></tr></thead><tbody>';
        ps.forEach(function (p) {
          html += '<tr><td>' + esc(p.ten) + '</td><td class="r">' + moneyTr(p.kh) + '</td><td class="r">' + moneyTr(p.gn) + '</td><td class="r"><span class="lu-pc">' + esc(p.tl || '—') + '</span></td></tr>';
        });
        html += '</tbody><tfoot><tr><td>TỔNG THEO DANH MỤC (' + ps.length + ' dự án)</td><td class="r">' + moneyTr(sumKh) + '</td><td class="r">' + moneyTr(sumGn) + '</td><td class="r">' + (sumKh > 0 ? pc(sumGn / sumKh * 100) : '—') + '</td></tr></tfoot></table></div>';
        if (off) {
          var diff = Math.round((+off.gn || 0) - sumGn);
          var cls = Math.abs(diff) < 1 ? 'eq' : (diff > 0 ? 'up' : 'down');
          var txt = Math.abs(diff) < 1
            ? '✓ Khớp với số liệu Kho bạc'
            : ('Kho bạc ' + (diff > 0 ? 'cao hơn' : 'thấp hơn') + ' danh mục <b>' + vn(Math.abs(diff)) + ' tr.đ</b>');
          html += '<div class="lu-compare ' + cls + '">🔁 <b>Đối chiếu giải ngân:</b> Kho bạc <b>' + moneyTr(off.gn) + '</b> • Danh mục (tự nhập) <b>' + moneyTr(sumGn) + '</b> → ' + txt + '</div>';
        }
        html += '<div class="lu-unit-note">Đơn vị: triệu đồng • Danh mục: đơn vị tự nhập theo tuần • Kho bạc: số chính thức theo ngày.</div>';
        html += '<div class="lu-disclaimer">⚠️ <b>Lưu ý:</b> Số liệu giải ngân trong danh mục dự án do đơn vị tự nhập theo tuần nên có thể <b>chênh lệch</b> với số liệu chính thức từ Kho bạc Nhà nước (cập nhật hằng ngày, hiển thị ở khung phía trên). Khi có khác biệt, <b>lấy theo số Kho bạc</b>; phần danh mục chỉ để đối chiếu chi tiết từng dự án.</div>';
        exportRows = ps.map(function (p, i) {
          return { 'TT': i + 1, 'Tên dự án': p.ten, 'KH vốn (tr.đ)': (+p.kh || 0), 'Giải ngân (tr.đ)': (+p.gn || 0), 'Tỷ lệ': (p.tl || '0%') };
        });
        exportName = 'Du_an_';
      } else {
        html += '<div class="lu-noproj">Không có dữ liệu danh mục dự án cho đơn vị này.</div>';
      }
      b.innerHTML = html;
      var xb = document.getElementById('lu-xls');
      if (xb) xb.addEventListener('click', function () {
        if (!exportRows || !exportRows.length) { alert('Không có dữ liệu để xuất.'); return; }
        ladoExportXlsx(exportRows, exportName + (u.ten || 'CDT').replace(/[^\wÀ-ỹ]+/g, '_').substring(0, 40), 'Dự án');
      });
      umodal.classList.add('on');
    }

    function applyData(j) {
      unitsCache = (j && j.success && j.data && j.data.units) ? j.data.units : {};
      contactsCache = (j && j.success && j.data && j.data.contacts) ? j.data.contacts : {};
      if (j && j.success && j.data && j.data.big_zero) { bigZero = j.data.big_zero; }
      phulucCache = (j && j.success && j.data && j.data.phuluc) || (LADO_AI.donvi && LADO_AI.donvi.phuluc) || null;
      phulucIndex = null;
      unitIndex = null; contactIndex = null;
    }
    function ensureData(cb) {
      if (unitsCache) { cb(); return; }
      var fd = new FormData();
      fd.append('action', 'lado_donvi'); fd.append('nonce', LADO_AI.nonce);
      fetch(LADO_AI.ajax, { method: 'POST', body: fd, credentials: 'same-origin' })
        .then(function (r) { return r.json(); })
        .then(function (j) { applyData(j); cb(); })
        .catch(function () { unitsCache = unitsCache || {}; contactsCache = contactsCache || {}; cb(); });
    }

    function show(key, name) {
      ensureData(function () {
        var u = lookup(key, name);
        if (!u) {
          var cc = getContact(name || '');
          if (cc) { render({ ten: name, khoi: '', projects: [], contact: cc }); return; }
          document.getElementById('lu-title').innerHTML = '<div class="lu-name">' + esc(name || 'Không tìm thấy') + '</div>';
          document.getElementById('lu-body').innerHTML = '<div class="lu-noproj">Chưa có dữ liệu chi tiết cho đơn vị này. Vui lòng nhập file Excel danh mục dự án và danh bạ trong trang quản trị.</div>';
          umodal.classList.add('on');
          return;
        }
        render(u);
      });
      if (!unitsCache) {
        document.getElementById('lu-title').innerHTML = '<div class="lu-name">Đang tải…</div>';
        document.getElementById('lu-body').innerHTML = '<div class="lu-loading"><div class="lado-spinner"></div></div>';
        umodal.classList.add('on');
      }
    }

    // popup chi tiết MỘT dự án THUỘC TỔ CÔNG TÁC (số Kho bạc + đối chiếu tự nhập + vướng mắc + kiến nghị)
    var knCache = null;
    function ensureKn(cb) {
      if (knCache) { cb(); return; }
      var fd = new FormData();
      fd.append('action', 'lado_kiennghi'); fd.append('nonce', LADO_AI.nonce);
      fetch(LADO_AI.ajax, { method: 'POST', body: fd, credentials: 'same-origin' })
        .then(function (r) { return r.json(); })
        .then(function (j) { knCache = (j && j.success && j.data && j.data.items) || []; cb(); })
        .catch(function () { knCache = []; cb(); });
    }
    window.__ladoTctProj = function (p, ctx) {
      ctx = ctx || {};
      var t = document.getElementById('lu-title'), b = document.getElementById('lu-body');
      t.innerHTML = '<div class="lu-name">💰 ' + esc(p.ten || 'Dự án') + '</div>' + (ctx.to ? '<span class="lu-badge">Tổ ' + ctx.to + '</span>' : '');
      var tlNum = parseFloat(String(p.tl || '').replace('%', '').replace(/\./g, '').replace(',', '.'));
      if (!isFinite(tlNum)) tlNum = (p.kh > 0 ? p.gn / p.kh * 100 : 0);
      var html = '<div class="lu-official"><div class="lu-of-h">🏦 Kho bạc Nhà nước' + (ctx.as ? ' — đến ' + esc(ctx.as) : '') + '</div>'
        + '<div class="lu-of-row">'
        + '<div class="lu-of-item"><span>Tổng KH vốn</span><b>' + vn(p.kh) + '</b></div>'
        + '<div class="lu-of-item"><span>Đã giải ngân</span><b class="gn">' + vn(p.gn) + '</b></div>'
        + '<div class="lu-of-item"><span>Tỷ lệ</span><b class="tl">' + esc(p.tl && p.tl !== '-' ? p.tl : pc(tlNum)) + '</b></div>'
        + '</div>'
        + '<div class="lu-progbar"><i style="width:' + Math.max(2, Math.min(100, tlNum)) + '%"></i></div></div>';
      // Tách vốn năm 2025 kéo dài / vốn năm 2026 (nếu báo cáo Tổ có dữ liệu)
      var has25 = (+p.kh25 || 0) > 0 || (+p.gn25 || 0) > 0;
      var has26 = (+p.kh26 || 0) > 0 || (+p.gn26 || 0) > 0;
      if (has25 || has26) {
        var pct = function (g, k) { return k > 0 ? pc(Math.round(g / k * 10000) / 100) : '—'; };
        html += '<div class="lu-split"><div class="lu-split-h">Phân theo nguồn vốn</div><table class="lu-split-tbl"><thead><tr><th>Nguồn</th><th class="r">Kế hoạch</th><th class="r">Đã giải ngân</th><th class="r">Tỷ lệ</th></tr></thead><tbody>'
          + '<tr><td>Vốn 2025 kéo dài</td><td class="r">' + vn(+p.kh25 || 0) + '</td><td class="r">' + vn(+p.gn25 || 0) + '</td><td class="r">' + pct(+p.gn25 || 0, +p.kh25 || 0) + '</td></tr>'
          + '<tr><td>Vốn năm 2026</td><td class="r">' + vn(+p.kh26 || 0) + '</td><td class="r">' + vn(+p.gn26 || 0) + '</td><td class="r">' + pct(+p.gn26 || 0, +p.kh26 || 0) + '</td></tr>'
          + '<tr class="lu-split-sum"><td>Tổng kế hoạch</td><td class="r"><b>' + vn(p.kh) + '</b></td><td class="r"><b>' + vn(p.gn) + '</b></td><td class="r"><b>' + esc(p.tl && p.tl !== '-' ? p.tl : pc(tlNum)) + '</b></td></tr>'
          + '</tbody></table></div>';
      }
      if (p.ma && p.ma !== '-') html += '<div class="lu-kvline"><b>Mã dự án:</b> ' + esc(p.ma) + '</div>';
      if (p.cdt) html += '<div class="lu-kvline"><b>Chủ đầu tư:</b> ' + unitLink(p.cdt) + ' <small class="lu-hintsm">(bấm để xem đơn vị)</small></div>';
      if (ctx.nhom) html += '<div class="lu-kvline"><b>Nhóm vướng mắc:</b> <span class="tct-nbadge n' + (ctx.nhomSo || 1) + '">' + esc(ctx.nhom) + '</span></div>';
      if (p.vm) html += '<div class="lu-vmbox">⚠️ <b>Vướng mắc cụ thể:</b> ' + esc(p.vm) + '</div>';
      html += '<div id="lu-dm-slot"></div><div id="lu-kn-slot"></div>';
      html += '<div class="lu-unit-note">Đơn vị: triệu đồng • Giải ngân theo Kho bạc Nhà nước; mục "Tự nhập (DM)" do đơn vị tự nhập trong danh mục tuần, chỉ để đối chiếu.</div>';
      b.innerHTML = html;
      umodal.classList.add('on');
      // Đối chiếu tự nhập (danh mục) — nạp async
      ensureData(function () {
        var slot = document.getElementById('lu-dm-slot'); if (!slot) return;
        var u = unitsCache ? unitsCache[unrm(p.cdt || '')] : null;
        var dm = null;
        if (u && u.projects) {
          var pk = unrm(p.ten);
          for (var i = 0; i < u.projects.length; i++) { if (unrm(u.projects[i].ten) === pk) { dm = (+u.projects[i].gn || 0); break; } }
        }
        if (dm == null) { slot.innerHTML = '<div class="lu-compare">🔁 <b>Tự nhập (danh mục):</b> chưa có dữ liệu đối chiếu cho dự án này.</div>'; return; }
        var diff = Math.round((+p.gn || 0) - dm);
        var cls = Math.abs(diff) < 1 ? 'eq' : (diff > 0 ? 'up' : 'down');
        slot.innerHTML = '<div class="lu-compare ' + cls + '">🔁 <b>Đối chiếu giải ngân:</b> Kho bạc <b>' + vn(p.gn) + '</b> • Tự nhập (DM) <b>' + vn(dm) + '</b> → '
          + (Math.abs(diff) < 1 ? '✓ Khớp' : ('chênh <b>' + (diff > 0 ? '+' : '−') + vn(Math.abs(diff)) + ' tr.đ</b> (Kho bạc ' + (diff > 0 ? 'cao hơn' : 'thấp hơn') + ')')) + '</div>';
      });
      // Kiến nghị, đề xuất của dự án — nạp async
      ensureKn(function () {
        var slot = document.getElementById('lu-kn-slot'); if (!slot) return;
        var pk = unrm(p.ten);
        var hits = (knCache || []).filter(function (x) { return unrm(x.du_an || '') === pk; });
        if (!hits.length) { slot.innerHTML = ''; return; }
        var h = '<div class="lu-knbox"><div class="lu-knh">💡 Kiến nghị, đề xuất (' + hits.length + ')</div>';
        hits.slice(0, 3).forEach(function (x) {
          h += '<div class="lu-knitem">';
          if (x.kho_khan && (!p.vm || String(x.kho_khan).length > String(p.vm).length + 5)) h += '<div><b>Khó khăn (đầy đủ):</b> ' + esc(x.kho_khan) + '</div>';
          if (x.kien_nghi) h += '<div><b>Kiến nghị:</b> ' + esc(x.kien_nghi) + '</div>';
          if (x.tham_quyen) h += '<div><b>Thẩm quyền giải quyết:</b> ' + esc(x.tham_quyen) + '</div>';
          if (x.thoi_gian) h += '<div><b>Thời gian hoàn thành:</b> ' + esc(xlDate(x.thoi_gian)) + '</div>';
          h += '</div>';
        });
        h += '</div>';
        slot.innerHTML = h;
      });
    };

    // popup chi tiết MỘT dự án (dùng cho bảng dự án vốn lớn 0%)
    function showProject(p) {
      ensureData(function () {
        var t = document.getElementById('lu-title'), b = document.getElementById('lu-body');
        t.innerHTML = '<div class="lu-name">💰 ' + esc(p.ten || 'Dự án') + '</div>' + (p.khoi ? '<span class="lu-badge">' + esc(p.khoi) + '</span>' : '');
        var c = getContact(p.cdt || '');
        var h = '<div class="lu-projhead">🏢 Chủ đầu tư</div><div class="lu-cdt">' + esc(p.cdt || '—') + '</div>';
        h += contactHtml(c);
        h += '<div class="lu-projhead">📊 Thông tin dự án</div>';
        h += '<table class="lu-table lu-kv"><tbody>'
          + '<tr><td>Kế hoạch vốn</td><td class="r"><b>' + vn(p.kh) + '</b> tr.đ</td></tr>'
          + '<tr><td>Đã giải ngân</td><td class="r">0 tr.đ</td></tr>'
          + '<tr><td>Tỷ lệ</td><td class="r"><span class="lu-pc r0">0%</span></td></tr>'
          + (p.nhom ? '<tr><td>Nhóm khó khăn</td><td class="r">' + esc(p.nhom) + '</td></tr>' : '')
          + '</tbody></table>';
        if (p.kho_khan) { h += '<div class="lu-projhead">⚠️ Khó khăn, vướng mắc</div><div class="lu-text">' + esc(p.kho_khan) + '</div>'; }
        if (p.kien_nghi) { h += '<div class="lu-projhead">💡 Kiến nghị</div><div class="lu-text">' + esc(p.kien_nghi) + '</div>'; }
        if (p.tham_quyen) { h += '<div class="lu-kvline"><b>Cấp thẩm quyền:</b> ' + esc(p.tham_quyen) + '</div>'; }
        if (p.thoi_gian) { h += '<div class="lu-kvline"><b>Thời gian dự kiến:</b> ' + esc(xlDate(p.thoi_gian)) + '</div>'; }
        if (!p.kho_khan && !p.kien_nghi) { h += '<div class="lu-unit-note">Chưa có thông tin khó khăn/kiến nghị kèm theo cho dự án này.</div>'; }
        b.innerHTML = h;
        umodal.classList.add('on');
      });
    }

    // bảng "dự án vốn lớn nhưng 0%"
    (function () {
      var box = document.getElementById('bigzero-box'); if (!box) return;
      // NGUỒN CHÍNH: phụ lục Kho bạc (giải ngân thực tế theo từng dự án); dự phòng: danh mục Excel tự nhập
      var bzKB = (LADO_AI.donvi && LADO_AI.donvi.big_zero_kb) || [];
      var bzSrcKB = bzKB.length > 0;
      var all = bzSrcKB ? bzKB : ((LADO_AI.donvi && LADO_AI.donvi.big_zero) || bigZero || []);
      var bzAsof = bzSrcKB ? ((LADO_AI.donvi && LADO_AI.donvi.big_zero_kb_asof) || '') : '';
      if (!all.length) {
        box.innerHTML = '<p class="hint" style="margin:0">Chưa có dữ liệu. Vui lòng nhập file Excel danh mục dự án trong trang quản trị.</p>';
        var bc = document.getElementById('sec-bigzero'); if (bc) bc.style.display = 'none';
        return;
      }
      bigZero = all;
      all = all.slice().sort(function (a, b) { return (+b.kh || 0) - (+a.kh || 0); });
      var bzProv = (+tong.kh || 0);

      // các giá trị lọc
      var khois = []; all.forEach(function (p) { if (p.khoi && khois.indexOf(p.khoi) < 0) khois.push(p.khoi); });
      var fKhoi = '', fCdt = '', limit = 50, page = 0, view = [], fQ = '', psz = 10;

      function cdtOptions() {
        var seen = {}, opts = ['<option value="">Tất cả chủ đầu tư</option>'];
        all.forEach(function (p) {
          if (fKhoi && p.khoi !== fKhoi) return;
          var c = p.cdt || ''; if (!c || seen[c]) return; seen[c] = 1;
          opts.push('<option value="' + esc(c) + '"' + (c === fCdt ? ' selected' : '') + '>' + esc(fullCDT(c)) + '</option>');
        });
        return opts.join('');
      }
      function controls() {
        var ko = ['<option value="">Tất cả nhóm CĐT</option>'].concat(khois.map(function (k) {
          return '<option value="' + esc(k) + '"' + (k === fKhoi ? ' selected' : '') + '>' + esc(k) + '</option>';
        })).join('');
        var counts = [10, 20, 30, 50, 80, 100], co = counts.map(function (n) {
          return '<option value="' + n + '"' + (limit === n ? ' selected' : '') + '>' + n + ' dự án</option>';
        }).join('') + '<option value="all"' + (limit === 'all' ? ' selected' : '') + '>Tất cả</option>';
        var pszs = [10, 20, 30, 50, 100], po = pszs.map(function (n) {
          return '<option value="' + n + '"' + (psz === n ? ' selected' : '') + '>' + n + ' DA/trang</option>';
        }).join('');
        return '<input type="search" id="bz-q" class="tct-q" placeholder="🔍 Tìm tên dự án hoặc chủ đầu tư…" value="' + esc(fQ) + '">'
          + '<div class="bz-controls">'
          + '<div class="bz-field"><label>🏷️ Nhóm chủ đầu tư</label><select id="bz-khoi" class="bz-sel">' + ko + '</select></div>'
          + '<div class="bz-field"><label>🏛️ Chủ đầu tư</label><select id="bz-cdt" class="bz-sel">' + cdtOptions() + '</select></div>'
          + '<div class="bz-field"><label>🔢 Số dự án hiển thị</label><select id="bz-count" class="bz-sel">' + co + '</select></div>'
          + '<div class="bz-field"><label>✏️ Hoặc nhập số</label><input type="number" id="bz-num" class="bz-num" min="1" placeholder="VD: 150"></div>'
          + '<div class="bz-field"><label>📄 Số dự án / trang</label><select id="bz-psz" class="bz-sel">' + po + '</select></div>'
          + '<div class="bz-field bz-field-btn"><label>&nbsp;</label><button id="bz-xls" class="bz-xls-btn">⬇ Xuất Excel</button></div>'
          + '</div>';
      }
      function compute() {
        var q = unrm(fQ);
        var f = all.filter(function (p) {
          if (fKhoi && p.khoi !== fKhoi) return false;
          if (fCdt && (p.cdt || '') !== fCdt) return false;
          if (q && !p.__s) p.__s = unrm((p.ten || '') + ' ' + (p.cdt || ''));
          if (q && p.__s.indexOf(q) < 0) return false;
          return true;
        });
        view = (limit === 'all') ? f : f.slice(0, +limit || 50);
        var pages = Math.max(1, Math.ceil(view.length / psz));
        if (page >= pages) page = pages - 1;
      }
      function summary() {
        var tot = view.reduce(function (s, p) { return s + (+p.kh || 0); }, 0);
        var pct = bzProv > 0 ? (tot / bzProv * 100) : 0;
        return '<div class="bz-summary">'
          + '<div class="bz-sm-item"><div class="bz-sm-lab">Số dự án (đang hiển thị)</div><div class="bz-sm-val">' + view.length + '</div></div>'
          + '<div class="bz-sm-item"><div class="bz-sm-lab">Tổng vốn các dự án này</div><div class="bz-sm-val">' + vn(tot) + ' <span class="bz-sm-u">tr.đ</span></div></div>'
          + '<div class="bz-sm-item hl"><div class="bz-sm-lab">Chiếm tỷ trọng vốn toàn tỉnh</div><div class="bz-sm-val">' + pc(pct) + '</div></div>'
          + '<div class="bz-sm-item"><div class="bz-sm-lab">Tổng kế hoạch vốn toàn tỉnh</div><div class="bz-sm-val">' + vn(bzProv) + ' <span class="bz-sm-u">tr.đ</span></div></div>'
          + '</div>';
      }
      function table() {
        var pages = Math.max(1, Math.ceil(view.length / psz)), start = page * psz;
        var rows = view.slice(start, start + psz).map(function (p, k) {
          var i = start + k;
          return '<tr class="bz-row" data-i="' + i + '"><td class="bz-rank">' + (i + 1) + '</td>'
            + '<td class="bz-proj">' + esc(p.ten) + '<span class="bz-cdt">' + esc(fullCDT(p.cdt || '')) + (p.khoi ? ' • ' + esc(p.khoi) : '') + '</span></td>'
            + '<td class="r bz-kh">' + vn(p.kh) + '</td>'
            + '<td class="r"><span class="bz-badge">0%</span></td></tr>';
        }).join('') || '<tr><td colspan="4" class="bz-empty">Không có dự án phù hợp bộ lọc.</td></tr>';
        var pager = pages > 1 ? '<div class="bz-pager">'
          + '<button class="bz-pg" data-pg="prev"' + (page === 0 ? ' disabled' : '') + '>‹ Trước</button>'
          + '<span class="bz-pginfo">Trang ' + (page + 1) + '/' + pages + ' • ' + view.length + ' dự án</span>'
          + '<button class="bz-pg" data-pg="next"' + (page >= pages - 1 ? ' disabled' : '') + '>Sau ›</button></div>' : '';
        return '<div class="bz-wrap"><table class="bz-table"><thead><tr><th>#</th><th>Dự án / Chủ đầu tư</th><th class="r">KH vốn (tr.đ)</th><th class="r">Giải ngân</th></tr></thead><tbody>' + rows + '</tbody></table></div>' + pager;
      }
      function draw() {
        compute();
        box.innerHTML = controls() + summary() + table()
          + '<div class="lu-unit-note">Bấm vào dòng để xem chủ đầu tư, liên hệ và khó khăn. ' + (bzSrcKB ? ('Nguồn: <b>Kho bạc Nhà nước</b> — phụ lục kết quả giải ngân từng dự án' + (bzAsof ? ' (đến ' + esc(bzAsof) + ')' : '') + '.') : 'Nguồn: danh mục Excel (đơn vị tự nhập) — sẽ tự chuyển sang số Kho bạc khi nhập phụ lục.') + '</div>';
      }
      draw();
      box.addEventListener('change', function (e) {
        var id = e.target.id;
        if (id === 'bz-khoi') { fKhoi = e.target.value; fCdt = ''; page = 0; draw(); }
        else if (id === 'bz-cdt') { fCdt = e.target.value; page = 0; draw(); }
        else if (id === 'bz-count') { limit = (e.target.value === 'all') ? 'all' : (+e.target.value); page = 0; draw(); }
        else if (id === 'bz-psz') { psz = +e.target.value || 10; page = 0; draw(); }
      });
      box.addEventListener('input', function (e) {
        if (e.target.id === 'bz-q') {
          fQ = e.target.value || ''; page = 0; compute();
          var sm0 = box.querySelector('.bz-summary'); if (sm0) sm0.outerHTML = summary();
          var wr0 = box.querySelector('.bz-wrap'); if (wr0) { var pg0 = box.querySelector('.bz-pager'); wr0.outerHTML = table(); if (pg0) pg0.remove(); }
          return;
        }
        if (e.target.id === 'bz-num') {
          var v = parseInt(e.target.value, 10);
          if (v > 0) { limit = v; page = 0;
            var keep = e.target; compute();
            // chỉ vẽ lại phần bảng + tóm tắt để giữ con trỏ trong ô nhập
            var sm = box.querySelector('.bz-summary'); if (sm) sm.outerHTML = summary();
            var wr = box.querySelector('.bz-wrap'); if (wr) { var pg = box.querySelector('.bz-pager'); wr.outerHTML = table(); if (pg) pg.remove(); }
          }
        }
      });
      box.addEventListener('click', function (e) {
        var xls = e.target.closest ? e.target.closest('#bz-xls') : null;
        if (xls) {
          var rows = view.map(function (p, i) {
            return { 'STT': i + 1, 'Dự án': p.ten, 'Chủ đầu tư': fullCDT(p.cdt || ''), 'Nhóm CĐT': p.khoi || '', 'KH vốn (tr.đ)': p.kh, 'Giải ngân': 0, 'Tỷ lệ': '0%' };
          });
          ladoExportXlsx(rows, 'DuAn_chua_giai_ngan_0pct', 'Du an 0%');
          return;
        }
        var pg = e.target.closest ? e.target.closest('.bz-pg') : null;
        if (pg) {
          if (pg.hasAttribute('disabled')) return;
          var pages = Math.max(1, Math.ceil(view.length / 10));
          if (pg.getAttribute('data-pg') === 'next') { if (page < pages - 1) page++; } else { if (page > 0) page--; }
          draw(); return;
        }
        var tr = e.target.closest ? e.target.closest('.bz-row') : null;
        if (!tr) return;
        var p = view[+tr.getAttribute('data-i')];
        if (p) showProject(p);
      });
    })();

    // tổng hợp theo từng Ban QLDA (số 1, 2, 3)
    (function () {
      var box = document.getElementById('banqlda-box'); if (!box) return;
      var sec = document.getElementById('sec-banqlda');
      // NGUỒN CHÍNH: bảng chi tiết báo cáo ngày (số liệu Kho bạc Nhà nước, cập nhật hằng ngày).
      var groups = [];
      var srcKB = false;
      if (D.all_ban && D.all_ban.length) {
        var tlStr = function (n) { var v = +n || 0; return (Math.round(v * 100) / 100).toString().replace('.', ',') + '%'; };
        var gmap = {}, order = [];
        D.all_ban.forEach(function (r) {
          var t = String(r.ten || '');
          var mg = t.match(/Ban QLDA ĐTXD số (\d+)\s*\(tổng\)/);
          if (mg) { var so = +mg[1]; gmap[so] = { so: so, ten: 'Ban QLDA ĐTXD số ' + so, kh: r.kh, gn: r.gn, tl: tlStr(r.tl), cdt: null, kv: [] }; order.push(so); return; }
          var so2 = (t.match(/số (\d+) làm CĐT/) || [])[1];
          if (so2 && gmap[so2]) { gmap[so2].cdt = { ten: r.ten, kh: r.kh, gn: r.gn, tl: tlStr(r.tl) }; return; }
          // dòng KV: thuộc Ban gần nhất đã thấy
          if (/^Ban QLDA ĐTXD/.test(t) && order.length) {
            var cur = gmap[order[order.length - 1]];
            if (cur) cur.kv.push({ ten: r.ten, kh: r.kh, gn: r.gn, tl: tlStr(r.tl) });
          }
        });
        groups = order.map(function (so) { return gmap[so]; }).filter(Boolean);
        srcKB = groups.length > 0;
      }
      // Dự phòng: khi chưa nhập báo cáo ngày, dùng Excel "Tổng hợp" (đơn vị tự nhập).
      if (!groups.length) { groups = (LADO_AI.donvi && LADO_AI.donvi.ban_qlda) || []; }
      if (!groups.length) { if (sec) sec.style.display = 'none'; return; }
      if (sec) sec.style.display = '';
      var srcNote = srcKB
        ? 'Nguồn: <b>Kho bạc Nhà nước</b> — bảng kết quả giải ngân chi tiết của báo cáo ngày (đến ' + esc(D.as_of || '') + ').'
        : 'Nguồn: file danh mục Excel (đơn vị tự nhập) — sẽ tự chuyển sang số Kho bạc khi nhập báo cáo ngày.';
      function pct(tl) { var n = parseFloat(String(tl || '').replace('%', '').replace(',', '.')); return isFinite(n) ? n : 0; }
      function bw(tl) { return Math.max(0, Math.min(100, pct(tl))); }
      function nameLink(ten) { return '<span class="lk" data-u="' + esc(unrm(ten)) + '">' + esc(fullCDT(ten)) + '</span>'; }
      function kvRow(x, cls) {
        return '<div class="bq-row' + (cls ? ' ' + cls : '') + '" data-n="' + esc(unrm(x.ten)) + '">'
          + '<div class="bq-rt">' + nameLink(x.ten) + '</div>'
          + '<div class="bq-rnums"><span class="bq-rk">' + vn(x.kh) + '</span>'
          + '<span class="bq-rg">' + vn(x.gn) + '</span>'
          + '<span class="bq-rp">' + esc(x.tl || '0%') + '</span></div>'
          + '<div class="bq-mbar"><i style="width:' + bw(x.tl) + '%"></i></div></div>';
      }
      function share(part, total) { return total > 0 ? Math.round(part / total * 100) : 0; }
      function subtl(gn, kh) { if (kh <= 0) return '0%'; var v = gn / kh * 100; return (Math.round(v * 100) / 100).toString().replace('.', ',') + '%'; }
      var byTl = function (a, b) { return pct(b.tl) - pct(a.tl); };
      var html = groups.map(function (g) {
        var head = '<div class="bq-head">'
          + '<button class="bq-xls" data-ban="' + (g.so || '') + '">⬇ Xuất Excel Ban ' + (g.so || '') + '</button>'
          + '<div class="bq-title">Ban Quản lý dự án số ' + (g.so || '') + '</div>'
          + '<div class="bq-totline">Tổng kế hoạch vốn <b>' + vn(g.kh) + '</b> tr.đ • đã giải ngân <b>' + vn(g.gn) + '</b> tr.đ'
          + '<span class="bq-pct">' + esc(g.tl || '0%') + '</span></div>'
          + '<div class="bq-bar"><i style="width:' + bw(g.tl) + '%"></i></div></div>';

        var inner = '<div class="bq-inlabel">Trong đó:</div>';
        if (g.cdt) {
          inner += '<div class="bq-sublab">🏗️ Ban số ' + (g.so || '') + ' trực tiếp làm chủ đầu tư'
            + '<span class="bq-share">chiếm ' + share(g.cdt.kh, g.kh) + '% kế hoạch vốn của Ban</span></div>'
            + kvRow(g.cdt, 'bq-cdt');
        }
        if (g.kv && g.kv.length) {
          var skh = 0, sgn = 0;
          g.kv.forEach(function (x) { skh += (+x.kh || 0); sgn += (+x.gn || 0); });
          inner += '<div class="bq-sublab">📍 Các Ban khu vực trực thuộc (' + g.kv.length + ' Ban) — xếp theo tỷ lệ giải ngân giảm dần'
            + '<span class="bq-share">cộng: KH ' + vn(skh) + ' • giải ngân ' + vn(sgn) + ' • ' + subtl(sgn, skh)
            + ' • chiếm ' + share(skh, g.kh) + '% KH của Ban</span></div>'
            + '<div class="bq-kvlist">' + g.kv.slice().sort(byTl).map(function (x) { return kvRow(x); }).join('') + '</div>';
        }
        return '<div class="bq-group" data-ban="' + (g.so || '') + '">' + head + '<div class="bq-body">' + inner + '</div></div>';
      }).join('');
      var chartCard = '<div class="bq-chartcard"><div class="bq-chartwrap"><canvas id="c-banqlda"></canvas></div>'
        + '<div class="bq-mini">' + groups.map(function (g) {
            return '<div class="bq-minicard"><div class="bq-mt">Ban số ' + (g.so || '') + '</div>'
              + '<div class="bq-mk">KH <b>' + vn(g.kh) + '</b></div>'
              + '<div class="bq-mg">GN <b>' + vn(g.gn) + '</b></div>'
              + '<div class="bq-mp">' + esc(g.tl || '0%') + '</div></div>';
          }).join('') + '</div></div>';
      var toolbar = '<div class="bq-toolbar"><input type="text" id="bq-search" placeholder="🔎 Lọc Ban khu vực theo tên…">'
        + '<button class="bq-xls bq-xls-all" data-ban="all">⬇ Xuất Excel cả 3 Ban</button></div>';
      box.innerHTML = chartCard + toolbar
        + '<div class="bq-collabel"><span>Đơn vị</span><span class="bq-rnums"><span>KH vốn</span><span>Giải ngân</span><span>Tỷ lệ</span></span></div>' + html
        + '<div class="lu-unit-note">Đơn vị: triệu đồng. Bấm tên Ban để xem danh mục dự án và liên hệ. ' + srcNote + '</div>';

      // lọc Ban khu vực theo tên
      var sb = document.getElementById('bq-search');
      if (sb) sb.addEventListener('input', function () {
        var q = unrm(sb.value || '');
        box.querySelectorAll('.bq-kvlist .bq-row').forEach(function (row) {
          var n = row.getAttribute('data-n') || '';
          row.style.display = (!q || n.indexOf(q) > -1) ? '' : 'none';
        });
      });

      // xuất Excel (từng Ban / cả 3)
      function expRows(gs) {
        var rows = [];
        gs.forEach(function (g) {
          rows.push({ 'Đơn vị': 'Ban Quản lý dự án số ' + (g.so || ''), 'Phân loại': 'TỔNG BAN', 'KH vốn (tr.đ)': g.kh, 'Giải ngân (tr.đ)': g.gn, 'Tỷ lệ': g.tl });
          if (g.cdt) rows.push({ 'Đơn vị': fullCDT(g.cdt.ten), 'Phân loại': 'Trực tiếp làm chủ đầu tư', 'KH vốn (tr.đ)': g.cdt.kh, 'Giải ngân (tr.đ)': g.cdt.gn, 'Tỷ lệ': g.cdt.tl });
          (g.kv || []).slice().sort(byTl).forEach(function (x) { rows.push({ 'Đơn vị': x.ten, 'Phân loại': 'Ban khu vực trực thuộc', 'KH vốn (tr.đ)': x.kh, 'Giải ngân (tr.đ)': x.gn, 'Tỷ lệ': x.tl }); });
        });
        return rows;
      }
      box.querySelectorAll('.bq-xls').forEach(function (btn) {
        btn.addEventListener('click', function () {
          var b = btn.getAttribute('data-ban');
          var gs = (b === 'all') ? groups : groups.filter(function (g) { return String(g.so) === b; });
          var fn = (b === 'all') ? 'BanQLDA_ca3Ban' : ('BanQLDA_so' + b);
          ladoExportXlsx(expRows(gs), fn);
        });
      });

      // biểu đồ so sánh 03 Ban: KH vốn vs đã giải ngân (+ nhãn tỷ lệ)
      try {
        var cv = document.getElementById('c-banqlda');
        if (cv && window.Chart) {
          var labs = groups.map(function (g) { return 'Ban số ' + (g.so || ''); });
          var khs = groups.map(function (g) { return +g.kh || 0; });
          var gns = groups.map(function (g) { return +g.gn || 0; });
          var tls = groups.map(function (g) { return pct(g.tl); });
          var tlLabel = {
            id: 'bqTlLabel',
            afterDatasetsDraw: function (ch) {
              var ctx = ch.ctx, meta = ch.getDatasetMeta(1);
              ctx.save(); ctx.font = '700 12px Inter, Segoe UI, sans-serif'; ctx.fillStyle = '#b91c1c'; ctx.textAlign = 'center';
              meta.data.forEach(function (bar, i) { ctx.fillText(pc(tls[i]), bar.x, bar.y - 7); });
              ctx.restore();
            }
          };
          new Chart(cv, {
            type: 'bar',
            data: { labels: labs, datasets: [
              { label: 'Kế hoạch vốn', data: khs, backgroundColor: '#93b4ff', borderRadius: 5 },
              { label: 'Đã giải ngân', data: gns, backgroundColor: '#1d4ed8', borderRadius: 5 }
            ] },
            options: {
              responsive: true, maintainAspectRatio: false,
              plugins: {
                legend: { position: 'bottom', labels: { boxWidth: 12, font: { size: 12 } } },
                tooltip: { callbacks: { label: function (c) { return c.dataset.label + ': ' + vn(c.parsed.y) + ' tr.đ'; },
                  afterBody: function (items) { var i = items[0].dataIndex; return 'Tỷ lệ giải ngân: ' + pc(tls[i]); } } }
              },
              scales: { y: { beginAtZero: true, ticks: { callback: function (v) { return vn(v); } } } }
            },
            plugins: [tlLabel]
          });
        }
      } catch (e) {}
    })();

    // bắt sự kiện bấm vào tên chủ đầu tư (ủy nhiệm)
    app.addEventListener('click', function (e) {
      var lk = e.target.closest ? e.target.closest('.lk') : null;
      if (!lk) return;
      e.preventDefault();
      var key = lk.getAttribute('data-u') || '';
      var name = (lk.textContent || '').trim();
      if (key || name) show(key, name);
    });
  })();

  /* ---------- weekly plan stats ---------- */
  (function () {
    var host = document.getElementById('wk-stats'); if (!host) return;
    var ws = (LADO_AI.donvi && LADO_AI.donvi.weekly_status) || null;
    var tt = (ws && (ws.tot || ws.phan || ws.dk_0 || ws.khong_dk)) ? ws : D.tuan_thongke;
    if (!tt) { document.querySelector('.wkstat-card').style.display = 'none'; return; }
    var kyEl = document.getElementById('wkstat-ky'); if (kyEl) kyEl.textContent = (tt.ky ? tt.ky + ' — ' : '') + 'mức độ đăng ký và thực hiện kế hoạch giải ngân trong tuần. Bấm mỗi ô để xem danh sách.';
    var tiles = [
      { k: 'tot', ic: '✅', cls: 'g', lab: 'Đăng ký & thực hiện tốt', note: 'đạt ≥ 80% KH tuần' },
      { k: 'phan', ic: '🔄', cls: 'b', lab: 'Đăng ký, thực hiện một phần', note: 'đạt < 80% KH tuần' },
      { k: 'khong_dk', ic: '⚠️', cls: 'a', lab: 'Không đăng ký KH tuần', note: 'không đăng ký kế hoạch tuần' },
      { k: 'dk_0', ic: '❌', cls: 'r', lab: 'Đăng ký nhưng thực hiện 0%', note: 'đăng ký nhưng chưa giải ngân' }
    ];
    tiles.forEach(function (t) {
      var obj = tt[t.k] || { count: 0, list: [] };
      var tile = el('<button class="wk-stat ' + t.cls + '"><div class="ws-ic">' + t.ic + '</div><div class="ws-num">' + (obj.count || 0) + '</div><div class="ws-lab">' + t.lab + '</div><div class="ws-note">' + t.note + '</div></button>');
      tile.addEventListener('click', function () { openModal(t.lab + ' (' + (obj.count || 0) + ' đơn vị)', obj.list || []); });
      host.appendChild(tile);
    });
  })();

  /* ---------- kiến nghị, đề xuất module ---------- */
  (function () {
    var card = document.getElementById('kn-card'); if (!card) return;
    var meta = LADO_AI.kn || {};
    if (!meta.has) { card.style.display = 'none'; return; }
    var by = meta.by_khoi || {};
    document.getElementById('kn-sub').innerHTML = 'Tổng hợp <b>' + (meta.total || 0) + '</b> kiến nghị, đề xuất theo từng dự án/đơn vị'
      + (meta.updated ? ' • cập nhật ' + esc(meta.updated) : '') + '. Nguồn: file Excel danh mục kế hoạch giải ngân theo tuần.';
    var ALL = [], shown = 0, STEP = 40, filtered = [];
    var listEl = document.getElementById('kn-list'), moreBtn = document.getElementById('kn-more');
    var qEl = document.getElementById('kn-q'), khoiEl = document.getElementById('kn-khoi'), nhomEl = document.getElementById('kn-nhom'), chipsEl = document.getElementById('kn-chips');
    // chuẩn hóa "nhóm khó khăn": tách theo dấu phẩy, bỏ rác, gộp về danh mục chuẩn
    var NHOM_CANON = [
      ['giai phong mat bang', 'Giải phóng mặt bằng'],
      ['thu tuc hanh chinh', 'Thủ tục hành chính'],
      ['nguyen vat lieu', 'Nguyên vật liệu'],
      ['nang luc nha thau', 'Năng lực nhà thầu'],
      ['gia ca', 'Về giá cả'],
      ['von', 'Khó khăn về vốn'],
      ['khac', 'Khó khăn khác']
    ];
    function nhomTokens(s) {
      var out = [], seen = {};
      (s || '').split(/[,;]/).forEach(function (t) {
        t = t.replace(/["']/g, '').trim();
        if (!t) return;
        var low = unrm(t);
        if (!low || low.indexOf('khong co') > -1 || low === 'vuong mac' || low === 'vuong mac.') return; // bỏ "Không có khó khăn…" và mảnh "vướng mắc"
        var canon = null;
        for (var i = 0; i < NHOM_CANON.length; i++) { if (low.indexOf(NHOM_CANON[i][0]) > -1) { canon = NHOM_CANON[i][1]; break; } }
        if (!canon) { canon = t.charAt(0).toUpperCase() + t.slice(1); }
        if (!seen[canon]) { seen[canon] = 1; out.push(canon); }
      });
      return out;
    }
    function khoiBadge(k) { var c = k.indexOf('Ban') > -1 ? 'b' : (k.indexOf('Sở') > -1 ? 'a' : 'g'); return '<span class="tl-badge ' + c + '">' + esc(k) + '</span>'; }
    function row(x) {
      var f = '';
      if (x.kho_khan) f += '<div class="kn-f"><span>Khó khăn, vướng mắc</span>' + esc(x.kho_khan) + '</div>';
      if (x.tham_quyen) f += '<div class="kn-f"><span>Thẩm quyền giải quyết</span>' + esc(x.tham_quyen) + '</div>';
      if (x.kien_nghi) f += '<div class="kn-f kn-hl"><span>Kiến nghị, đề xuất</span>' + esc(x.kien_nghi) + '</div>';
      if (x.thoi_gian) f += '<div class="kn-f"><span>Thời gian hoàn thành</span>' + esc(xlDate(x.thoi_gian)) + '</div>';
      return '<div class="kn-item"><div class="kn-top">' + khoiBadge(x.khoi) + '<span class="kn-nhom">' + esc(nhomTokens(x.nhom).join(', ') || x.nhom) + '</span></div>'
        + '<div class="kn-dv">' + esc(x.don_vi || '') + '</div>'
        + (x.du_an ? '<div class="kn-da">' + esc(x.du_an) + '</div>' : '') + f + '</div>';
    }
    function render(reset) {
      if (reset) { shown = 0; listEl.innerHTML = ''; }
      if (!filtered.length) { listEl.innerHTML = '<p class="hint" style="margin:0">Không có kiến nghị phù hợp bộ lọc.</p>'; moreBtn.style.display = 'none'; return; }
      var slice = filtered.slice(shown, shown + STEP);
      listEl.insertAdjacentHTML('beforeend', slice.map(row).join(''));
      shown += slice.length;
      moreBtn.style.display = shown < filtered.length ? '' : 'none';
      moreBtn.textContent = 'Xem thêm (' + (filtered.length - shown) + ')';
    }
    function filter() {
      var q = (qEl.value || '').toLowerCase().trim(), kk = khoiEl.value, nh = nhomEl.value;
      filtered = ALL.filter(function (x) {
        if (kk && x.khoi !== kk) return false;
        if (nh && nhomTokens(x.nhom).indexOf(nh) < 0) return false;
        if (q) { var hay = ((x.don_vi || '') + ' ' + (x.du_an || '') + ' ' + (x.kho_khan || '') + ' ' + (x.kien_nghi || '') + ' ' + (x.tham_quyen || '')).toLowerCase(); if (hay.indexOf(q) < 0) return false; }
        return true;
      });
      render(true);
    }
    function buildNhom() {
      var counts = {};
      ALL.forEach(function (x) { nhomTokens(x.nhom).forEach(function (tok) { counts[tok] = (counts[tok] || 0) + 1; }); });
      var arr = Object.keys(counts).map(function (k) { return [k, counts[k]]; }).sort(function (a, b) { return b[1] - a[1]; }).slice(0, 8);
      arr.forEach(function (p) { var o = document.createElement('option'); o.value = p[0]; o.textContent = p[0] + ' (' + p[1] + ')'; nhomEl.appendChild(o); });
      chipsEl.innerHTML = arr.slice(0, 6).map(function (p) { return '<button class="kn-chip" data-n="' + esc(p[0]) + '">' + esc(p[0]) + ' <b>' + p[1] + '</b></button>'; }).join('');
      chipsEl.querySelectorAll('.kn-chip').forEach(function (b) {
        b.addEventListener('click', function () {
          var on = b.classList.contains('on');
          chipsEl.querySelectorAll('.kn-chip').forEach(function (x) { x.classList.remove('on'); });
          if (on) { nhomEl.value = ''; } else { b.classList.add('on'); nhomEl.value = b.dataset.n; }
          filter();
        });
      });
    }
    qEl.addEventListener('input', filter); khoiEl.addEventListener('change', filter); nhomEl.addEventListener('change', filter);
    moreBtn.addEventListener('click', function () { render(false); });
    listEl.innerHTML = '<p class="hint" style="margin:0">Đang tải danh sách kiến nghị…</p>';
    var fd = new FormData(); fd.append('action', 'lado_kiennghi'); fd.append('nonce', LADO_AI.nonce);
    fetch(LADO_AI.ajax, { method: 'POST', body: fd }).then(function (r) { return r.json(); }).then(function (res) {
      if (res && res.success && res.data && res.data.items && res.data.items.length) {
        ALL = res.data.items; filtered = ALL.slice(); buildNhom(); render(true);
      } else { listEl.innerHTML = '<p class="hint" style="margin:0">Chưa có dữ liệu kiến nghị.</p>'; }
    }).catch(function () { listEl.innerHTML = '<p class="hint" style="margin:0">Không tải được dữ liệu kiến nghị.</p>'; });
  })();

  /* ---------- full detail tables (3 nhóm) ---------- */
  (function () {
    var wrap = document.getElementById('ld-table'); if (!wrap) return;
    var groups = {
      ban: { rows: D.all_ban || [], cols: ['kh', 'gn'], head: ['Chủ đầu tư (Ban QLDA)', 'Kế hoạch', 'Giải ngân', 'Tỷ lệ'] },
      so:  { rows: D.all_so || [],  cols: ['kh', 'gn'], head: ['Đơn vị (Sở, ngành)', 'Kế hoạch', 'Giải ngân', 'Tỷ lệ'] },
      xa:  { rows: D.all_xa || [],  cols: ['kh', 'gn'], head: ['Xã / phường / đặc khu', 'Kế hoạch', 'Giải ngân', 'Tỷ lệ'] }
    };
    var setc = function (id, n) { var e = document.getElementById(id); if (e) e.textContent = n; };
    setc('cnt-ban', groups.ban.rows.length); setc('cnt-so', groups.so.rows.length); setc('cnt-xa', groups.xa.rows.length);
    var cur = 'ban', sortKey = 'tl', sortDir = -1; // mặc định: tỷ lệ giảm dần
    function tlCls(t) { return t >= 20 ? 'g' : (t < 5 ? 'r' : 'a'); }
    function curRows() {
      var info = groups[cur];
      var f = (document.getElementById('ld-search').value || '').toLowerCase().trim();
      var band = document.getElementById('ld-filter').value;
      var rows = info.rows.filter(function (r) {
        if (f && (r.ten || '').toLowerCase().indexOf(f) < 0) return false;
        var t = +r.tl || 0;
        if (band === 'ge20') return t >= 20;
        if (band === '5to20') return t >= 5 && t < 20;
        if (band === 'lt5') return t < 5 && t > 0.001;
        if (band === 'zero') return t <= 0.001;
        return true;
      });
      rows = rows.slice().sort(function (a, b) {
        var x, y;
        if (sortKey === 'ten') { x = (a.ten || '').toLowerCase(); y = (b.ten || '').toLowerCase(); return x < y ? -sortDir : (x > y ? sortDir : 0); }
        x = +a[sortKey] || 0; y = +b[sortKey] || 0; return (x - y) * sortDir;
      });
      return rows;
    }
    function arrow(k) { return sortKey === k ? (sortDir < 0 ? ' ▼' : ' ▲') : ''; }
    function render() {
      var info = groups[cur], rows = curRows();
      var h = '<table class="ld-table"><thead><tr><th class="c-tt">#</th>'
        + '<th class="ld-sort" data-k="ten">' + info.head[0] + arrow('ten') + '</th>'
        + '<th class="num ld-sort" data-k="kh">Kế hoạch' + arrow('kh') + '</th>'
        + '<th class="num ld-sort" data-k="gn">Giải ngân' + arrow('gn') + '</th>'
        + '<th class="num ld-sort" data-k="tl">Tỷ lệ' + arrow('tl') + '</th></tr></thead><tbody>';
      if (!rows.length) h += '<tr><td colspan="5" style="text-align:center;color:var(--muted);padding:16px">Không tìm thấy đơn vị phù hợp.</td></tr>';
      rows.forEach(function (r, idx) {
        h += '<tr><td class="c-tt">' + (idx + 1) + '</td><td>' + unitLink(r.ten) + '</td>'
          + '<td class="num">' + (r.kh != null ? vn(r.kh) : '—') + '</td>'
          + '<td class="num">' + (r.gn != null ? vn(r.gn) : '—') + '</td>'
          + '<td class="num"><span class="tl-badge ' + tlCls(r.tl) + '">' + pc(r.tl) + '</span></td></tr>';
      });
      wrap.innerHTML = h + '</tbody></table>';
      wrap.querySelectorAll('.ld-sort').forEach(function (th) {
        th.addEventListener('click', function () {
          var k = th.getAttribute('data-k');
          if (sortKey === k) { sortDir = -sortDir; } else { sortKey = k; sortDir = (k === 'ten') ? 1 : -1; }
          render();
        });
      });
    }
    app.querySelectorAll('.ld-tab').forEach(function (b) {
      b.addEventListener('click', function () {
        app.querySelectorAll('.ld-tab').forEach(function (x) { x.classList.remove('on'); });
        b.classList.add('on'); cur = b.dataset.g; render(); wrap.scrollTop = 0;
      });
    });
    document.getElementById('ld-search').addEventListener('input', render);
    document.getElementById('ld-filter').addEventListener('change', render);
    var gname = { ban: 'Ban_QLDA', so: 'So_nganh', xa: 'Xa_phuong' };
    function exportRows() {
      return curRows().map(function (r, i) {
        return { 'TT': i + 1, 'Chủ đầu tư / đơn vị': r.ten, 'Kế hoạch vốn (tr.đ)': r.kh || 0, 'Giải ngân (tr.đ)': r.gn || 0, 'Tỷ lệ (%)': (+r.tl || 0) };
      });
    }
    document.getElementById('ld-xls').addEventListener('click', function () {
      ladoExportXlsx(exportRows(), 'Chi_tiet_' + gname[cur] + '_' + (D.as_of || '').replace(/\//g, '-'), 'Chi tiết giải ngân');
    });
    document.getElementById('ld-doc').addEventListener('click', function () {
      ladoExportDoc(exportRows(), 'Chi_tiet_' + gname[cur] + '_' + (D.as_of || '').replace(/\//g, '-'),
        'BẢNG KẾT QUẢ GIẢI NGÂN CHI TIẾT — ' + (groups[cur].head[0]) + ' (đến ' + (D.as_of || '') + ')');
    });
    render();
  })();

  /* ---------- tab thống kê theo 06 TỔ (ẩn mặc định) ---------- */
  (function () {
    var card = document.getElementById('sec-6to'); if (!card) return;
    // ====== BẢN MỚI: theo báo cáo riêng từng TỔ CÔNG TÁC ======
    var TCT = (D.tct && D.tct.tos && D.tct.tos.length) ? D.tct : null;
    if (TCT) {
      var tbody = document.getElementById('sixto-body');
      var ttoggle = document.getElementById('sixto-toggle');
      var tbuilt = false, tcur = 0;
      var NGR = { 1: 'Không vướng mắc', 2: 'Giải phóng mặt bằng', 3: 'Thủ tục hành chính', 4: 'Giá nhiên vật liệu / nhà thầu', 5: 'Vướng mắc khác' };
      function tCls(t) { return t >= 20 ? 'g' : (t < 5 ? 'r' : 'a'); }
      function tPct(tl) { return pc(+tl || 0); }
      function dlGrid() {
        var files = LADO_AI.tct_files || [];
        if (!files.length) return '';
        var byTo = {};
        files.forEach(function (f) { (byTo[f.to] = byTo[f.to] || []).push(f); });
        var cards = TCT.tos.map(function (t) {
          var fs = (byTo[t.so] || []).slice().reverse();
          if (!fs.length) return '<div class="tct-dlcard off"><div class="tdl-to">Tổ ' + t.so + '</div><div class="tdl-d">Chưa có file</div></div>';
          var sel = fs.length > 1
            ? '<select class="tdl-sel" data-to="' + t.so + '">' + fs.map(function (f, i) { return '<option value="' + esc(f.url) + '"' + (i === 0 ? ' selected' : '') + '>' + esc(f.date) + '</option>'; }).join('') + '</select>'
            : '<div class="tdl-d">Ngày ' + esc(fs[0].date) + '</div>';
          return '<a class="tct-dlcard" id="tdl-' + t.so + '" href="' + esc(fs[0].url) + '" download><div class="tdl-to">Tổ ' + t.so + '</div>' + sel + '<div class="tdl-btn">⬇ Tải báo cáo</div></a>';
        }).join('');
        return '<div class="tct-dlhead">📥 Tải báo cáo của từng Tổ công tác' + (TCT.as_of ? ' <small>(số liệu Kho bạc đến ' + esc(TCT.as_of) + ')</small>' : '') + '</div><div class="tct-dlgrid">' + cards + '</div>';
      }
      function tctCards() {
        return '<div class="tct-cards">' + TCT.tos.map(function (t, i) {
          var w = Math.max(2, Math.min(100, +t.tl || 0));
          return '<button class="tct-card' + (i === tcur ? ' on' : '') + '" data-i="' + i + '">'
            + '<div class="tc-h"><span class="tc-no">Tổ ' + t.so + '</span><span class="sx-tl ' + tCls(t.tl) + '">' + tPct(t.tl) + '</span></div>'
            + '<div class="tc-pv">' + esc(t.ten || '') + '</div>'
            + '<div class="tc-tt">👤 ' + esc(t.to_truong || '') + '</div>'
            + '<div class="sx-prog"><i class="' + tCls(t.tl) + '" style="width:' + w + '%"></i></div>'
            + '<div class="tc-nums"><b>' + vn(t.gn) + '</b> / ' + vn(t.kh) + ' tr.đ</div>'
            + '<div class="tc-chips">'
            + (t.ps ? '<span class="tc-chip up">▲ kỳ này +' + vn(t.ps) + '</span>' : '')
            + '<span class="tc-chip g">🟢 tốt ' + ((t.dg_tot && t.dg_tot.n) || 0) + '</span>'
            + '<span class="tc-chip r">⭕ 0%: ' + ((t.dg_zero && t.dg_zero.n) || 0) + ' DA</span>'
            + '</div></button>';
        }).join('') + '</div>';
      }
      function tctDetail() {
        var t = TCT.tos[tcur]; if (!t) return '';
        var h = '<div class="tct-dhead"><h4>🧭 Tổ công tác số ' + t.so + ' — ' + esc(t.ten || '') + '</h4>'
          + '<div class="tct-tt">Tổ trưởng: <b>' + esc(t.to_truong_full || t.to_truong || '') + '</b></div></div>'
          + '<input type="search" id="tct-q" class="tct-q" placeholder="🔍 Tìm dự án / chủ đầu tư trong Tổ ' + t.so + '…">';
        h += '<div class="tct-stats">'
          + '<div class="tct-st"><span>Tổng KH vốn</span><b>' + vn(t.kh) + '</b></div>'
          + '<div class="tct-st"><span>Vốn năm 2026</span><b>' + vn(t.kh26) + '</b></div>'
          + '<div class="tct-st"><span>Vốn 2025 kéo dài</span><b>' + vn(t.kh25) + '</b></div>'
          + '<div class="tct-st hl"><span>Lũy kế giải ngân</span><b>' + vn(t.gn) + '</b></div>'
          + '<div class="tct-st up"><span>Phát sinh trong kỳ</span><b>' + (t.ps ? '+' + vn(t.ps) : '0') + '</b></div>'
          + '<div class="tct-st tl"><span>Tỷ lệ</span><b>' + tPct(t.tl) + '</b></div>'
          + '</div>';
        var dg = [];
        if (t.dg_tot && t.dg_tot.n) dg.push('<div class="tct-dg g">🟢 <b>' + t.dg_tot.n + '</b> dự án giải ngân tốt (≥40%)' + (t.dg_tot.text ? ': <i>' + esc(t.dg_tot.text) + '</i>' : '') + '</div>');
        if (t.dg_chuatot && t.dg_chuatot.n) dg.push('<div class="tct-dg a">🟡 <b>' + t.dg_chuatot.n + '</b> dự án dưới 10% — KH ' + vn(t.dg_chuatot.kh) + '</div>');
        if (t.dg_zero && t.dg_zero.n) dg.push('<div class="tct-dg r">⭕ <b>' + t.dg_zero.n + '</b> dự án 0% — KH ' + vn(t.dg_zero.kh) + (t.dg_zero.text ? ' • ' + esc(t.dg_zero.text) : '') + '</div>');
        if (dg.length) h += '<div class="tct-dgwrap">' + dg.join('') + '</div>';
        var LIMIT = 15;
        (t.nhom || []).forEach(function (g) {
          if (!g.n || !g.projects || !g.projects.length) return;
          h += '<div class="tct-nhom n' + g.so + '"><div class="tct-nh">'
            + '<span class="tct-nbadge n' + g.so + '">Nhóm ' + g.so + '</span> ' + esc(g.ten)
            + '<span class="tct-nsum">' + g.n + ' DA • KH ' + vn(g.kh) + ' • GN ' + vn(g.gn) + ' (' + esc(g.tl) + ')</span></div>'
            + '<div class="lu-tablewrap"><table class="lu-table tct-table"><thead><tr><th>Tên dự án / Chủ đầu tư</th><th class="r">Tổng KH</th><th class="r">Giải ngân</th><th class="r">Tỷ lệ</th></tr></thead><tbody>';
          g.projects.forEach(function (p, pi) {
            h += '<tr class="tct-prow' + (pi >= LIMIT ? ' hid' : '') + '" data-n="' + g.so + '" data-p="' + pi + '" data-s="' + esc(unrm((p.ten || '') + ' ' + (p.cdt || ''))) + '">'
              + '<td>' + esc(p.ten) + '<span class="lu-ma">' + (p.ma && p.ma !== '-' ? 'Mã: ' + esc(p.ma) + ' • ' : '') + esc(fullCDT(p.cdt || '')) + '</span></td>'
              + '<td class="r">' + vn(p.kh) + '</td><td class="r"><b>' + vn(p.gn) + '</b></td>'
              + '<td class="r"><span class="lu-pc">' + esc(p.tl || '—') + '</span></td></tr>';
          });
          h += '</tbody></table></div>';
          if (g.projects.length > LIMIT) {
            h += '<button class="tct-more" data-n="' + g.so + '">▾ Xem thêm ' + (g.projects.length - LIMIT) + ' dự án (đang hiện ' + LIMIT + '/' + g.projects.length + ')</button>';
          }
          h += '</div>';
        });
        h += '<div class="lu-unit-note">Bấm vào một dự án để xem chi tiết giải ngân, đối chiếu tự nhập, vướng mắc và kiến nghị. Nguồn: báo cáo Tổ công tác (số Kho bạc' + (TCT.as_of ? ' đến ' + esc(TCT.as_of) : '') + ').</div>';
        return h;
      }
      function tctBuild() {
        tbody.innerHTML = dlGrid() + tctCards() + '<div id="tct-detail">' + tctDetail() + '</div>';
        tbody.querySelectorAll('.tdl-sel').forEach(function (sel) {
          sel.addEventListener('click', function (e) { e.preventDefault(); e.stopPropagation(); });
          sel.addEventListener('change', function () { var a = document.getElementById('tdl-' + sel.getAttribute('data-to')); if (a) a.href = sel.value; });
        });
        tbody.addEventListener('click', function (e) {
          var c = e.target.closest ? e.target.closest('.tct-card') : null;
          if (c) {
            tcur = +c.getAttribute('data-i') || 0;
            tbody.querySelectorAll('.tct-card').forEach(function (x) { x.classList.remove('on'); });
            c.classList.add('on');
            var dt = document.getElementById('tct-detail');
            if (dt) { dt.innerHTML = tctDetail(); dt.scrollIntoView({ behavior: 'smooth', block: 'start' }); }
            return;
          }
          var mb = e.target.closest ? e.target.closest('.tct-more') : null;
          if (mb) {
            var gso = mb.getAttribute('data-n');
            var box2 = mb.closest('.tct-nhom');
            var hid = box2 ? box2.querySelectorAll('.tct-prow.hid') : [];
            for (var i = 0; i < hid.length && i < 40; i++) { hid[i].classList.remove('hid'); }
            var left = box2 ? box2.querySelectorAll('.tct-prow.hid').length : 0;
            if (!left) { mb.remove(); }
            else { var tot = box2.querySelectorAll('.tct-prow').length; mb.textContent = '▾ Xem thêm ' + left + ' dự án (đang hiện ' + (tot - left) + '/' + tot + ')'; }
            return;
          }
          var tr = e.target.closest ? e.target.closest('.tct-prow') : null;
          if (tr && !(e.target.closest && e.target.closest('.lk'))) {
            var t = TCT.tos[tcur]; if (!t) return;
            var g = (t.nhom || []).filter(function (x) { return x.so === +tr.getAttribute('data-n'); })[0];
            var p = g && g.projects ? g.projects[+tr.getAttribute('data-p')] : null;
            if (p && window.__ladoTctProj) window.__ladoTctProj(p, { to: t.so, as: TCT.as_of || '', nhom: g.ten, nhomSo: g.so });
          }
        });
        // tìm dự án trong tổ (ủy nhiệm input)
        tbody.addEventListener('input', function (e) {
          if (e.target.id !== 'tct-q') return;
          var q = unrm(e.target.value || '');
          var dt = document.getElementById('tct-detail'); if (!dt) return;
          dt.querySelectorAll('.tct-prow').forEach(function (row) {
            if (!q) { row.style.display = ''; return; }
            row.classList.remove('hid');
            row.style.display = (row.getAttribute('data-s') || '').indexOf(q) > -1 ? '' : 'none';
          });
          dt.querySelectorAll('.tct-more').forEach(function (m) { m.style.display = q ? 'none' : ''; });
          dt.querySelectorAll('.tct-nhom').forEach(function (nb) {
            var any = false;
            nb.querySelectorAll('.tct-prow').forEach(function (r) { if (r.style.display !== 'none' && !r.classList.contains('hid')) any = true; });
            nb.style.display = (!q || any) ? '' : 'none';
          });
        });
      }
      if (ttoggle) ttoggle.addEventListener('click', function () {
        var open = tbody.style.display !== 'none';
        if (open) { tbody.style.display = 'none'; ttoggle.textContent = 'Hiển thị thống kê 6 tổ ▾'; }
        else { tbody.style.display = ''; ttoggle.textContent = 'Ẩn thống kê 6 tổ ▴'; if (!tbuilt) { tctBuild(); tbuilt = true; } }
      });
      return;
    }
    // ====== BẢN CŨ: file tổng hợp 6 tổ ======
    var six = (D.sixto && D.sixto.tos) ? D.sixto.tos : [];
    if (!six.length) { card.style.display = 'none'; return; }
    var body = document.getElementById('sixto-body');
    var toggle = document.getElementById('sixto-toggle');
    var built = false, curTo = 0, sortKey = 'tl', sortDir = -1;

    function tlCls(t) { return t >= 20 ? 'g' : (t < 5 ? 'r' : 'a'); }
    function summaryHtml() {
      var S = D.sixto || {};
      var totGn = 0, totKh = 0, totDa = 0;
      six.forEach(function (t) { totGn += (+t.gn || 0); totKh += (+t.kh || 0); totDa += (+t.da || 0); });
      if (S.tong) { totGn = +S.tong.gn || totGn; totKh = +S.tong.kh || totKh; }
      var totTl = totKh > 0 ? (totGn / totKh * 100) : 0;
      var cards = six.map(function (t, i) {
        var w = Math.max(2, Math.min(100, +t.tl || 0));
        var share = totKh > 0 ? Math.round((+t.kh || 0) / totKh * 100) : 0;
        return '<button class="sx-card' + (i === curTo ? ' on' : '') + '" data-i="' + i + '">'
          + '<div class="sx-h"><span class="sx-no">Tổ ' + t.stt + '</span><span class="sx-tl ' + tlCls(t.tl) + '">' + pc(t.tl) + '</span></div>'
          + '<div class="sx-pv">' + esc(t.pham_vi || '') + '</div>'
          + '<div class="sx-tt">👤 ' + esc(t.to_truong || '') + '</div>'
          + '<div class="sx-prog"><i class="' + tlCls(t.tl) + '" style="width:' + w + '%"></i></div>'
          + '<div class="sx-nums"><b>' + vn(t.gn) + '</b> / ' + vn(t.kh) + ' tr.đ</div>'
          + '<div class="sx-meta">' + (t.da ? ('📦 ' + t.da + ' dự án • ') : '') + '🏛 ' + (t.cdt || t.count || (t.rows ? t.rows.length : 0)) + ' CĐT • chiếm ' + share + '% KH 6 tổ</div>'
          + '</button>';
      }).join('');
      var ds = S.doi_soat ? '<div class="sx-doisoat">🔎 <b>Đối soát:</b> ' + esc(S.doi_soat) + '</div>' : '';
      return '<div class="sx-summary">' + cards + '</div>'
        + '<div class="sx-total">Cộng 06 tổ: đã giải ngân <b>' + vn(totGn) + '</b> / ' + vn(totKh) + ' triệu đồng • tỷ lệ <b>' + pc(totTl) + '</b>' + (totDa ? ' • ' + vn(totDa) + ' dự án' : '') + (S.as_of ? ' • số liệu đến <b>' + esc(S.as_of) + '</b>' : '') + '</div>'
        + ds;
    }
    function curRows() {
      var t = six[curTo] || { rows: [] };
      var f = (document.getElementById('sx-search').value || '').toLowerCase().trim();
      var band = document.getElementById('sx-filter').value;
      var rows = (t.rows || []).filter(function (r) {
        if (f && (r.ten || '').toLowerCase().indexOf(f) < 0) return false;
        var x = +r.tl || 0;
        if (band === 'ge20') return x >= 20;
        if (band === '5to20') return x >= 5 && x < 20;
        if (band === 'lt5') return x < 5 && x > 0.001;
        if (band === 'zero') return x <= 0.001;
        return true;
      });
      rows = rows.slice().sort(function (a, b) {
        if (sortKey === 'ten') { var x = (a.ten || '').toLowerCase(), y = (b.ten || '').toLowerCase(); return x < y ? -sortDir : (x > y ? sortDir : 0); }
        return ((+a[sortKey] || 0) - (+b[sortKey] || 0)) * sortDir;
      });
      return rows;
    }
    function arrow(k) { return sortKey === k ? (sortDir < 0 ? ' ▼' : ' ▲') : ''; }
    function renderTable() {
      var rows = curRows(), wrap = document.getElementById('sx-table');
      var hasDa = rows.some(function (r) { return +r.da > 0; });
      var h = '<table class="ld-table"><thead><tr><th class="c-tt">#</th>'
        + '<th class="ld-sort" data-k="ten">Chủ đầu tư / địa bàn' + arrow('ten') + '</th>'
        + (hasDa ? '<th class="num ld-sort" data-k="da">Số DA' + arrow('da') + '</th>' : '')
        + '<th class="num ld-sort" data-k="kh">Kế hoạch' + arrow('kh') + '</th>'
        + '<th class="num ld-sort" data-k="gn">Giải ngân' + arrow('gn') + '</th>'
        + '<th class="num ld-sort" data-k="tl">Tỷ lệ' + arrow('tl') + '</th></tr></thead><tbody>';
      if (!rows.length) h += '<tr><td colspan="' + (hasDa ? 6 : 5) + '" style="text-align:center;color:var(--muted);padding:16px">Không có chủ đầu tư phù hợp.</td></tr>';
      rows.forEach(function (r, i) {
        h += '<tr><td class="c-tt">' + (i + 1) + '</td><td>' + unitLink(r.ten) + '</td>'
          + (hasDa ? '<td class="num">' + (r.da || 0) + '</td>' : '')
          + '<td class="num">' + vn(r.kh) + '</td><td class="num">' + vn(r.gn) + '</td>'
          + '<td class="num"><span class="tl-badge ' + tlCls(r.tl) + '">' + pc(r.tl) + '</span></td></tr>';
      });
      wrap.innerHTML = h + '</tbody></table>';
      wrap.querySelectorAll('.ld-sort').forEach(function (th) {
        th.addEventListener('click', function () {
          var k = th.getAttribute('data-k');
          if (sortKey === k) sortDir = -sortDir; else { sortKey = k; sortDir = (k === 'ten') ? 1 : -1; }
          renderTable();
        });
      });
    }
    function refreshSummary() {
      document.getElementById('sx-summary-wrap').innerHTML = summaryHtml();
      document.getElementById('sx-summary-wrap').querySelectorAll('.sx-card').forEach(function (b) {
        b.addEventListener('click', function () { curTo = +b.getAttribute('data-i'); refreshSummary(); renderTable(); });
      });
      var t = six[curTo] || {};
      document.getElementById('sx-cur-title').innerHTML = '📁 Tổ ' + (t.stt || '') + ' — ' + esc(t.pham_vi || '');
    }
    function build() {
      var files = (LADO_AI.sixto_files || []).slice().reverse();
      var dlBar = '';
      if (files.length) {
        dlBar = '<div class="sx-dlbar">📥 <b>Tải báo cáo thống kê 6 tổ:</b> <select id="sx-dl-date" class="ld-filter">'
          + files.map(function (f, i) { return '<option value="' + esc(f.url) + '"' + (i === 0 ? ' selected' : '') + '>Ngày ' + esc(f.date) + '</option>'; }).join('')
          + '</select> <a id="sx-dl-btn" class="ld-exp doc" href="' + esc(files[0].url) + '" download>⬇ Tải file (.docx)</a></div>';
      }
      body.innerHTML =
        dlBar
        + '<div id="sx-summary-wrap"></div>'
        + '<div class="sx-tablehead"><h4 id="sx-cur-title"></h4></div>'
        + '<div class="ld-controls">'
        + '<input type="search" class="ld-search" id="sx-search" placeholder="🔍 Tìm chủ đầu tư trong tổ…">'
        + '<select class="ld-filter" id="sx-filter"><option value="">Tất cả tỷ lệ</option><option value="ge20">Tốt (≥ 20%)</option><option value="5to20">Trung bình (5–20%)</option><option value="lt5">Thấp (< 5%)</option><option value="zero">Chưa giải ngân (0%)</option></select>'
        + '<div class="ld-exports"><button class="ld-exp xls" id="sx-xls">⬇ Excel</button><button class="ld-exp doc" id="sx-doc">⬇ Word</button></div>'
        + '</div>'
        + '<div class="ld-table-wrap" id="sx-table"></div>';
      var dsel = document.getElementById('sx-dl-date');
      if (dsel) dsel.addEventListener('change', function () { var b = document.getElementById('sx-dl-btn'); if (b) b.href = dsel.value; });
      document.getElementById('sx-search').addEventListener('input', renderTable);
      document.getElementById('sx-filter').addEventListener('change', renderTable);
      document.getElementById('sx-xls').addEventListener('click', function () {
        var t = six[curTo]; var rows = curRows().map(function (r, i) { var o = { 'TT': i + 1, 'Chủ đầu tư / địa bàn': r.ten }; if (+r.da > 0) o['Số DA'] = r.da; o['Kế hoạch vốn (tr.đ)'] = r.kh || 0; o['Giải ngân (tr.đ)'] = r.gn || 0; o['Tỷ lệ (%)'] = (+r.tl || 0); return o; });
        ladoExportXlsx(rows, 'To_' + t.stt + '_' + (D.sixto.as_of || '').replace(/\//g, '-'), 'Tổ ' + t.stt);
      });
      document.getElementById('sx-doc').addEventListener('click', function () {
        var t = six[curTo]; var rows = curRows().map(function (r, i) { return { 'TT': i + 1, 'Chủ đầu tư / địa bàn': r.ten, 'Kế hoạch vốn (tr.đ)': r.kh || 0, 'Giải ngân (tr.đ)': r.gn || 0, 'Tỷ lệ (%)': (+r.tl || 0) }; });
        ladoExportDoc(rows, 'To_' + t.stt + '_' + (D.sixto.as_of || '').replace(/\//g, '-'), 'THỐNG KÊ GIẢI NGÂN — TỔ ' + t.stt + ': ' + (t.pham_vi || '') + ' (đến ' + (D.sixto.as_of || '') + ')');
      });
      refreshSummary(); renderTable();
      built = true;
    }
    toggle.addEventListener('click', function () {
      var open = body.style.display !== 'none';
      if (open) { body.style.display = 'none'; toggle.innerHTML = 'Hiển thị thống kê 6 tổ ▾'; toggle.classList.remove('on'); }
      else { if (!built) build(); body.style.display = ''; toggle.innerHTML = 'Ẩn thống kê 6 tổ ▴'; toggle.classList.add('on'); }
    });
  })();

  /* ---------- navigation menu (scroll to section + scroll-spy) ---------- */
  (function () {
    var track = document.getElementById('lado-nav'); if (!track) return;
    var items = [
      { id: 'sec-tong', ic: '📊', t: 'Tổng quan' },
      { id: 'sec-dl', ic: '📥', t: 'Tải báo cáo' },
      { id: 'sec-day', ic: '📈', t: 'Theo ngày' },
      { id: 'sec-khoi', ic: '🎯', t: 'Tỷ lệ & nhóm' },
      { id: 'sec-barkhoi', ic: '📊', t: 'Biểu đồ khối' },
      { id: 'sec-giao', ic: '🎯', t: 'Kế hoạch giao' },
      { id: 'sec-nguon', ic: '💰', t: 'Nguồn vốn' },
      { id: 'sec-cocau', ic: '🧭', t: 'Cơ cấu' },
      { id: 'sec-bigzero', ic: '💰', t: 'Dự án 0%' },
      { id: 'sec-week', ic: '📅', t: 'Theo tuần' },
      { id: 'sec-banqlda', ic: '🏛️', t: 'Ban QLDA' },
      { id: 'sec-rank', ic: '🏆', t: 'Xếp hạng' },
      { id: 'sec-detail', ic: '📋', t: 'Bảng chi tiết' },
      { id: 'sec-6to', ic: '🧩', t: '6 tổ' },
      { id: 'sec-wkstat', ic: '🗓️', t: 'Kế hoạch tuần' },
      { id: 'sec-zero', ic: '🚫', t: 'Chưa giải ngân' },
      { id: 'kn-card', ic: '💡', t: 'Kiến nghị' }
    ].filter(function (it) { var n = document.getElementById(it.id); return n && n.style.display !== 'none'; });

    var nav = track.parentNode;
    var btns = items.map(function (it) {
      var b = el('<button class="ln-btn" data-id="' + it.id + '"><span class="ln-ic">' + it.ic + '</span>' + esc(it.t) + '</button>');
      b.addEventListener('click', function (e) {
        if (e && e.preventDefault) e.preventDefault();
        var target = document.getElementById(it.id); if (!target) return;
        var off = nav.offsetHeight + 12;
        // chọn đúng phần tử cuộn: .lado-app nếu nó cuộn được, ngược lại là cửa sổ
        if (app.scrollHeight > app.clientHeight + 4) {
          var top = app.scrollTop + (target.getBoundingClientRect().top - app.getBoundingClientRect().top) - off;
          app.scrollTo({ top: top < 0 ? 0 : top, behavior: 'smooth' });
        } else {
          var y = (window.pageYOffset || document.documentElement.scrollTop || 0) + target.getBoundingClientRect().top - off;
          window.scrollTo({ top: y < 0 ? 0 : y, behavior: 'smooth' });
        }
        setActive(it.id);
        centerBtn(b);
      });
      track.appendChild(b);
      return b;
    });

    // chỉ cuộn NGANG thanh menu để nút active vào giữa (không đụng cuộn dọc)
    function centerBtn(b) {
      var t = b.offsetLeft - (track.clientWidth - b.offsetWidth) / 2;
      track.scrollTo({ left: t < 0 ? 0 : t, behavior: 'smooth' });
    }

    function setActive(id) {
      btns.forEach(function (b) { b.classList.toggle('on', b.getAttribute('data-id') === id); });
    }

    // scroll-spy: chuyên mục nào gần đỉnh thì sáng
    var ticking = false;
    function spy() {
      ticking = false;
      var ar = app.getBoundingClientRect();
      var line = nav.offsetHeight + 28;
      var current = items[0] && items[0].id;
      for (var i = 0; i < items.length; i++) {
        var n = document.getElementById(items[i].id); if (!n) continue;
        if ((n.getBoundingClientRect().top - ar.top) <= line) { current = items[i].id; }
      }
      setActive(current);
    }
    app.addEventListener('scroll', function () { if (!ticking) { ticking = true; requestAnimationFrame(spy); } }, { passive: true });
    spy();

    // mũi tên cuộn menu (desktop khi tràn)
    function upd() {
      var prev = document.getElementById('ln-prev'), next = document.getElementById('ln-next');
      var sc = track.scrollWidth - track.clientWidth - 2;
      if (prev) prev.style.display = track.scrollLeft > 2 ? '' : 'none';
      if (next) next.style.display = track.scrollLeft < sc ? '' : 'none';
    }
    var prevB = document.getElementById('ln-prev'), nextB = document.getElementById('ln-next');
    if (prevB) prevB.addEventListener('click', function () { track.scrollBy({ left: -220, behavior: 'smooth' }); });
    if (nextB) nextB.addEventListener('click', function () { track.scrollBy({ left: 220, behavior: 'smooth' }); });
    track.addEventListener('scroll', upd, { passive: true });
    window.addEventListener('resize', upd);
    upd();
  })();

  /* ---------- download experience ---------- */
  var ov = document.getElementById('lado-ov'), ovProg = document.getElementById('ov-prog'), ovSub = document.getElementById('ov-sub');
  var dlTimer = null, dlCancelled = false;
  function steps(on){ app.querySelectorAll('.ov-step').forEach(function(s){ var i=+s.dataset.s; s.classList.toggle('on', i===on); s.classList.toggle('done', i<on); }); }
  app.querySelectorAll('.dlbtn').forEach(function (b) {
    b.addEventListener('click', function () { startDownload(b.dataset.type); });
  });
  document.getElementById('ov-cancel').addEventListener('click', function(){ dlCancelled = true; clearTimeout(dlTimer); ov.classList.remove('on'); });

  /* week download list */
  (function () {
    var host = document.getElementById('week-list'); if (!host) return;
    var weeks = LADO_AI.weeks || [];
    if (!weeks.length) { host.innerHTML = '<p class="hint" style="margin:0">Chưa có báo cáo tuần nào được đính kèm.</p>'; return; }
    weeks.slice().reverse().forEach(function (w) {
      var row = el('<div class="wk-item"><div class="wk-info"><span class="wk-ky">' + esc(w.ky) + '</span>'
        + (w.tl != null ? '<span class="tl-badge ' + (w.tl >= 20 ? 'g' : (w.tl < 5 ? 'r' : 'a')) + '">' + pc(w.tl) + '</span>' : '') + '</div>'
        + '<button class="wk-dl' + (w.has ? '' : ' off') + '" data-idx="' + w.idx + '">' + (w.has ? '⬇ Tải báo cáo' : 'Chưa có file') + '</button></div>');
      host.appendChild(row);
      var btn = row.querySelector('.wk-dl');
      if (w.has) { btn.addEventListener('click', function () { startDownload('week_idx', w.idx); }); }
      else { btn.disabled = true; }
    });
  })();

  function startDownload(type, idx) {
    dlCancelled = false;
    ov.classList.add('on'); ovProg.style.width = '0'; ovSub.textContent = 'Vui lòng đợi trong giây lát…';
    var seq = [0, 1, 2, 3], i = 0;
    steps(0); ovProg.style.width = '12%';
    function tick() {
      if (dlCancelled) return;
      steps(seq[i]); ovProg.style.width = (18 + i * 24) + '%';
      i++;
      if (i < seq.length) { dlTimer = setTimeout(tick, 850); }
      else { dlTimer = setTimeout(finish, 850); }
    }
    dlTimer = setTimeout(tick, 500);

    function finish() {
      if (dlCancelled) return;
      var fd = new FormData();
      fd.append('action', 'lado_report'); fd.append('nonce', LADO_AI.nonce); fd.append('type', type);
      if (idx != null) { fd.append('idx', idx); }
      fetch(LADO_AI.ajax, { method: 'POST', body: fd }).then(function (r) { return r.json(); }).then(function (res) {
        ovProg.style.width = '100%';
        app.querySelectorAll('.ov-step').forEach(function (s) { s.classList.add('done'); s.classList.remove('on'); });
        if (res && res.success && res.data && res.data.url) {
          ovSub.innerHTML = '✅ Hoàn tất! Đang tải <b>' + esc(res.data.name) + '</b>…';
          var a = document.createElement('a'); a.href = res.data.url; a.download = res.data.name || ''; document.body.appendChild(a); a.click(); a.remove();
          setTimeout(function () { ov.classList.remove('on'); }, 1400);
        } else {
          ovSub.innerHTML = '⚠️ ' + esc((res && res.data && res.data.message) || 'Chưa có file báo cáo.');
          setTimeout(function () { ov.classList.remove('on'); }, 2600);
        }
      }).catch(function () { ovSub.textContent = '⚠️ Lỗi kết nối. Vui lòng thử lại.'; setTimeout(function () { ov.classList.remove('on'); }, 2400); });
    }
  }

  /* ---------- chat ---------- */
  var fab = document.getElementById('lado-fab'), chat = document.getElementById('lado-chat');
  var body = document.getElementById('chat-body'), input = document.getElementById('chat-in'), send = document.getElementById('chat-send');
  var history = [], busy = false, greeted = false;

  fab.addEventListener('click', function () { chat.classList.add('on'); fab.style.display = 'none'; if (!greeted) greet(); input.focus(); });
  document.getElementById('chat-x').addEventListener('click', function () { chat.classList.remove('on', 'fs'); var b = document.getElementById('chat-fs'); if (b) b.textContent = '⛶'; fab.style.display = 'flex'; });
  function chatConfirm(msg, onYes) {
    var ov = el('<div class="chat-confirm"><div class="cc-box"><div class="cc-ic">🗑</div><div class="cc-msg">' + esc(msg) + '</div><div class="cc-btns"><button class="cc-no">Hủy</button><button class="cc-yes">Xóa toàn bộ</button></div></div></div>');
    chat.appendChild(ov);
    requestAnimationFrame(function () { ov.classList.add('on'); });
    function close() { ov.classList.remove('on'); setTimeout(function () { ov.remove(); }, 180); }
    ov.querySelector('.cc-no').addEventListener('click', close);
    ov.addEventListener('click', function (e) { if (e.target === ov) close(); });
    ov.querySelector('.cc-yes').addEventListener('click', function () { close(); onYes(); });
  }
  document.getElementById('chat-clear').addEventListener('click', function () {
    chatConfirm('Xóa toàn bộ nội dung cuộc trò chuyện? Hành động này không thể hoàn tác.', function () {
      history = []; busy = false; send.disabled = false;
      body.innerHTML = ''; greeted = false; greet(); input.focus();
    });
  });
  document.getElementById('chat-fs').addEventListener('click', function () {
    var on = chat.classList.toggle('fs');
    this.textContent = on ? '🗗' : '⛶';
    this.title = on ? 'Thu nhỏ' : 'Phóng to toàn màn hình';
    body.scrollTop = body.scrollHeight; input.focus();
  });

  // ---- Tải báo cáo ngay trong chat (tự lấy file từ các mục đã nhập) ----
  function dlAjax(type, idx) {
    var fd = new FormData();
    fd.append('action', 'lado_report'); fd.append('nonce', LADO_AI.nonce); fd.append('type', type);
    if (idx != null && idx !== '') { fd.append('idx', idx); }
    fetch(LADO_AI.ajax, { method: 'POST', body: fd }).then(function (r) { return r.json(); }).then(function (res) {
      if (res && res.success && res.data && res.data.url) {
        var a = document.createElement('a'); a.href = res.data.url; a.download = res.data.name || ''; document.body.appendChild(a); a.click(); a.remove();
      } else { bubble('⚠️ ' + ((res && res.data && res.data.message) || 'Chưa có file này trong hệ thống.'), 'bot'); }
    }).catch(function () { bubble('⚠️ Lỗi kết nối khi tải file.', 'bot'); });
  }
  function dlIntent(q) {
    var sQ = unrm(q);
    if (!/(tai|download|cho toi file|gui file|lay file|xin file)/.test(sQ)) return null;
    if (!/(bao cao|phu luc|file|to )/.test(sQ)) return null;
    var btns = [];
    // Ngày được yêu cầu: "10/6", "10-6-2026" hoặc "ngày 10 tháng 6"
    var mD = q.match(/(\d{1,2})\s*[\/\-.]\s*(\d{1,2})(?:\s*[\/\-.]\s*(\d{2,4}))?/);
    if (!mD) { var mT = sQ.match(/ngay (\d{1,2}) thang (\d{1,2})/); if (mT) mD = [mT[0], mT[1], mT[2], '']; }
    function sameD(fdate) { if (!mD) return true; var p = String(fdate || '').split('/'); return (+p[0] === +mD[1]) && (+p[1] === +mD[2]); }
    var dLbl = mD ? (' ngày ' + (+mD[1]) + '/' + (+mD[2])) : '';
    function pick(list) {
      var arr = (list || []).slice().reverse();
      if (!mD) return arr[0] || null;
      for (var i = 0; i < arr.length; i++) { if (sameD(arr[i].date)) return arr[i]; }
      return null;
    }
    var mTo = sQ.match(/to(?: cong tac)?(?: so)? ([1-6])/);
    if (mTo) {
      var so = +mTo[1];
      var fs = (LADO_AI.tct_files || []).filter(function (f) { return +f.to === so; });
      var hit = pick(fs);
      if (hit) btns.push({ ic: '🧭', label: 'Báo cáo Tổ công tác số ' + so + ' — ngày ' + hit.date, url: hit.url });
      else if (fs.length) { var lt = fs[fs.length - 1]; btns.push({ ic: '🧭', label: 'Tổ ' + so + dLbl + ': chưa có file — bản gần nhất ngày ' + lt.date, url: lt.url }); }
      else btns.push({ ic: '🧭', label: 'Tổ ' + so + ': chưa có file trong hệ thống', url: '' });
    }
    if (/phu luc/.test(sQ)) {
      var ph = pick(LADO_AI.phuluc_files);
      if (ph) btns.push({ ic: '📎', label: 'Phụ lục giải ngân từng dự án — ngày ' + ph.date, url: ph.url });
      else if ((LADO_AI.phuluc_files || []).length) { var pl2 = LADO_AI.phuluc_files[LADO_AI.phuluc_files.length - 1]; btns.push({ ic: '📎', label: 'Phụ lục' + dLbl + ': chưa có — bản gần nhất ngày ' + pl2.date, url: pl2.url }); }
    }
    if (/(6 to|06 to|sau to|thong ke.*to)/.test(sQ) && !mTo) {
      var sx = pick(LADO_AI.sixto_files);
      if (sx) btns.push({ ic: '🧩', label: 'Thống kê 06 tổ công tác — ngày ' + sx.date, url: sx.url });
      else if ((LADO_AI.sixto_files || []).length) { var sx2 = LADO_AI.sixto_files[LADO_AI.sixto_files.length - 1]; btns.push({ ic: '🧩', label: 'Thống kê 06 tổ' + dLbl + ': chưa có — bản gần nhất ngày ' + sx2.date, url: sx2.url }); }
    }
    if (/bao cao ngay|bc ngay|theo ngay/.test(sQ) || (/ngay/.test(sQ) && /bao cao/.test(sQ) && !mTo)) {
      if (mD) {
        var dHit = null;
        (LADO_AI.days || []).forEach(function (d) { if (d.dl && sameD(d.date)) dHit = d; });
        if (dHit) btns.push({ ic: '📆', label: 'Báo cáo ngày ' + dHit.date, ajax: 'day_idx', idx: dHit.idx });
        else {
          var avail = (LADO_AI.days || []).filter(function (d) { return d.dl; }).slice(-3).reverse();
          btns.push({ ic: '📆', label: 'Báo cáo' + dLbl + ': chưa có file trong hệ thống', url: '' });
          avail.forEach(function (d) { btns.push({ ic: '📆', label: 'Báo cáo ngày ' + d.date, ajax: 'day_idx', idx: d.idx }); });
        }
      } else if (LADO_AI.has_day) { btns.push({ ic: '📆', label: 'Báo cáo NGÀY mới nhất', ajax: 'day' }); }
    }
    if (/tuan/.test(sQ)) btns.push({ ic: '📄', label: 'Báo cáo TUẦN mới nhất', ajax: 'week' });
    if (/thang/.test(sQ)) btns.push({ ic: '📑', label: 'Báo cáo THÁNG', ajax: 'month' });
    if (!btns.length) {
      // hỏi chung "tải báo cáo" -> đưa menu đầy đủ
      if (LADO_AI.has_day) btns.push({ ic: '📆', label: 'Báo cáo NGÀY mới nhất', ajax: 'day' });
      var pf2 = (LADO_AI.phuluc_files || []).slice().reverse();
      if (pf2.length) btns.push({ ic: '📎', label: 'Phụ lục từng dự án — ' + pf2[0].date, url: pf2[0].url });
      var sf2 = (LADO_AI.sixto_files || []).slice().reverse();
      if (sf2.length) btns.push({ ic: '🧩', label: 'Thống kê 06 tổ — ' + sf2[0].date, url: sf2[0].url });
      var byTo = {};
      (LADO_AI.tct_files || []).forEach(function (f) { byTo[f.to] = f; });
      Object.keys(byTo).sort().forEach(function (k) { btns.push({ ic: '🧭', label: 'Báo cáo Tổ ' + k + ' — ' + byTo[k].date, url: byTo[k].url }); });
    }
    return btns.length ? btns : null;
  }
  function renderDl(btns) {
    var m = el('<div class="msg bot"></div>');
    var h = '<p>📥 Đồng chí có thể tải trực tiếp tại đây:</p><div class="chat-dls">';
    btns.forEach(function (b, i) {
      if (b.ajax) h += '<button class="chat-dl" data-ajax="' + esc(b.ajax) + '"' + (b.idx != null ? ' data-idx="' + b.idx + '"' : '') + '><span class="cd-ic">' + b.ic + '</span><span class="cd-tx">' + esc(b.label) + '</span><span class="cd-arr">⬇</span></button>';
      else if (b.url) h += '<a class="chat-dl" href="' + esc(b.url) + '" download target="_blank" rel="noopener"><span class="cd-ic">' + b.ic + '</span><span class="cd-tx">' + esc(b.label) + '</span><span class="cd-arr">⬇</span></a>';
      else h += '<div class="chat-dl off"><span class="cd-ic">' + b.ic + '</span><span class="cd-tx">' + esc(b.label) + '</span></div>';
    });
    h += '</div>';
    m.innerHTML = h;
    m.querySelectorAll('.chat-dl[data-ajax]').forEach(function (btn) {
      btn.addEventListener('click', function () { dlAjax(btn.getAttribute('data-ajax'), btn.getAttribute('data-idx')); });
    });
    body.appendChild(m); body.scrollTop = body.scrollHeight;
  }

  function splitRow(s) { s = s.trim().replace(/^\|/, '').replace(/\|$/, ''); return s.split('|').map(function (x) { return x.trim(); }); }
  function inlineMd(t) {
    t = esc(t);
    t = t.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
    t = t.replace(/`([^`]+)`/g, '<code>$1</code>');
    t = t.replace(/(\d[\d.,]*\s?%)/g, '<span class="hl">$1</span>');
    t = t.replace(/(\d[\d.,]*\s?tr\.đ)/g, '<span class="amt-hl">$1</span>');
    t = t.replace(/\*/g, '');
    return t;
  }
  function mdToHtml(src) {
    var lines = String(src).replace(/\r/g, '').split('\n'), html = [], i = 0;
    while (i < lines.length) {
      var ln = lines[i];
      if (/^\s*$/.test(ln)) { i++; continue; }
      if (ln.indexOf('|') > -1 && i + 1 < lines.length && /^[\s|:\-]+$/.test(lines[i + 1]) && lines[i + 1].indexOf('-') > -1) {
        var head = splitRow(ln); i += 2; var rows = [];
        while (i < lines.length && lines[i].indexOf('|') > -1 && !/^\s*$/.test(lines[i])) { rows.push(splitRow(lines[i])); i++; }
        var t = '<table><thead><tr>' + head.map(function (h) { return '<th>' + inlineMd(h) + '</th>'; }).join('') + '</tr></thead><tbody>';
        rows.forEach(function (r) { t += '<tr>' + r.map(function (c) { var num = /\d/.test(c) && /^[\d.,%\s+\-]+$/.test(c.trim()); return '<td class="' + (num ? 'num' : '') + '">' + inlineMd(c) + '</td>'; }).join('') + '</tr>'; });
        html.push(t + '</tbody></table>'); continue;
      }
      var hm = ln.match(/^\s*#{1,4}\s+(.*)$/);
      if (hm) { html.push('<h4>' + inlineMd(hm[1]) + '</h4>'); i++; continue; }
      if (/^\s*[-*•]\s+/.test(ln)) {
        var items = [];
        while (i < lines.length && /^\s*[-*•]\s+/.test(lines[i])) { items.push(inlineMd(lines[i].replace(/^\s*[-*•]\s+/, ''))); i++; }
        html.push('<ul>' + items.map(function (x) { return '<li>' + x + '</li>'; }).join('') + '</ul>'); continue;
      }
      if (/^\s*\d+[.)]\s+/.test(ln)) {
        var its = [];
        while (i < lines.length && /^\s*\d+[.)]\s+/.test(lines[i])) { its.push(inlineMd(lines[i].replace(/^\s*\d+[.)]\s+/, ''))); i++; }
        html.push('<ol>' + its.map(function (x) { return '<li>' + x + '</li>'; }).join('') + '</ol>'); continue;
      }
      var para = [ln]; i++;
      while (i < lines.length && !/^\s*$/.test(lines[i]) && lines[i].indexOf('|') < 0 && !/^\s*[-*•]\s+/.test(lines[i]) && !/^\s*\d+[.)]\s+/.test(lines[i]) && !/^\s*#{1,4}\s+/.test(lines[i])) { para.push(lines[i]); i++; }
      html.push('<p>' + para.map(inlineMd).join('<br>') + '</p>');
    }
    return html.join('');
  }

  function bubble(text, cls) {
    var m = el('<div class="msg ' + cls + '"></div>');
    if (cls === 'bot') {
      m.innerHTML = mdToHtml(text);
      var cp = el('<button class="msg-copy" title="Sao chép câu trả lời">📋</button>');
      cp.addEventListener('click', function () {
        var plain = String(text).replace(/\*\*/g, '').replace(/`/g, '');
        function done() { cp.textContent = '✓'; cp.classList.add('ok'); setTimeout(function () { cp.textContent = '📋'; cp.classList.remove('ok'); }, 1600); }
        if (navigator.clipboard && navigator.clipboard.writeText) { navigator.clipboard.writeText(plain).then(done).catch(function () { fallbackCopy(plain); done(); }); }
        else { fallbackCopy(plain); done(); }
      });
      m.appendChild(cp);
    } else { m.textContent = text; }
    body.appendChild(m); body.scrollTop = body.scrollHeight; return m;
  }
  function fallbackCopy(t) {
    var ta = document.createElement('textarea'); ta.value = t; ta.style.position = 'fixed'; ta.style.opacity = '0';
    document.body.appendChild(ta); ta.select();
    try { document.execCommand('copy'); } catch (e) {}
    ta.remove();
  }
  function greet() {
    greeted = true;
    bubble('Xin chào đồng chí! Tôi là ' + NAME + ', trợ lý ảo về giải ngân vốn đầu tư công tỉnh Lâm Đồng. Đồng chí cần tra cứu nội dung gì ạ?', 'bot');
    var sug = el('<div class="chips"></div>');
    ['Tỷ lệ giải ngân toàn tỉnh hiện nay?', 'Khối nào giải ngân thấp nhất?', '5 Ban QLDA kém nhất là ai?', 'So với kế hoạch Thủ tướng giao đạt bao nhiêu?'].forEach(function (q) {
      var c = el('<button class="chip"></button>'); c.textContent = q; c.addEventListener('click', function () { input.value = q; doSend(); }); sug.appendChild(c);
    });
    body.appendChild(sug); body.scrollTop = body.scrollHeight;
  }
  input.addEventListener('input', function () { this.style.height = 'auto'; this.style.height = Math.min(90, this.scrollHeight) + 'px'; });
  input.addEventListener('keydown', function (e) { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); doSend(); } });
  send.addEventListener('click', doSend);

  function doSend() {
    var q = input.value.trim(); if (!q || busy) return;
    var chips = body.querySelector('.chips'); if (chips) chips.remove();
    bubble(q, 'me'); history.push({ role: 'user', content: q });
    input.value = ''; input.style.height = 'auto';
    var dls = dlIntent(q);
    if (dls) {
      renderDl(dls);
      history.push({ role: 'assistant', content: '(Đã hiển thị các nút tải file báo cáo theo yêu cầu.)' });
      input.focus();
      return;
    }
    busy = true; send.disabled = true;
    var typ = el('<div class="msg bot thinking"><div class="lado-think"><span class="lt-orb"><i></i><i></i><i></i></span><span class="lt-tx">LaDo-AI đang phân tích số liệu…</span></div></div>');
    body.appendChild(typ); body.scrollTop = body.scrollHeight;
    var thinkMsgs = ['Đang tra cứu số liệu giải ngân…', 'Đang đối chiếu kế hoạch vốn…', 'Đang tổng hợp theo chủ đầu tư…', 'Sắp có kết quả cho đồng chí…'];
    var tIdx = 0; var txEl = typ.querySelector('.lt-tx');
    var thinkTimer = setInterval(function () { tIdx = (tIdx + 1) % thinkMsgs.length; if (txEl) { txEl.style.opacity = '0'; setTimeout(function () { if (txEl) { txEl.textContent = thinkMsgs[tIdx]; txEl.style.opacity = '1'; } }, 180); } }, 1700);

    var fd = new FormData();
    fd.append('action', 'lado_chat'); fd.append('nonce', LADO_AI.nonce); fd.append('history', JSON.stringify(history));
    fetch(LADO_AI.ajax, { method: 'POST', body: fd }).then(function (r) { return r.json(); }).then(function (res) {
      clearInterval(thinkTimer); typ.remove();
      if (res && res.success) { var mb2 = bubble(res.data.reply, 'bot'); mb2.classList.add('msg-in'); history.push({ role: 'assistant', content: res.data.reply }); }
      else { bubble('LaDo-AI gặp lỗi kết nối.', 'err'); }
    }).catch(function () { clearInterval(thinkTimer); typ.remove(); bubble('LaDo-AI gặp lỗi kết nối.', 'err'); })
      .finally(function () { busy = false; send.disabled = false; input.focus(); });
  }
})();
