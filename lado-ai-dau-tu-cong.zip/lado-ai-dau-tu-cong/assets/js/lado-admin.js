jQuery(function ($) {
  // Image picker (avatar)
  $('.lado-pick-img').on('click', function (e) {
    e.preventDefault();
    var target = $(this).data('target');
    var frame = wp.media({ title: 'Chọn logo/icon trợ lý', button: { text: 'Dùng ảnh này' }, library: { type: 'image' }, multiple: false });
    frame.on('select', function () {
      var a = frame.state().get('selection').first().toJSON();
      $('#' + target).val(a.id);
      var url = (a.sizes && a.sizes.thumbnail) ? a.sizes.thumbnail.url : a.url;
      $('#' + target + '-preview').attr('src', url).show();
    });
    frame.open();
  });
  $('.lado-clear-img').on('click', function (e) {
    e.preventDefault();
    var target = $(this).data('target');
    $('#' + target).val(0);
    $('#' + target + '-preview').hide().attr('src', '');
  });

  // Media picker for single report fields (tuần/tháng)
  $('.lado-pick').on('click', function (e) {
    e.preventDefault();
    var target = $(this).data('target');
    var frame = wp.media({
      title: 'Chọn file báo cáo (.docx)',
      button: { text: 'Dùng file này' },
      library: { type: ['application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'application/msword'] },
      multiple: false
    });
    frame.on('select', function () {
      var a = frame.state().get('selection').first().toJSON();
      $('#' + target).val(a.id);
      $('.lado-file-name[data-for="' + target + '"]').text(a.filename || a.title || ('#' + a.id));
    });
    frame.open();
  });

  // ---- Weekly reports manager ----
  function rowTpl() {
    return '<tr class="wk-row">' +
      '<td><input type="text" class="wk-ky" placeholder="Tuần 23" /></td>' +
      '<td><input type="number" step="0.01" class="wk-tl" value="0" /></td>' +
      '<td><input type="hidden" class="wk-file" value="0" /><button type="button" class="button wk-pick">Chọn file…</button></td>' +
      '<td><button type="button" class="button wk-del">✕</button></td></tr>';
  }
  $('#wk-add').on('click', function () { $('#lado-weeks tbody').append(rowTpl()); });
  $('#lado-weeks').on('click', '.wk-del', function () { $(this).closest('tr').remove(); });
  $('#lado-weeks').on('click', '.wk-pick', function (e) {
    e.preventDefault();
    var $btn = $(this), $row = $btn.closest('tr');
    var frame = wp.media({
      title: 'Chọn file báo cáo tuần (.docx)',
      button: { text: 'Dùng file này' },
      library: { type: ['application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'application/msword'] },
      multiple: false
    });
    frame.on('select', function () {
      var a = frame.state().get('selection').first().toJSON();
      $row.find('.wk-file').val(a.id);
      $btn.text(a.filename || a.title || ('#' + a.id));
    });
    frame.open();
  });

  // Serialize weeks on submit
  $('form').on('submit', function () {
    var weeks = [];
    $('#lado-weeks tbody tr.wk-row').each(function () {
      var ky = $(this).find('.wk-ky').val();
      if (!ky || !ky.trim()) return;
      weeks.push({
        ky: ky.trim(),
        tl: parseFloat($(this).find('.wk-tl').val()) || 0,
        file: parseInt($(this).find('.wk-file').val(), 10) || 0
      });
    });
    $('#weeks_json').val(JSON.stringify(weeks));
  });
});
