jQuery(function ($) {
  $('.lado-pick').on('click', function (e) {
    e.preventDefault();
    var target = $(this).data('target');
    var frame = wp.media({
      title: 'Chọn file báo cáo (.docx)',
      button: { text: 'Dùng file này' },
      library: { type: ['application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'application/msword'] },
      multiple: false
    });
    frame.on('select', function () {
      var a = frame.state().get('selection').first().toJSON();
      $('#' + target).val(a.id);
      $('.lado-file-name[data-for="' + target + '"]').text(a.filename || a.title || ('#' + a.id));
    });
    frame.open();
  });
});
