<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class LaDo_AI_Shortcode {

	public function __construct() {
		add_shortcode( 'lado_ai_dashboard', array( $this, 'render' ) );
	}

	public function render( $atts ) {
		$o = get_option( LADO_AI_OPT, lado_ai_default_settings() );
		$data = json_decode( $o['data'], true );
		if ( ! is_array( $data ) ) { $data = array(); }

		wp_enqueue_script( 'chartjs', 'https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js', array(), '4.4.1', true );
		wp_enqueue_style( 'lado-app', LADO_AI_URL . 'assets/css/lado-app.css', array(), LADO_AI_VERSION );
		wp_enqueue_script( 'lado-app', LADO_AI_URL . 'assets/js/lado-app.js', array( 'chartjs' ), LADO_AI_VERSION, true );

		wp_localize_script( 'lado-app', 'LADO_AI', array(
			'ajax'      => admin_url( 'admin-ajax.php' ),
			'nonce'     => wp_create_nonce( 'lado_ai_front' ),
			'name'      => $o['assistant_name'],
			'data'      => $data,
			'has_week'  => ! empty( $o['report_week'] ),
			'has_month' => ! empty( $o['report_month'] ),
		) );

		ob_start();
		?>
		<div id="lado-app" class="lado-app" data-assistant="<?php echo esc_attr( $o['assistant_name'] ); ?>">
			<div class="lado-loading"><div class="lado-spinner"></div><p>Đang khởi tạo bảng điều khiển…</p></div>
		</div>
		<?php
		return ob_get_clean();
	}
}
