<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class LaDo_AI_Shortcode {

	public function __construct() {
		add_shortcode( 'lado_ai_dashboard', array( $this, 'render' ) );
	}

	public function render( $atts ) {
		$o = get_option( LADO_AI_OPT, lado_ai_default_settings() );
		$data = json_decode( $o['data'], true );
		if ( ! is_array( $data ) ) { $data = array(); }

		$css_path = LADO_AI_DIR . 'assets/css/lado-app.css';
		$js_path  = LADO_AI_DIR . 'assets/js/lado-app.js';
		$css_ver  = file_exists( $css_path ) ? (string) filemtime( $css_path ) : LADO_AI_VERSION;
		$js_ver   = file_exists( $js_path ) ? (string) filemtime( $js_path ) : LADO_AI_VERSION;

		wp_enqueue_script( 'chartjs', 'https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js', array(), '4.4.1', true );
		wp_enqueue_script( 'lado-xlsx', 'https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js', array(), '0.18.5', true );
		wp_enqueue_style( 'lado-app', LADO_AI_URL . 'assets/css/lado-app.css', array(), $css_ver );
		wp_enqueue_script( 'lado-app', LADO_AI_URL . 'assets/js/lado-app.js', array( 'chartjs', 'lado-xlsx' ), $js_ver, true );

		$weeks = array();
		foreach ( (array) ( $o['weeks'] ?? array() ) as $i => $wk ) {
			$url = ! empty( $wk['file'] ) ? wp_get_attachment_url( $wk['file'] ) : '';
			$weeks[] = array(
				'ky'   => isset( $wk['ky'] ) ? $wk['ky'] : '',
				'tl'   => isset( $wk['tl'] ) ? (float) $wk['tl'] : 0,
				'idx'  => $i,
				'has'  => $url ? true : false,
				'name' => $url ? basename( $url ) : '',
			);
		}

		$avatar = ! empty( $o['avatar'] ) ? wp_get_attachment_image_url( $o['avatar'], 'thumbnail' ) : '';
		$kn = lado_ai_get_kiennghi();
		$kn_meta = array(
			'has'     => ! empty( $kn['items'] ),
			'total'   => isset( $kn['total'] ) ? (int) $kn['total'] : 0,
			'updated' => isset( $kn['updated'] ) ? $kn['updated'] : '',
			'by_khoi' => isset( $kn['by_khoi'] ) ? $kn['by_khoi'] : array(),
		);
		$days = array();
		foreach ( (array) ( $o['days'] ?? array() ) as $i => $dp ) {
			$days[] = array(
				'date' => isset( $dp['date'] ) ? $dp['date'] : '',
				'tl'   => isset( $dp['tl'] ) ? (float) $dp['tl'] : 0,
				'ttg'  => isset( $dp['ttg'] ) ? (float) $dp['ttg'] : 0,
				'gn'   => isset( $dp['gn'] ) ? (float) $dp['gn'] : 0,
				'gn26' => isset( $dp['gn26'] ) ? (float) $dp['gn26'] : 0,
				'idx'  => $i,
				'dl'   => ! empty( $dp['att'] ),
			);
		}
		$tct_files = array();
		foreach ( (array) ( $o['tct_files'] ?? array() ) as $tfp ) {
			$ut = ! empty( $tfp['att'] ) ? wp_get_attachment_url( (int) $tfp['att'] ) : '';
			if ( $ut ) { $tct_files[] = array( 'to' => (int) ( $tfp['to'] ?? 0 ), 'date' => isset( $tfp['date'] ) ? $tfp['date'] : '', 'url' => $ut ); }
		}
		$phuluc_files = array();
		foreach ( (array) ( $o['phuluc_files'] ?? array() ) as $pfp ) {
			$up = ! empty( $pfp['att'] ) ? wp_get_attachment_url( (int) $pfp['att'] ) : '';
			if ( $up ) { $phuluc_files[] = array( 'date' => isset( $pfp['date'] ) ? $pfp['date'] : '', 'url' => $up ); }
		}
		$sixto_files = array();
		foreach ( (array) ( $o['sixto_files'] ?? array() ) as $sfp ) {
			$u6 = ! empty( $sfp['att'] ) ? wp_get_attachment_url( (int) $sfp['att'] ) : '';
			if ( $u6 ) { $sixto_files[] = array( 'date' => isset( $sfp['date'] ) ? $sfp['date'] : '', 'url' => $u6 ); }
		}
		$dv = lado_ai_get_donvi();
		$dv_meta = array(
			'has'      => ! empty( $dv['units'] ),
			'updated'  => isset( $dv['updated'] ) ? $dv['updated'] : '',
			'big_zero' => isset( $dv['big_zero'] ) ? array_values( $dv['big_zero'] ) : array(),
			'big_zero_kb' => isset( $dv['big_zero_kb'] ) ? array_values( $dv['big_zero_kb'] ) : array(),
			'big_zero_kb_asof' => isset( $dv['big_zero_kb_asof'] ) ? $dv['big_zero_kb_asof'] : '',
			'ban_qlda' => isset( $dv['ban_qlda'] ) ? array_values( $dv['ban_qlda'] ) : array(),
			'weekly_status' => isset( $dv['weekly_status'] ) ? $dv['weekly_status'] : null,
			'dk_traj' => isset( $dv['dk_traj'] ) ? $dv['dk_traj'] : array(),
		);

		wp_localize_script( 'lado-app', 'LADO_AI', array(
			'ajax'      => admin_url( 'admin-ajax.php' ),
			'nonce'     => wp_create_nonce( 'lado_ai_front' ),
			'name'      => $o['assistant_name'],
			'avatar'    => $avatar,
			'data'      => $data,
			'has_week'  => ! empty( $o['report_week'] ),
			'has_month' => ! empty( $o['report_month'] ),
			'has_day'   => ! empty( $o['report_day'] ),
			'weeks'     => $weeks,
			'days'      => $days,
			'sixto_files' => $sixto_files,
			'phuluc_files' => $phuluc_files,
			'tct_files' => $tct_files,
			'kn'        => $kn_meta,
			'donvi'     => $dv_meta,
		) );

		ob_start();
		?>
		<div id="lado-app" class="lado-app" data-assistant="<?php echo esc_attr( $o['assistant_name'] ); ?>">
			<div class="lado-loading"><div class="lado-spinner"></div><p>Đang khởi tạo bảng điều khiển…</p></div>
		</div>
		<?php
		return ob_get_clean();
	}
}
