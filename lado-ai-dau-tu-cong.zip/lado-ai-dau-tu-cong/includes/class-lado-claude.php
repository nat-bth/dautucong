<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Gọi Claude Messages API phía máy chủ (API key không bao giờ lộ ra trình duyệt).
 */
class LaDo_AI_Claude {

	const ENDPOINT = 'https://api.anthropic.com/v1/messages';
	const VERSION  = '2023-06-01';

	/**
	 * @param array  $history  [ ['role'=>'user'|'assistant','content'=>'...'], ... ]
	 * @return array [ 'ok'=>bool, 'text'=>string, 'error'=>string ]
	 */
	public static function ask( $history ) {
		$key = trim( lado_ai_get( 'api_key' ) );
		if ( '' === $key ) {
			return array( 'ok' => false, 'error' => 'Chưa cấu hình API key của Claude trong trang quản trị.' );
		}
		$model = trim( lado_ai_get( 'model', 'claude-opus-4-8' ) );

		$system = self::build_system_prompt();

		$messages = array();
		foreach ( $history as $m ) {
			$role = ( isset( $m['role'] ) && 'assistant' === $m['role'] ) ? 'assistant' : 'user';
			$content = isset( $m['content'] ) ? wp_strip_all_tags( (string) $m['content'] ) : '';
			$content = mb_substr( $content, 0, 4000 );
			if ( '' !== trim( $content ) ) {
				$messages[] = array( 'role' => $role, 'content' => $content );
			}
		}
		if ( empty( $messages ) ) {
			return array( 'ok' => false, 'error' => 'Nội dung câu hỏi trống.' );
		}

		$body = array(
			'model'       => $model,
			'max_tokens'  => (int) lado_ai_get( 'max_tokens', 1200 ),
			'temperature' => (float) lado_ai_get( 'temperature', 0.2 ),
			'system'      => $system,
			'messages'    => $messages,
		);

		$resp = wp_remote_post( self::ENDPOINT, array(
			'timeout' => 60,
			'headers' => array(
				'content-type'      => 'application/json',
				'x-api-key'         => $key,
				'anthropic-version' => self::VERSION,
			),
			'body'    => wp_json_encode( $body ),
		) );

		if ( is_wp_error( $resp ) ) {
			return array( 'ok' => false, 'error' => 'Lỗi kết nối: ' . $resp->get_error_message() );
		}
		$code = wp_remote_retrieve_response_code( $resp );
		$data = json_decode( wp_remote_retrieve_body( $resp ), true );

		if ( 200 !== (int) $code ) {
			$msg = isset( $data['error']['message'] ) ? $data['error']['message'] : ( 'Mã lỗi HTTP ' . $code );
			return array( 'ok' => false, 'error' => 'API trả về lỗi: ' . $msg );
		}

		$text = '';
		if ( isset( $data['content'] ) && is_array( $data['content'] ) ) {
			foreach ( $data['content'] as $blk ) {
				if ( isset( $blk['type'], $blk['text'] ) && 'text' === $blk['type'] ) {
					$text .= $blk['text'];
				}
			}
		}
		$text = trim( $text );
		if ( '' === $text ) {
			return array( 'ok' => false, 'error' => 'Không nhận được nội dung trả lời.' );
		}
		return array( 'ok' => true, 'text' => $text );
	}

	protected static function build_system_prompt() {
		$persona = lado_ai_get( 'persona' );
		$data    = lado_ai_get( 'data' );
		$kb      = lado_ai_get( 'kb_text' );

		// Giới hạn ngữ cảnh để tránh vượt quá token
		$kb = mb_substr( (string) $kb, 0, 40000 );

		$ctx  = "=== SỐ LIỆU TÓM TẮT (JSON) ===\n" . $data . "\n\n";
		if ( '' !== trim( $kb ) ) {
			$ctx .= "=== NGỮ CẢNH TỪ FILE CƠ SỞ DỮ LIỆU DO QUẢN TRỊ VIÊN TẢI LÊN ===\n" . $kb . "\n";
		}

		return $persona . "\n\nLuôn dựa trên NGỮ CẢNH dưới đây để trả lời. Đơn vị tiền là triệu đồng trừ khi ghi rõ khác.\n\nĐỊNH DẠNG TRẢ LỜI: viết tiếng Việt rõ ràng, có thể dùng tiêu đề ngắn, danh sách gạch đầu dòng (dùng dấu \"-\"), in đậm bằng **...**, và bảng Markdown (dùng dấu |) khi so sánh số liệu. Không lạm dụng ký tự *; không chèn ký tự lạ. Khi nêu số liệu, ưu tiên trình bày bằng bảng để dễ đọc.\n\n" . $ctx;
	}
}
