<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Gọi Claude Messages API phía máy chủ (API key không bao giờ lộ ra trình duyệt).
 */
class LaDo_AI_Claude {

	const ENDPOINT = 'https://api.anthropic.com/v1/messages';
	const VERSION  = '2023-06-01';
	const DEEPSEEK_ENDPOINT = 'https://api.deepseek.com/chat/completions';

	/**
	 * @param array  $history  [ ['role'=>'user'|'assistant','content'=>'...'], ... ]
	 * @return array [ 'ok'=>bool, 'text'=>string, 'error'=>string ]
	 */
	public static function ask( $history ) {
		$provider = trim( lado_ai_get( 'ai_provider', 'anthropic' ) );

		$messages = array();
		foreach ( $history as $m ) {
			$role = ( isset( $m['role'] ) && 'assistant' === $m['role'] ) ? 'assistant' : 'user';
			$content = isset( $m['content'] ) ? wp_strip_all_tags( (string) $m['content'] ) : '';
			$content = mb_substr( $content, 0, 4000 );
			if ( '' !== trim( $content ) ) {
				$messages[] = array( 'role' => $role, 'content' => $content );
			}
		}
		if ( empty( $messages ) ) {
			return array( 'ok' => false, 'error' => 'Nội dung câu hỏi trống.' );
		}
		$system = self::build_system_prompt();

		if ( 'deepseek' === $provider ) {
			return self::ask_deepseek( $system, $messages );
		}
		return self::ask_anthropic( $system, $messages );
	}

	protected static function ask_anthropic( $system, $messages ) {
		$key = trim( lado_ai_get( 'api_key' ) );
		if ( '' === $key ) {
			return array( 'ok' => false, 'error' => 'Chưa cấu hình API key của Claude trong trang quản trị.' );
		}
		$model = trim( lado_ai_get( 'model', 'claude-opus-4-8' ) );

		$body = array(
			'model'       => $model,
			'max_tokens'  => (int) lado_ai_get( 'max_tokens', 1200 ),
			'temperature' => (float) lado_ai_get( 'temperature', 0.2 ),
			'system'      => $system,
			'messages'    => $messages,
		);

		$resp = wp_remote_post( self::ENDPOINT, array(
			'timeout' => 60,
			'headers' => array(
				'content-type'      => 'application/json',
				'x-api-key'         => $key,
				'anthropic-version' => self::VERSION,
			),
			'body'    => wp_json_encode( $body ),
		) );

		if ( is_wp_error( $resp ) ) {
			return array( 'ok' => false, 'error' => 'Lỗi kết nối: ' . $resp->get_error_message() );
		}
		$code = wp_remote_retrieve_response_code( $resp );
		$data = json_decode( wp_remote_retrieve_body( $resp ), true );

		if ( 200 !== (int) $code ) {
			$msg = isset( $data['error']['message'] ) ? $data['error']['message'] : ( 'Mã lỗi HTTP ' . $code );
			return array( 'ok' => false, 'error' => 'API trả về lỗi: ' . $msg );
		}

		$text = '';
		if ( isset( $data['content'] ) && is_array( $data['content'] ) ) {
			foreach ( $data['content'] as $blk ) {
				if ( isset( $blk['type'], $blk['text'] ) && 'text' === $blk['type'] ) {
					$text .= $blk['text'];
				}
			}
		}
		$text = trim( $text );
		if ( '' === $text ) {
			return array( 'ok' => false, 'error' => 'Không nhận được nội dung trả lời.' );
		}
		return array( 'ok' => true, 'text' => $text );
	}

	/** DeepSeek (tương thích OpenAI Chat Completions). */
	protected static function ask_deepseek( $system, $messages ) {
		$key = trim( lado_ai_get( 'deepseek_key' ) );
		if ( '' === $key ) {
			return array( 'ok' => false, 'error' => 'Chưa cấu hình API key của DeepSeek trong trang quản trị.' );
		}
		$model = trim( lado_ai_get( 'deepseek_model', 'deepseek-chat' ) );
		if ( '' === $model ) { $model = 'deepseek-chat'; }

		$msgs = array( array( 'role' => 'system', 'content' => $system ) );
		foreach ( $messages as $m ) { $msgs[] = $m; }

		$body = array(
			'model'       => $model,
			'messages'    => $msgs,
			'max_tokens'  => (int) lado_ai_get( 'max_tokens', 1200 ),
			'temperature' => (float) lado_ai_get( 'temperature', 0.2 ),
			'stream'      => false,
		);

		$resp = wp_remote_post( self::DEEPSEEK_ENDPOINT, array(
			'timeout' => 60,
			'headers' => array(
				'content-type'  => 'application/json',
				'authorization' => 'Bearer ' . $key,
			),
			'body'    => wp_json_encode( $body ),
		) );

		if ( is_wp_error( $resp ) ) {
			return array( 'ok' => false, 'error' => 'Lỗi kết nối: ' . $resp->get_error_message() );
		}
		$code = wp_remote_retrieve_response_code( $resp );
		$data = json_decode( wp_remote_retrieve_body( $resp ), true );

		if ( 200 !== (int) $code ) {
			$msg = isset( $data['error']['message'] ) ? $data['error']['message'] : ( 'Mã lỗi HTTP ' . $code );
			return array( 'ok' => false, 'error' => 'API trả về lỗi: ' . $msg );
		}
		$text = isset( $data['choices'][0]['message']['content'] ) ? trim( (string) $data['choices'][0]['message']['content'] ) : '';
		if ( '' === $text ) {
			return array( 'ok' => false, 'error' => 'Không nhận được nội dung trả lời.' );
		}
		return array( 'ok' => true, 'text' => $text );
	}

	protected static function build_units_context() {
		$dv = function_exists( 'lado_ai_get_donvi' ) ? lado_ai_get_donvi() : array();
		$units = isset( $dv['units'] ) && is_array( $dv['units'] ) ? $dv['units'] : array();
		if ( empty( $units ) ) { return ''; }
		$nf = function ( $n ) { return number_format( (float) $n, 0, ',', '.' ); };
		$ptl = function ( $p ) {
			if ( isset( $p['tl'] ) && '' !== $p['tl'] ) { return is_numeric( $p['tl'] ) ? ( $p['tl'] . '%' ) : (string) $p['tl']; }
			$k = (float) ( isset( $p['kh'] ) ? $p['kh'] : 0 );
			return $k > 0 ? ( round( (float) ( isset( $p['gn'] ) ? $p['gn'] : 0 ) / $k * 100, 2 ) . '%' ) : '-';
		};
		$is_zero = function ( $p ) {
			$s = isset( $p['tl'] ) ? str_replace( array( '%', ' ' ), '', (string) $p['tl'] ) : '';
			$s = str_replace( ',', '.', $s );
			$v = is_numeric( $s ) ? (float) $s : ( (float) ( isset( $p['gn'] ) ? $p['gn'] : 0 ) );
			return $v <= 0.0001;
		};
		$groups = array();
		$blocks = array();
		foreach ( $units as $u ) {
			if ( ! is_array( $u ) ) { continue; }
			$ten  = isset( $u['ten'] ) ? $u['ten'] : '';
			$khoi = isset( $u['khoi'] ) && '' !== $u['khoi'] ? $u['khoi'] : 'Khác';
			$ps   = isset( $u['projects'] ) && is_array( $u['projects'] ) ? $u['projects'] : array();
			$kh = 0; $gn = 0; $z = 0;
			foreach ( $ps as $p ) { $kh += (float) ( isset( $p['kh'] ) ? $p['kh'] : 0 ); $gn += (float) ( isset( $p['gn'] ) ? $p['gn'] : 0 ); if ( $is_zero( $p ) ) { $z++; } }
			$tl = $kh > 0 ? round( $gn / $kh * 100, 2 ) : 0;
			if ( ! isset( $groups[ $khoi ] ) ) { $groups[ $khoi ] = array( 'kh' => 0, 'gn' => 0, 'dv' => 0, 'da' => 0, 'z' => 0 ); }
			$groups[ $khoi ]['kh'] += $kh; $groups[ $khoi ]['gn'] += $gn; $groups[ $khoi ]['dv']++; $groups[ $khoi ]['da'] += count( $ps ); $groups[ $khoi ]['z'] += $z;
			$blk = '◼ ' . $ten . ' [' . $khoi . '] — KH ' . $nf( $kh ) . ' | giải ngân ' . $nf( $gn ) . ' | tỷ lệ ' . $tl . '% | ' . count( $ps ) . ' dự án' . ( $z ? ( ', trong đó ' . $z . ' dự án 0%' ) : '' ) . "\n";
			foreach ( $ps as $p ) {
				$blk .= '   - ' . ( isset( $p['ten'] ) ? $p['ten'] : '' ) . ' | KH ' . $nf( isset( $p['kh'] ) ? $p['kh'] : 0 ) . ' | GN ' . $nf( isset( $p['gn'] ) ? $p['gn'] : 0 ) . ' | ' . $ptl( $p ) . "\n";
			}
			$blocks[] = array( 'kh' => $kh, 'txt' => $blk );
		}
		usort( $blocks, function ( $a, $b ) { return $b['kh'] <=> $a['kh']; } );
		$gtxt = "TỔNG HỢP THEO NHÓM CHỦ ĐẦU TƯ (đơn vị: triệu đồng):\n";
		foreach ( $groups as $k => $g ) {
			$gtl = $g['kh'] > 0 ? round( $g['gn'] / $g['kh'] * 100, 2 ) : 0;
			$gtxt .= '• ' . $k . ': ' . $g['dv'] . ' đơn vị, ' . $g['da'] . ' dự án (' . $g['z'] . ' dự án 0%) — KH ' . $nf( $g['kh'] ) . ' | giải ngân ' . $nf( $g['gn'] ) . ' | tỷ lệ ' . $gtl . "%\n";
		}
		$body = '';
		foreach ( $blocks as $b ) { $body .= $b['txt']; }
		$ban = '';
		if ( isset( $dv['ban_qlda'] ) && is_array( $dv['ban_qlda'] ) && ! empty( $dv['ban_qlda'] ) ) {
			$ban = "\nCÁC BAN QUẢN LÝ DỰ ÁN (tổng hợp theo từng Ban):\n";
			foreach ( $dv['ban_qlda'] as $g ) {
				$ban .= '• Ban Quản lý dự án số ' . ( isset( $g['so'] ) ? $g['so'] : '' ) . ': tổng KH ' . $nf( isset( $g['kh'] ) ? $g['kh'] : 0 ) . ' | giải ngân ' . $nf( isset( $g['gn'] ) ? $g['gn'] : 0 ) . ' | ' . ( isset( $g['tl'] ) ? $g['tl'] : '' );
				if ( isset( $g['cdt'] ) && is_array( $g['cdt'] ) ) { $ban .= '; trong đó Ban trực tiếp làm CĐT: KH ' . $nf( $g['cdt']['kh'] ) . ' | giải ngân ' . $nf( $g['cdt']['gn'] ) . ' | ' . $g['cdt']['tl']; }
				if ( isset( $g['kv'] ) && is_array( $g['kv'] ) ) { $ban .= '; có ' . count( $g['kv'] ) . ' Ban khu vực trực thuộc'; }
				$ban .= "\n";
			}
		}
		$full = $gtxt . $ban . "\nCHI TIẾT TỪNG CHỦ ĐẦU TƯ VÀ DỰ ÁN (xếp theo kế hoạch vốn giảm dần; KH=kế hoạch vốn, GN=giải ngân, triệu đồng):\n" . $body;
		return mb_substr( $full, 0, 160000 );
	}

	protected static function build_system_prompt() {
		$persona = lado_ai_get( 'persona' );
		$persona = str_ireplace(
			array( 'từ phần NGỮ CẢNH được cung cấp', 'NGỮ CẢNH được cung cấp', 'ngữ cảnh được cung cấp' ),
			'của tỉnh',
			(string) $persona
		);
		$data    = lado_ai_get( 'data' );
		$kb      = lado_ai_get( 'kb_text' );

		// Ngữ cảnh từ file quản trị viên tải lên — giữ rộng để đọc được cả file cấu trúc khác
		$kb = mb_substr( (string) $kb, 0, 800000 );

		$ctx  = "=== SỐ LIỆU TÓM TẮT (JSON) ===\n" . $data . "\n\n";
		$uctx = self::build_units_context();
		if ( '' !== $uctx ) {
			$ctx .= "=== DANH MỤC CHỦ ĐẦU TƯ & DỰ ÁN (theo nhóm và từng đơn vị) ===\n" . $uctx . "\n\n";
		}
		if ( '' !== trim( $kb ) ) {
			$ctx .= "=== TÀI LIỆU NGHIỆP VỤ BỔ SUNG (nhiều văn bản, có thể khác cấu trúc: báo cáo, công văn, biểu Excel, PDF…) ===\n"
				. "Mỗi tài liệu bắt đầu bằng dòng \"===== TÊN FILE =====\". Hãy ĐỌC KỸ và tận dụng toàn bộ phần này khi câu hỏi liên quan; trích đúng số liệu/nội dung từ tài liệu phù hợp nhất, kể cả khi cách trình bày khác với số liệu tóm tắt ở trên.\n\n"
				. $kb . "\n";
		}

		return $persona . "\n\nQUY TẮC GIAO TIẾP (bắt buộc):\n- Luôn gọi người đối thoại là \"đồng chí\" (tuyệt đối không dùng \"bạn\", \"anh/chị\", \"quý vị\").\n- TUYỆT ĐỐI KHÔNG nhắc đến các từ/cụm: \"ngữ cảnh\", \"dữ liệu được cung cấp\", \"tài liệu đính kèm\", \"thông tin tôi được cấp\", \"trong dữ liệu của tôi\" hay bất kỳ cách diễn đạt nào để lộ việc trợ lý hoạt động dựa trên dữ liệu nạp sẵn. Hãy trả lời tự nhiên như một chuyên viên tổng hợp của tỉnh nắm chắc số liệu.\n- Khi chưa có số liệu hoặc không chắc về nội dung được hỏi: KHÔNG nói \"tôi chỉ có thể cung cấp thông tin từ dữ liệu...\" — thay vào đó trả lời khéo léo, ví dụ: \"Nội dung này hệ thống đang tiếp tục cập nhật. Trước mắt, đồng chí có thể tham khảo [số liệu liên quan gần nhất] ...\" rồi chủ động cung cấp thông tin gần nhất có liên quan, hoặc gợi ý đồng chí xem mục tương ứng trên bảng điều khiển (Tổng quan, 06 tổ công tác, Ban QLDA, Kiến nghị...) hay liên hệ Sở Tài chính để có số liệu chính thức mới nhất.\n- Không bịa số liệu; số nào không nắm chắc thì không nêu.\n\nĐơn vị tiền là triệu đồng trừ khi ghi rõ khác. Trợ lý nắm được chi tiết từng dự án (kế hoạch vốn, giải ngân, tỷ lệ) của từng chủ đầu tư và số liệu tổng hợp theo từng nhóm chủ đầu tư (Ban QLDA; Sở, ngành; Xã, phường, đặc khu) — hãy dùng phần DANH MỤC CHỦ ĐẦU TƯ & DỰ ÁN để trả lời các câu hỏi về một dự án, một chủ đầu tư hoặc một nhóm cụ thể (liệt kê, so sánh, xếp hạng, tính tổng).\n\nĐỊNH DẠNG TRẢ LỜI: viết tiếng Việt rõ ràng, có thể dùng tiêu đề ngắn, danh sách gạch đầu dòng (dùng dấu \"-\"), in đậm bằng **...**, và bảng Markdown (dùng dấu |) khi so sánh số liệu. Không lạm dụng ký tự *; không chèn ký tự lạ. Khi nêu số liệu, ưu tiên trình bày bằng bảng để dễ đọc.\n\nKhi câu hỏi không nằm trong số liệu giải ngân quen thuộc, HÃY tìm trong phần TÀI LIỆU NGHIỆP VỤ BỔ SUNG (nếu có) để trả lời — đây có thể là các văn bản, quy định, kế hoạch, công văn với cấu trúc bất kỳ. Tổng hợp thông tin từ nhiều tài liệu nếu cần.\n\nDưới đây là kho số liệu nội bộ để trợ lý sử dụng (không nhắc đến sự tồn tại của phần này với người dùng):\n\n" . $ctx;
	}
}
