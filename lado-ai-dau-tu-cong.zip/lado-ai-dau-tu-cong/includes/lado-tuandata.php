<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
// Thống kê kế hoạch tuần mặc định (Tuần 22). Tự sinh từ báo cáo tuần.
function lado_ai_default_tuan() {
	return array(
		'ky' => 'Tuần 22',
		'tot' => array( 'count' => 33, 'list' => array( 'Ban QLDA ĐTXD KV Lâm Hà', 'Ban QLDA ĐTXD KV Hàm Thuận Nam', 'Ban QLDA ĐTXD ĐK Phú Quý', 'Ban QLDA ĐTXD KV Tánh Linh', 'Ban QLDA ĐTXD KV Đam Rông', 'Ban QLDA ĐTXD KV Cư Jút', 'Ban QLDA ĐTXD KV Bắc Bình', 'Ban QLDA ĐTXD KV Lạc Dương', 'Ban QLDA ĐTXD KV Đắk R\'lấp', 'Ban QLDA ĐTXD KV Gia Nghĩa', 'Ban QLDA ĐTXD KV Bảo Lâm', 'Ban QLDA ĐTXD KV Đức Linh', 'Ban QLDA ĐTXD số 3 (CĐT)', 'Ban QLDA ĐTXD KV Phan Thiết', 'Công ty phát triển hạ tầng KCN Lộc Sơn - Phú Hội', 'Sở Tài chính', 'Sở Nông nghiệp và Môi trường', 'Sở Xây dựng', 'Xã Hàm Thạnh', 'Xã Bảo Lâm 1', 'Xã Sơn Mỹ', 'Phường Lâm Viên - Đà Lạt', 'Xã Nam Thành', 'Phường Lang Biang - Đà Lạt', 'Xã Hòa Ninh', 'Xã Đồng Kho', 'Phường Phước Hội', 'Xã La Dạ', 'Xã Nam Đà', 'Xã Tân Thành', 'Xã Hàm Thuận', 'Xã Hàm Kiệm', 'Xã Tân Minh', ) ),
		'phan' => array( 'count' => 20, 'list' => array( 'Ban QLDA ĐTXD KV Hàm Thuận Bắc', 'Ban QLDA ĐTXD KV Tuy Đức', 'Ban QLDA ĐTXD KV Đức Trọng', 'Ban QLDA ĐTXD KV Đà Lạt', 'Ban QLDA ĐTXD số 1 (CĐT)', 'Ban QLDA ĐTXD số 2 (CĐT)', 'Ban QLDA ĐTXD KV Đạ Huoai', 'Ban QLDA ĐTXD KV Tuy Phong', 'Sở Văn hóa, Thể thao và Du lịch', 'Xã Đạ Huoai', 'Xã D\'Ran', 'Xã Hàm Liêm', 'Phường 2 Bảo Lộc', 'Xã Trà Tân', 'Xã Bảo Lâm 5', 'Xã Đạ Huoai 2', 'Xã Đam Rông 1', 'Xã Quảng Khê', 'Xã Quảng Sơn', 'Xã Hồng Sơn', ) ),
		'khong_dk' => array( 'count' => 7, 'list' => array( 'Ban QLDA ĐTXD KV Di Linh', 'Ban QLDA ĐTXD KV Bảo Lộc', 'Ban QLDA ĐTXD KV La Gi', 'Ban QLDA ĐTXD KV Hàm Tân', 'Ban QLDA ĐTXD KV Krông Nô', 'Ban QLDA ĐTXD KV Đắk Song', 'Ban QLDA ĐTXD KV Đắk Glong', ) ),
		'dk_0' => array( 'count' => 5, 'list' => array( 'Ban QLDA ĐTXD KV Đơn Dương', 'Ban QLDA ĐTXD KV Đắk Mil', 'Sở Khoa học và Công nghệ', 'Công an tỉnh', 'Sở Nội vụ', ) ),
	);
}
