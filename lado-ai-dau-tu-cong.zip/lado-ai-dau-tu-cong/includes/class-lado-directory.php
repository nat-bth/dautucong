<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Đọc danh mục dự án theo từng chủ đầu tư (từ Excel danh mục tuần) và
 * danh bạ liên hệ (từ file Word) — phục vụ popup chi tiết khi bấm vào đơn vị.
 */
class LaDo_AI_Directory {

	/* Chuẩn hóa tên đơn vị để khớp giữa các nguồn (bỏ dấu, thường hóa) */
	public static function nrm( $s ) {
		$s = mb_strtolower( trim( (string) $s ), 'UTF-8' );
		$map = array(
			'à'=>'a','á'=>'a','ạ'=>'a','ả'=>'a','ã'=>'a','â'=>'a','ầ'=>'a','ấ'=>'a','ậ'=>'a','ẩ'=>'a','ẫ'=>'a','ă'=>'a','ằ'=>'a','ắ'=>'a','ặ'=>'a','ẳ'=>'a','ẵ'=>'a',
			'è'=>'e','é'=>'e','ẹ'=>'e','ẻ'=>'e','ẽ'=>'e','ê'=>'e','ề'=>'e','ế'=>'e','ệ'=>'e','ể'=>'e','ễ'=>'e',
			'ì'=>'i','í'=>'i','ị'=>'i','ỉ'=>'i','ĩ'=>'i',
			'ò'=>'o','ó'=>'o','ọ'=>'o','ỏ'=>'o','õ'=>'o','ô'=>'o','ồ'=>'o','ố'=>'o','ộ'=>'o','ổ'=>'o','ỗ'=>'o','ơ'=>'o','ờ'=>'o','ớ'=>'o','ợ'=>'o','ở'=>'o','ỡ'=>'o',
			'ù'=>'u','ú'=>'u','ụ'=>'u','ủ'=>'u','ũ'=>'u','ư'=>'u','ừ'=>'u','ứ'=>'u','ự'=>'u','ử'=>'u','ữ'=>'u',
			'ỳ'=>'y','ý'=>'y','ỵ'=>'y','ỷ'=>'y','ỹ'=>'y','đ'=>'d',
		);
		$s = strtr( $s, $map );
		$s = preg_replace( '/lam cdt$/', '', $s );
		$s = preg_replace( '/[^a-z0-9 ]/', ' ', $s );
		$s = preg_replace( '/\s+/', ' ', $s );
		return trim( $s );
	}

	protected static function pnum( $s ) {
		$s = preg_replace( '/[^0-9]/', '', (string) $s );
		return '' === $s ? 0 : (int) $s;
	}
	protected static function pround( $s ) {
		$s = str_replace( ',', '.', (string) $s );
		return is_numeric( $s ) ? (int) round( (float) $s ) : 0;
	}
	protected static function is_unit_stt( $s ) {
		$s = trim( (string) $s );
		if ( ! preg_match( '/^\d+(\.0+)?$/', $s ) ) { return false; }
		$n = (float) $s;
		return $n > 0 && $n < 600;
	}

	/* ---------------- Dự án theo chủ đầu tư (Excel) ---------------- */
	public static function parse_units( $path ) {
		if ( ! class_exists( 'ZipArchive' ) ) { return null; }
		$zip = new ZipArchive();
		if ( true !== $zip->open( $path ) ) { return null; }

		$shared = LaDo_AI_Excel_shared( $zip );
		$map    = LaDo_AI_Excel_sheetmap( $zip );
		$units  = array();

		foreach ( $map as $name => $file ) {
			$khoi = '';
			if ( false !== mb_stripos( $name, 'Ban QLDA' ) ) { $khoi = 'Ban QLDA'; }
			elseif ( false !== mb_stripos( $name, 'Sở' ) ) { $khoi = 'Sở, ngành'; }
			elseif ( false !== mb_stripos( $name, 'Xã' ) ) { $khoi = 'Xã, phường, đặc khu'; }
			else { continue; }

			$rows = LaDo_AI_Excel_rows( $zip, $file, $shared );
			if ( empty( $rows ) ) { continue; }
			ksort( $rows );

			// Tự dò cột "Kế hoạch vốn" tổng (ô tiêu đề "Tổng cộng" trong vùng cột 30–60); dự phòng 34 rồi 32.
			$khcol = 0;
			foreach ( $rows as $hr => $hd ) {
				if ( $hr > 9 ) { break; }
				foreach ( $hd as $cc => $cv ) {
					if ( $cc >= 30 && $cc <= 60 && 'tổng cộng' === mb_strtolower( trim( (string) $cv ) ) ) { $khcol = $cc; break 2; }
				}
			}
			if ( ! $khcol ) { $khcol = 34; }

			$cur = null;
			foreach ( $rows as $rn => $rd ) {
				if ( $rn < 9 ) { continue; }
				$c2 = isset( $rd[2] ) ? trim( $rd[2] ) : '';
				if ( '' === $c2 ) { continue; }
				if ( self::is_unit_stt( isset( $rd[1] ) ? $rd[1] : '' ) ) {
					$ten = preg_replace( '/\s*làm CĐT$/u', '', $c2 );
					$cur = self::nrm( $ten );
					$units[ $cur ] = array( 'ten' => $ten, 'khoi' => $khoi, 'projects' => array() );
					continue;
				}
				if ( null === $cur ) { continue; }
				if ( preg_match( '/^(CỘNG|TỔNG)/u', $c2 ) ) { continue; }
				$kh = isset( $rd[ $khcol ] ) ? self::pround( $rd[ $khcol ] ) : 0;
				if ( ! $kh && isset( $rd[34] ) ) { $kh = self::pround( $rd[34] ); }
				if ( ! $kh && isset( $rd[32] ) ) { $kh = self::pround( $rd[32] ); }
				// giải ngân/tỷ lệ = ô khớp "số/số%" ở vị trí PHẢI NHẤT (lũy kế thực hiện tuần mới nhất)
				$gn = 0; $tl = '';
				$cols = array_keys( $rd );
				rsort( $cols );
				foreach ( $cols as $cc ) {
					if ( $cc <= 40 ) { break; }
					$v = (string) $rd[ $cc ];
					if ( preg_match( '/^\s*([\d\.]+)\s*\/\s*([\d,]+)\s*%\s*$/u', $v, $mm ) ) {
						$gn = self::pnum( $mm[1] );
						$tl = $mm[2] . '%';
						break;
					}
				}
				if ( $kh > 0 || $gn > 0 ) {
					$units[ $cur ]['projects'][] = array( 'ten' => $c2, 'kh' => $kh, 'gn' => $gn, 'tl' => $tl );
				}
			}
		}
		$zip->close();
		return $units;
	}

	/* ---------- Tổng hợp theo từng Ban QLDA (sheet "Tổng hợp") ---------- */
	public static function parse_ban_qlda( $path ) {
		if ( ! class_exists( 'ZipArchive' ) ) { return array(); }
		$zip = new ZipArchive();
		if ( true !== $zip->open( $path ) ) { return array(); }
		$shared = LaDo_AI_Excel_shared( $zip );
		$map    = LaDo_AI_Excel_sheetmap( $zip );
		$file   = '';
		foreach ( $map as $name => $f ) {
			if ( false !== mb_stripos( $name, 'Tổng hợp' ) || false !== mb_stripos( $name, 'Tong hop' ) ) { $file = $f; break; }
		}
		if ( '' === $file ) { $zip->close(); return array(); }
		$rows = LaDo_AI_Excel_rows( $zip, $file, $shared );
		$zip->close();
		if ( empty( $rows ) ) { return array(); }
		ksort( $rows );

		$groups = array(); $gi = -1;
		foreach ( $rows as $rd ) {
			$name = isset( $rd[2] ) ? trim( $rd[2] ) : '';
			if ( '' === $name ) { continue; }
			$kh = isset( $rd[3] ) ? self::pround( $rd[3] ) : 0;
			$gn = 0; $tl = '';
			if ( isset( $rd[6] ) && preg_match( '/([\d\.]+)\s*\/\s*([\d,]+)\s*%/u', (string) $rd[6], $m ) ) {
				$gn = self::pnum( $m[1] ); $tl = $m[2] . '%';
			}
			if ( preg_match( '/^Ban QLDA ĐTXD số (\d+)$/u', $name, $mm ) ) {
				$groups[] = array( 'so' => (int) $mm[1], 'ten' => $name, 'kh' => $kh, 'gn' => $gn, 'tl' => $tl, 'cdt' => null, 'kv' => array() );
				$gi = count( $groups ) - 1;
			} elseif ( $gi >= 0 && preg_match( '/làm CĐT$/u', $name ) ) {
				$groups[ $gi ]['cdt'] = array( 'ten' => $name, 'kh' => $kh, 'gn' => $gn, 'tl' => $tl );
			} elseif ( $gi >= 0 && 0 === mb_stripos( $name, 'Ban QLDA ĐTXD' ) ) {
				$groups[ $gi ]['kv'][] = array( 'ten' => $name, 'kh' => $kh, 'gn' => $gn, 'tl' => $tl );
			}
		}
		return $groups;
	}

	/* ---- Trạng thái đăng ký/thực hiện KH tuần theo đơn vị (từ Excel tuần) ---- */
	public static function parse_weekly_status( $path ) {
		if ( ! class_exists( 'ZipArchive' ) ) { return array(); }
		$zip = new ZipArchive();
		if ( true !== $zip->open( $path ) ) { return array(); }
		$shared = LaDo_AI_Excel_shared( $zip );
		$map    = LaDo_AI_Excel_sheetmap( $zip );
		$cats   = array( 'tot' => array(), 'phan' => array(), 'dk_0' => array(), 'khong_dk' => array() );
		$ky     = '';
		foreach ( $map as $name => $file ) {
			if ( false === mb_stripos( $name, 'Ban QLDA' ) && false === mb_stripos( $name, 'Sở' ) && false === mb_stripos( $name, 'Xã' ) ) { continue; }
			$rows = LaDo_AI_Excel_rows( $zip, $file, $shared );
			if ( empty( $rows ) ) { continue; }
			ksort( $rows );
			$thcols = array(); $wlabels = array();
			foreach ( $rows as $hr => $hd ) {
				if ( $hr > 9 ) { break; }
				foreach ( $hd as $cc => $cv ) {
					if ( 'thực hiện tuần' === mb_strtolower( trim( (string) $cv ) ) ) { $thcols[] = $cc; }
					if ( preg_match( '/Tuần\s*(\d+)/u', (string) $cv, $mw ) ) { $wlabels[ $cc ] = 'Tuần ' . $mw[1]; }
				}
			}
			if ( empty( $thcols ) ) { continue; }
			sort( $thcols );
			$counts = array(); $mx = 1;
			foreach ( $thcols as $cc ) {
				$n = 0;
				foreach ( $rows as $rn => $rd ) { if ( $rn < 10 ) { continue; } if ( isset( $rd[ $cc ] ) && self::pnum( $rd[ $cc ] ) > 0 ) { $n++; } }
				$counts[ $cc ] = $n; if ( $n > $mx ) { $mx = $n; }
			}
			$thc = 0;
			foreach ( array_reverse( $thcols ) as $cc ) {
				if ( $counts[ $cc ] >= 0.3 * $mx && $counts[ $cc ] >= 5 ) { $thc = $cc; break; }
			}
			if ( ! $thc ) { $thc = end( $thcols ); }
			$khc = $thc - 2;
			if ( '' === $ky ) { $best = 0; foreach ( $wlabels as $cc => $lb ) { if ( $cc <= $thc + 1 && $cc > $best ) { $best = $cc; } } if ( $best ) { $ky = $wlabels[ $best ]; } }
			$cur = null; $agg = array();
			foreach ( $rows as $rn => $rd ) {
				if ( $rn < 9 ) { continue; }
				$c2 = isset( $rd[2] ) ? trim( $rd[2] ) : '';
				if ( '' === $c2 ) { continue; }
				if ( self::is_unit_stt( isset( $rd[1] ) ? $rd[1] : '' ) ) {
					$ten = preg_replace( '/\s*làm CĐT$/u', '', $c2 );
					$cur = $ten; $agg[ $cur ] = array( 'ten' => $ten, 'kh' => 0, 'th' => 0, 'ann' => 0 );
					continue;
				}
				if ( null === $cur || preg_match( '/^(CỘNG|TỔNG)/u', $c2 ) ) { continue; }
				$agg[ $cur ]['kh']  += self::pnum( isset( $rd[ $khc ] ) ? $rd[ $khc ] : 0 );
				$agg[ $cur ]['th']  += self::pnum( isset( $rd[ $thc ] ) ? $rd[ $thc ] : 0 );
				$agg[ $cur ]['ann'] += self::pnum( isset( $rd[34] ) ? $rd[34] : 0 );
			}
			foreach ( $agg as $a ) {
				if ( $a['kh'] > 0 ) {
					if ( $a['th'] >= $a['kh'] ) { $cats['tot'][] = $a['ten']; }
					elseif ( $a['th'] > 0 ) { $cats['phan'][] = $a['ten']; }
					else { $cats['dk_0'][] = $a['ten']; }
				} elseif ( $a['ann'] > 0 ) {
					$cats['khong_dk'][] = $a['ten'];
				}
			}
		}
		$zip->close();
		return array(
			'ky'       => $ky,
			'tot'      => array( 'count' => count( $cats['tot'] ), 'list' => $cats['tot'] ),
			'phan'     => array( 'count' => count( $cats['phan'] ), 'list' => $cats['phan'] ),
			'dk_0'     => array( 'count' => count( $cats['dk_0'] ), 'list' => $cats['dk_0'] ),
			'khong_dk' => array( 'count' => count( $cats['khong_dk'] ), 'list' => $cats['khong_dk'] ),
		);
	}

	/* ---- Quỹ đạo "kế hoạch đăng ký" lũy kế theo tuần (cộng dồn KH tuần từ file danh mục) ---- */
	public static function parse_dk_trajectory( $path ) {
		if ( ! class_exists( 'ZipArchive' ) ) { return array(); }
		$zip = new ZipArchive();
		if ( true !== $zip->open( $path ) ) { return array(); }
		$shared = LaDo_AI_Excel_shared( $zip );
		$map    = LaDo_AI_Excel_sheetmap( $zip );
		$gnum = function ( $v ) { $s = (string) ( null === $v ? '' : $v ); $s = explode( '/', $s ); $s = preg_replace( '/[^0-9]/', '', $s[0] ); return '' === $s ? 0 : (int) $s; };
		$sum    = array();   // wk => Lũy kế kế hoạch (số trước '/')
		$dates  = array();   // wk => 'dd/mm/yyyy'
		$order  = array();
		foreach ( $map as $name => $file ) {
			if ( false === mb_stripos( $name, 'Ban QLDA' ) && false === mb_stripos( $name, 'Sở' ) && false === mb_stripos( $name, 'Xã' ) ) { continue; }
			$rows = LaDo_AI_Excel_rows( $zip, $file, $shared );
			if ( empty( $rows ) ) { continue; }
			ksort( $rows );
			$wcols = array(); $seen = array();
			foreach ( $rows as $rn => $rd ) {
				if ( $rn > 6 ) { break; }
				foreach ( $rd as $cc => $cv ) {
					if ( preg_match( '/Tuần\s*(\d+).*?đến\s*([0-9]{1,2})\/([0-9]{1,2})/us', (string) $cv, $mw ) ) {
						$wk = (int) $mw[1];
						if ( isset( $seen[ $wk ] ) ) { continue; }
						$seen[ $wk ] = 1; $wcols[ $cc ] = $wk;
						if ( ! isset( $dates[ $wk ] ) ) { $dates[ $wk ] = sprintf( '%02d/%02d/2026', (int) $mw[2], (int) $mw[3] ); }
					}
				}
			}
			if ( empty( $wcols ) ) { continue; }
			foreach ( $rows as $rn => $rd ) {
				if ( $rn < 9 ) { continue; }
				if ( ! self::is_unit_stt( isset( $rd[1] ) ? $rd[1] : '' ) ) { continue; }
				foreach ( $wcols as $cc => $wk ) {
					if ( ! isset( $sum[ $wk ] ) ) { $sum[ $wk ] = 0; $order[] = $wk; }
					$sum[ $wk ] += $gnum( isset( $rd[ $cc + 1 ] ) ? $rd[ $cc + 1 ] : 0 ); // Lũy kế kế hoạch
				}
			}
		}
		$zip->close();
		if ( empty( $sum ) ) { return array(); }
		ksort( $sum );
		$out = array();
		foreach ( $sum as $wk => $amt ) {
			$out[] = array( 'wk' => $wk, 'date' => isset( $dates[ $wk ] ) ? $dates[ $wk ] : '', 'amt' => $amt );
		}
		return $out;
	}

	/* ---------------- Danh bạ liên hệ (Word) ---------------- */
	public static function parse_contacts( $path ) {
		$tables = LaDo_AI_Data::docx_tables( $path );
		if ( empty( $tables ) ) { return null; }
		$contacts = array();
		foreach ( $tables as $tb ) {
			if ( empty( $tb ) ) { continue; }
			$head  = mb_strtolower( implode( ' | ', $tb[0] ), 'UTF-8' );
			$is_xa = ( false !== mb_strpos_safe( $head, 'bí thư' ) ) || ( false !== mb_strpos_safe( $head, 'chủ tịch' ) );
			foreach ( array_slice( $tb, 1 ) as $r ) {
				if ( count( $r ) < 3 || '' === trim( $r[1] ) ) { continue; }
				$ten = trim( $r[1] );
				$key = self::nrm( $ten );
				if ( '' === $key ) { continue; }
				if ( $is_xa ) {
					$contacts[ $key ] = array(
						'ten'           => $ten,
						'bithu'         => isset( $r[2] ) ? trim( $r[2] ) : '',
						'bithu_phone'   => isset( $r[3] ) ? trim( $r[3] ) : '',
						'chutich'       => isset( $r[4] ) ? trim( $r[4] ) : '',
						'chutich_phone' => isset( $r[5] ) ? trim( $r[5] ) : '',
					);
				} else {
					$contacts[ $key ] = array(
						'ten'        => $ten,
						'head'       => isset( $r[2] ) ? trim( str_replace( array( "\n", "\r" ), ' — ', $r[2] ) ) : '',
						'head_phone' => isset( $r[3] ) ? trim( $r[3] ) : '',
					);
				}
			}
		}
		return $contacts;
	}
}

/* Tiện ích đọc xlsx dùng chung (chia sẻ với LaDo_AI_Excel) */
function LaDo_AI_Excel_shared( $zip ) {
	$out = array();
	$xml = $zip->getFromName( 'xl/sharedStrings.xml' );
	if ( ! $xml ) { return $out; }
	// Bắt cả <si/> rỗng tự đóng để KHÔNG làm lệch chỉ số chuỗi
	if ( preg_match_all( '#<si\b[^>]*?(?:/>|>(.*?)</si>)#s', $xml, $m, PREG_SET_ORDER ) ) {
		foreach ( $m as $si ) {
			$inner = isset( $si[1] ) ? $si[1] : '';
			$txt   = '';
			if ( '' !== $inner && preg_match_all( '#<t[^>]*>(.*?)</t>#s', $inner, $t ) ) { $txt = implode( '', $t[1] ); }
			$out[] = html_entity_decode( wp_strip_all_tags( $txt ), ENT_QUOTES | ENT_HTML5, 'UTF-8' );
		}
	}
	return $out;
}
function LaDo_AI_Excel_sheetmap( $zip ) {
	$map = array();
	$wb  = $zip->getFromName( 'xl/workbook.xml' );
	$rel = $zip->getFromName( 'xl/_rels/workbook.xml.rels' );
	if ( ! $wb || ! $rel ) { return $map; }
	$rid = array();
	if ( preg_match_all( '#Id="([^"]+)"[^>]*Target="([^"]+)"#', $rel, $mr, PREG_SET_ORDER ) ) {
		foreach ( $mr as $r ) {
			$t = $r[2];
			if ( $t && '/' !== $t[0] ) { $t = 'xl/' . $t; }
			$rid[ $r[1] ] = $t;
		}
	}
	if ( preg_match_all( '#<sheet[^>]*name="([^"]+)"[^>]*r:id="([^"]+)"#', $wb, $ms, PREG_SET_ORDER ) ) {
		foreach ( $ms as $s ) {
			$name = html_entity_decode( $s[1], ENT_QUOTES | ENT_HTML5, 'UTF-8' );
			if ( isset( $rid[ $s[2] ] ) ) { $map[ $name ] = $rid[ $s[2] ]; }
		}
	}
	return $map;
}
function LaDo_AI_Excel_rows( $zip, $file, $shared ) {
	$rows = array();
	$xml  = $zip->getFromName( $file );
	if ( ! $xml ) { return $rows; }
	// Bắt cả <row .../> tự đóng lẫn <row ...>...</row>
	if ( ! preg_match_all( '#<row\b[^>]*?\br="(\d+)"[^>]*?(?:/>|>(.*?)</row>)#s', $xml, $mr, PREG_SET_ORDER ) ) { return $rows; }
	foreach ( $mr as $rm ) {
		$rn    = (int) $rm[1];
		$body  = isset( $rm[2] ) ? $rm[2] : '';
		$cells = array();
		// Bắt cả ô rỗng tự đóng <c .../> lẫn <c ...>...</c> (tránh "nuốt" các ô liền sau)
		if ( '' !== $body && preg_match_all( '#<c\b([^>]*?)\br="([A-Z]+)\d+"([^>]*?)(?:/>|>(.*?)</c>)#s', $body, $mc, PREG_SET_ORDER ) ) {
			foreach ( $mc as $cm ) {
				$col = $cm[2]; $ci = 0; $len = strlen( $col );
				for ( $i = 0; $i < $len; $i++ ) { $ci = $ci * 26 + ( ord( $col[ $i ] ) - 64 ); }
				$attr  = $cm[1] . $cm[3];
				$cbody = isset( $cm[4] ) ? $cm[4] : '';
				$val   = '';
				if ( preg_match( '#<v>(.*?)</v>#s', $cbody, $v ) ) {
					$val = $v[1];
					if ( false !== strpos( $attr, 't="s"' ) && ctype_digit( $val ) ) {
						$idx = (int) $val; $val = isset( $shared[ $idx ] ) ? $shared[ $idx ] : '';
					}
				} elseif ( preg_match( '#<t[^>]*>(.*?)</t>#s', $cbody, $t ) ) {
					$val = html_entity_decode( wp_strip_all_tags( $t[1] ), ENT_QUOTES | ENT_HTML5, 'UTF-8' );
				}
				$cells[ $ci ] = trim( (string) $val );
			}
		}
		$rows[ $rn ] = $cells;
	}
	return $rows;
}
function mb_strpos_safe( $h, $n ) { return mb_strpos( $h, $n ); }
