<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Trích xuất văn bản & bảng từ .docx / .xlsx, và chuyển báo cáo Word -> số liệu biểu đồ.
 */
class LaDo_AI_Data {

	public static function extract( $path ) {
		$ext = strtolower( pathinfo( $path, PATHINFO_EXTENSION ) );
		if ( 'docx' === $ext ) { return self::docx( $path ); }
		if ( 'pdf' === $ext ) { return self::clean( self::pdf_text( $path ) ); }
		if ( 'xlsx' === $ext ) { return self::xlsx( $path ); }
		if ( 'csv' === $ext || 'txt' === $ext ) {
			$c = file_get_contents( $path );
			if ( ! $c ) { return ''; }
			// Tự nhận diện mã hóa (UTF-8 / UTF-16 / Windows-1258…) để không lỗi dấu tiếng Việt
			if ( function_exists( 'mb_detect_encoding' ) ) {
				$enc = mb_detect_encoding( $c, array( 'UTF-8', 'UTF-16', 'UTF-16LE', 'UTF-16BE', 'Windows-1258', 'Windows-1252', 'ISO-8859-1' ), true );
				if ( $enc && 'UTF-8' !== $enc ) { $c = mb_convert_encoding( $c, 'UTF-8', $enc ); }
			}
			$c = preg_replace( '/^\xEF\xBB\xBF/', '', $c ); // bỏ BOM
			return self::clean( $c );
		}
		return '';
	}

	protected static function docx( $path ) {
		if ( ! class_exists( 'ZipArchive' ) ) { return ''; }
		$zip = new ZipArchive();
		if ( true !== $zip->open( $path ) ) { return ''; }
		$out = '';
		$targets = array( 'word/document.xml' );
		for ( $i = 0; $i < $zip->numFiles; $i++ ) {
			$n = $zip->getNameIndex( $i );
			if ( preg_match( '#^word/(header|footer)\d+\.xml$#', $n ) ) { $targets[] = $n; }
		}
		foreach ( $targets as $t ) {
			$xml = $zip->getFromName( $t );
			if ( ! $xml ) { continue; }
			$xml = preg_replace( '#</w:p>#', "\n", $xml );
			$xml = preg_replace( '#<w:tab[^>]*/>#', "\t", $xml );
			$xml = preg_replace( '#<w:br[^>]*/>#', "\n", $xml );
			$txt = wp_strip_all_tags( $xml );
			$out .= html_entity_decode( $txt, ENT_QUOTES | ENT_HTML5, 'UTF-8' ) . "\n";
		}
		$zip->close();
		return self::clean( $out );
	}

	protected static function xlsx( $path ) {
		if ( ! class_exists( 'ZipArchive' ) ) { return ''; }
		$zip = new ZipArchive();
		if ( true !== $zip->open( $path ) ) { return ''; }
		$shared = array();
		$ss = $zip->getFromName( 'xl/sharedStrings.xml' );
		if ( $ss && preg_match_all( '#<si>(.*?)</si>#s', $ss, $m ) ) {
			foreach ( $m[1] as $si ) {
				$txt = wp_strip_all_tags( $si );
				$shared[] = html_entity_decode( $txt, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
			}
		}
		$out = '';
		for ( $i = 0; $i < $zip->numFiles; $i++ ) {
			$n = $zip->getNameIndex( $i );
			if ( ! preg_match( '#^xl/worksheets/sheet\d+\.xml$#', $n ) ) { continue; }
			$sheet = $zip->getFromName( $n );
			if ( ! $sheet ) { continue; }
			if ( preg_match_all( '#<c[^>]*?(t="([^"]*)")?[^>]*>(.*?)</c>#s', $sheet, $cells, PREG_SET_ORDER ) ) {
				$rowbuf = array();
				foreach ( $cells as $c ) {
					$type = isset( $c[2] ) ? $c[2] : '';
					if ( preg_match( '#<v>(.*?)</v>#s', $c[3], $v ) ) {
						$val = $v[1];
						if ( 's' === $type ) {
							$idx = (int) $val;
							$val = isset( $shared[ $idx ] ) ? $shared[ $idx ] : '';
						} elseif ( preg_match( '#<t[^>]*>(.*?)</t>#s', $c[3], $t ) ) {
							$val = html_entity_decode( wp_strip_all_tags( $t[1] ), ENT_QUOTES | ENT_HTML5, 'UTF-8' );
						}
						if ( '' !== trim( (string) $val ) ) { $rowbuf[] = trim( (string) $val ); }
					}
				}
				if ( $rowbuf ) { $out .= implode( ' | ', $rowbuf ) . "\n"; }
			}
		}
		$zip->close();
		return self::clean( $out );
	}

	protected static function clean( $s ) {
		$s = preg_replace( "/[ \t]+/u", ' ', $s );
		$s = preg_replace( "/\n{2,}/u", "\n", $s );
		return trim( $s );
	}

	/* ---------------- Đọc bảng từ .docx ---------------- */
	public static function docx_tables( $path ) {
		return self::docx_tables_safe( $path );
	}

	protected static function pnum( $s ) {
		$s = preg_replace( '/[^0-9]/', '', (string) $s );
		return '' === $s ? null : (int) $s;
	}
	protected static function ppct( $s ) {
		if ( false === strpos( (string) $s, '%' ) ) { return null; }
		$s = str_replace( array( '.', ' ', '%' ), array( '', '', '' ), (string) $s );
		$s = str_replace( ',', '.', $s );
		$s = preg_replace( '/[^0-9.\-]/', '', $s );
		return '' === $s ? null : (float) $s;
	}
	protected static function has( $cell, $needle ) { return false !== mb_stripos( $cell, $needle ); }
	protected static function pct_idx( $row ) {
		foreach ( $row as $i => $c ) { if ( false !== strpos( $c, '%' ) ) { return $i; } }
		return -1;
	}

	/* ---- Phụ lục: kết quả giải ngân TỪNG DỰ ÁN theo chủ đầu tư (Kho bạc) ---- */
	public static function parse_phuluc( $path ) {
		$text   = self::docx( $path );
		$tables = self::docx_tables( $path );
		$out    = array( 'units' => array() );
		if ( preg_match( '#chốt đến ngày\s*([0-9]{1,2}/[0-9]{1,2}/[0-9]{4})#u', $text, $md ) ) { $out['as_of'] = $md[1]; }
		elseif ( preg_match( '#đến ngày\s*([0-9]{1,2}/[0-9]{1,2}/[0-9]{4})#u', $text, $md ) ) { $out['as_of'] = $md[1]; }
		$cdts = array(); $khoi = '';
		foreach ( preg_split( '/\n+/', $text ) as $line ) {
			$line = trim( $line );
			if ( '' === $line ) { continue; }
			if ( preg_match( '#^[IVX]+\.\s*KHỐI\s+(.+)$#iu', $line, $mk ) ) {
				$k = $mk[1];
				if ( false !== mb_stripos( $k, 'BAN' ) ) { $khoi = 'Ban QLDA'; }
				elseif ( false !== mb_stripos( $k, 'SỞ' ) ) { $khoi = 'Sở, ngành'; }
				else { $khoi = 'Xã, phường, đặc khu'; }
				continue;
			}
			if ( preg_match( '#^(\d+)\.\s+(.+?)\s+—\s+Kế hoạch\s+([\d.]+).*?giải ngân\s+([\d.]+)(?:,\s*đạt\s*([\d.,]+)\s*%)?#u', $line, $m ) ) {
				$cdts[] = array(
					'ten'  => trim( $m[2] ),
					'khoi' => $khoi,
					'kh'   => self::pnum( $m[3] ),
					'gn'   => self::pnum( $m[4] ),
					'tl'   => isset( $m[5] ) ? (float) str_replace( ',', '.', str_replace( '.', '', $m[5] ) ) : 0,
				);
			}
		}
		$tabs = array();
		foreach ( $tables as $tb ) {
			if ( count( $tb[0] ) >= 8 && isset( $tb[0][2] ) && false !== mb_stripos( $tb[0][2], 'Mã' ) ) { $tabs[] = $tb; }
		}
		$n = min( count( $cdts ), count( $tabs ) );
		for ( $i = 0; $i < $n; $i++ ) {
			$ps = array();
			foreach ( $tabs[ $i ] as $ri => $r ) {
				if ( 0 === $ri ) { continue; }
				$name = isset( $r[1] ) ? trim( $r[1] ) : '';
				if ( '' === $name || preg_match( '#^(CỘNG|TỔNG)#ui', $name ) ) { continue; }
				$ps[] = array(
					'ten'  => $name,
					'ma'   => isset( $r[2] ) ? trim( $r[2] ) : '',
					'kh25' => self::pnum( isset( $r[3] ) ? $r[3] : 0 ),
					'kh26' => self::pnum( isset( $r[4] ) ? $r[4] : 0 ),
					'kh'   => self::pnum( isset( $r[5] ) ? $r[5] : 0 ),
					'gn'   => self::pnum( isset( $r[6] ) ? $r[6] : 0 ),
					'tl'   => isset( $r[7] ) ? trim( $r[7] ) : '',
				);
			}
			$u = $cdts[ $i ];
			$u['projects'] = $ps;
			$out['units'][] = $u;
		}
		return $out;
	}

	/* Tách bảng bằng quét chuỗi (an toàn với bảng rất lớn — không dùng regex lớn) */
	protected static function docx_tables_safe( $path ) {
		if ( ! class_exists( 'ZipArchive' ) ) { return array(); }
		$zip = new ZipArchive();
		if ( true !== $zip->open( $path ) ) { return array(); }
		$xml = $zip->getFromName( 'word/document.xml' );
		$zip->close();
		if ( ! $xml ) { return array(); }
		$tables = array(); $pos = 0; $len = strlen( $xml );
		while ( true ) {
			$a = strpos( $xml, '<w:tbl', $pos );
			if ( false === $a ) { break; }
			$ch = ( $a + 6 < $len ) ? $xml[ $a + 6 ] : '';
			if ( '>' !== $ch && ' ' !== $ch ) { $pos = $a + 6; continue; }
			$b = strpos( $xml, '</w:tbl>', $a );
			if ( false === $b ) { break; }
			$seg = substr( $xml, $a, $b - $a );
			$pos = $b + 8;
			$rows = array(); $rp = 0; $slen = strlen( $seg );
			while ( true ) {
				$ra = strpos( $seg, '<w:tr', $rp );
				if ( false === $ra ) { break; }
				$ch = ( $ra + 5 < $slen ) ? $seg[ $ra + 5 ] : '';
				if ( '>' !== $ch && ' ' !== $ch ) { $rp = $ra + 5; continue; }
				$rb = strpos( $seg, '</w:tr>', $ra );
				if ( false === $rb ) { break; }
				$rseg = substr( $seg, $ra, $rb - $ra );
				$rp = $rb + 7;
				$cells = array(); $cp = 0; $rlen = strlen( $rseg );
				while ( true ) {
					$ca = strpos( $rseg, '<w:tc', $cp );
					if ( false === $ca ) { break; }
					$ch = ( $ca + 5 < $rlen ) ? $rseg[ $ca + 5 ] : '';
					if ( '>' !== $ch && ' ' !== $ch ) { $cp = $ca + 5; continue; }
					$cb = strpos( $rseg, '</w:tc>', $ca );
					if ( false === $cb ) { break; }
					$cseg = substr( $rseg, $ca, $cb - $ca );
					$cp = $cb + 7;
					$txt = ''; $tp = 0; $clen = strlen( $cseg );
					while ( true ) {
						$ta = strpos( $cseg, '<w:t', $tp );
						if ( false === $ta ) { break; }
						$ch = ( $ta + 4 < $clen ) ? $cseg[ $ta + 4 ] : '';
						if ( '>' !== $ch && ' ' !== $ch && '/' !== $ch ) { $tp = $ta + 4; continue; }
						$te = strpos( $cseg, '>', $ta );
						if ( false === $te ) { break; }
						if ( '/' === $cseg[ $te - 1 ] ) { $tp = $te + 1; continue; }
						$tb2 = strpos( $cseg, '</w:t>', $te );
						if ( false === $tb2 ) { break; }
						$txt .= substr( $cseg, $te + 1, $tb2 - $te - 1 );
						$tp = $tb2 + 6;
					}
					$cells[] = trim( preg_replace( '/\s+/u', ' ', html_entity_decode( $txt, ENT_QUOTES | ENT_HTML5, 'UTF-8' ) ) );
				}
				if ( $cells ) { $rows[] = $cells; }
			}
			if ( $rows ) { $tables[] = $rows; }
		}
		return $tables;
	}

	/* ============ Trích văn bản PDF thuần PHP (không cần thư viện) ============ */
	protected static function pdf_a85( $data ) {
		$data = preg_replace( '/\s+/', '', $data );
		if ( '~>' === substr( $data, -2 ) ) { $data = substr( $data, 0, -2 ); }
		$out = ''; $grp = array(); $len = strlen( $data );
		for ( $i = 0; $i < $len; $i++ ) {
			$o = ord( $data[ $i ] );
			if ( 0x7a === $o && ! $grp ) { $out .= "\x00\x00\x00\x00"; continue; }
			if ( $o < 0x21 || $o > 0x75 ) { continue; }
			$grp[] = $o - 33;
			if ( 5 === count( $grp ) ) {
				$v = 0;
				foreach ( $grp as $g ) { $v = $v * 85 + $g; }
				$out .= pack( 'N', $v ); $grp = array();
			}
		}
		if ( $grp ) {
			$n = count( $grp );
			for ( $k = $n; $k < 5; $k++ ) { $grp[] = 84; }
			$v = 0;
			foreach ( $grp as $g ) { $v = $v * 85 + $g; }
			$out .= substr( pack( 'N', $v ), 0, $n - 1 );
		}
		return $out;
	}

	protected static function pdf_stream( $body ) {
		$i = strpos( $body, 'stream' );
		if ( false === $i ) { return null; }
		$head = substr( $body, 0, $i );
		$j = $i + 6;
		if ( "\r\n" === substr( $body, $j, 2 ) ) { $j += 2; }
		elseif ( "\n" === substr( $body, $j, 1 ) ) { $j += 1; }
		if ( preg_match( '/\/Length\s+(\d+)\b/', $head, $lm ) ) {
			$data = substr( $body, $j, (int) $lm[1] );
		} else {
			$k = strpos( $body, 'endstream', $j );
			if ( false === $k ) { return null; }
			$data = substr( $body, $j, $k - $j );
		}
		if ( false !== strpos( $head, '/ASCII85Decode' ) ) { $data = self::pdf_a85( $data ); }
		if ( false !== strpos( $head, '/FlateDecode' ) ) {
			$d2 = @gzuncompress( $data );
			if ( false === $d2 ) { $d2 = @gzinflate( $data ); }
			if ( false === $d2 ) { $d2 = @gzinflate( substr( $data, 2 ) ); }
			if ( false === $d2 ) { return null; }
			$data = $d2;
		}
		return $data;
	}

	protected static function pdf_cp2utf8( $cp ) {
		if ( $cp < 0x80 ) { return chr( $cp ); }
		if ( $cp < 0x800 ) { return chr( 0xC0 | ( $cp >> 6 ) ) . chr( 0x80 | ( $cp & 0x3F ) ); }
		if ( $cp < 0x10000 ) { return chr( 0xE0 | ( $cp >> 12 ) ) . chr( 0x80 | ( ( $cp >> 6 ) & 0x3F ) ) . chr( 0x80 | ( $cp & 0x3F ) ); }
		return chr( 0xF0 | ( $cp >> 18 ) ) . chr( 0x80 | ( ( $cp >> 12 ) & 0x3F ) ) . chr( 0x80 | ( ( $cp >> 6 ) & 0x3F ) ) . chr( 0x80 | ( $cp & 0x3F ) );
	}

	protected static function pdf_unesc( $b ) {
		$out = ''; $i = 0; $n = strlen( $b );
		$mapc = array( 'n' => "\n", 'r' => "\r", 't' => "\t", 'b' => "\x08", 'f' => "\x0C" );
		while ( $i < $n ) {
			$c = $b[ $i ];
			if ( '\\' === $c && $i + 1 < $n ) {
				$x = $b[ $i + 1 ];
				if ( isset( $mapc[ $x ] ) ) { $out .= $mapc[ $x ]; $i += 2; continue; }
				if ( '(' === $x || ')' === $x || '\\' === $x ) { $out .= $x; $i += 2; continue; }
				if ( $x >= '0' && $x <= '7' ) {
					$j = $i + 1; $oc = 0; $k = 0;
					while ( $j < $n && $b[ $j ] >= '0' && $b[ $j ] <= '7' && $k < 3 ) { $oc = $oc * 8 + ( ord( $b[ $j ] ) - 48 ); $j++; $k++; }
					$out .= chr( $oc & 0xFF ); $i = $j; continue;
				}
				$i += 1; continue;
			}
			$out .= $c; $i++;
		}
		return $out;
	}

	public static function pdf_text( $path ) {
		$raw = @file_get_contents( $path );
		if ( ! $raw || '%PDF' !== substr( $raw, 0, 4 ) || strlen( $raw ) > 30 * 1024 * 1024 ) { return ''; }
		// 1) Quét object TUẦN TỰ (dùng /Length để nhảy qua stream nhị phân)
		$objs = array(); $pos = 0; $rl = strlen( $raw );
		while ( $pos < $rl && preg_match( '/(\d+)\s+\d+\s+obj\b/', $raw, $m, PREG_OFFSET_CAPTURE, $pos ) ) {
			$num   = (int) $m[1][0];
			$start = $m[0][1] + strlen( $m[0][0] );
			$he    = strpos( $raw, 'stream', $start );
			$e     = strpos( $raw, 'endobj', $start );
			if ( false !== $he && ( false === $e || $he < $e ) ) {
				$j = $he + 6;
				if ( "\r\n" === substr( $raw, $j, 2 ) ) { $j += 2; }
				elseif ( "\n" === substr( $raw, $j, 1 ) ) { $j += 1; }
				if ( preg_match( '/\/Length\s+(\d+)\b/', substr( $raw, $start, $he - $start ), $lm ) ) {
					$e = strpos( $raw, 'endobj', $j + (int) $lm[1] );
				} else {
					$k = strpos( $raw, 'endstream', $j );
					$e = ( false !== $k ) ? strpos( $raw, 'endobj', $k ) : false;
				}
			}
			if ( false === $e ) { $e = $rl; }
			$objs[ $num ] = substr( $raw, $start, $e - $start );
			$pos = $e + 6;
		}
		// 2) ToUnicode CMap của từng font object
		$cmaps = array();
		foreach ( $objs as $num => $body ) {
			if ( ! preg_match( '/\/ToUnicode\s+(\d+)\s+\d+\s+R/', $body, $rm ) ) { continue; }
			$tn = (int) $rm[1];
			if ( ! isset( $objs[ $tn ] ) ) { continue; }
			$st = self::pdf_stream( $objs[ $tn ] );
			if ( ! $st ) { continue; }
			$mp = array(); $codelen = 2;
			if ( preg_match_all( '/beginbfchar(.*?)endbfchar/s', $st, $bb ) ) {
				foreach ( $bb[1] as $blk ) {
					if ( preg_match_all( '/<([0-9A-Fa-f]+)>\s*<([0-9A-Fa-f]+)>/', $blk, $pm, PREG_SET_ORDER ) ) {
						foreach ( $pm as $p ) {
							$codelen = (int) ( strlen( $p[1] ) / 2 );
							$u = ''; $dl = strlen( $p[2] );
							for ( $x = 0; $x + 4 <= $dl; $x += 4 ) { $u .= self::pdf_cp2utf8( hexdec( substr( $p[2], $x, 4 ) ) ); }
							$mp[ hexdec( $p[1] ) ] = $u;
						}
					}
				}
			}
			if ( preg_match_all( '/beginbfrange(.*?)endbfrange/s', $st, $br ) ) {
				foreach ( $br[1] as $blk ) {
					if ( preg_match_all( '/<([0-9A-Fa-f]+)>\s*<([0-9A-Fa-f]+)>\s*<([0-9A-Fa-f]+)>/', $blk, $pm, PREG_SET_ORDER ) ) {
						foreach ( $pm as $p ) {
							$codelen = (int) ( strlen( $p[1] ) / 2 );
							$lo = hexdec( $p[1] ); $hi = hexdec( $p[2] );
							$base = hexdec( substr( $p[3], 0, 4 ) );
							$hi = min( $hi, $lo + 65535 );
							for ( $c = $lo; $c <= $hi; $c++ ) { $mp[ $c ] = self::pdf_cp2utf8( $base + ( $c - $lo ) ); }
						}
					}
				}
			}
			if ( $mp ) { $cmaps[ $num ] = array( $mp, $codelen ); }
		}
		// 3) Tên font -> font object (dict nội tuyến hoặc tham chiếu gián tiếp)
		$name2font = array();
		foreach ( $objs as $num => $body ) {
			if ( preg_match_all( '/\/Font\s*<<(.*?)>>/s', $body, $fms ) ) {
				foreach ( $fms[1] as $fm ) {
					if ( preg_match_all( '#/([^\s/<>\[\]()]+)\s+(\d+)\s+\d+\s+R#', $fm, $nms, PREG_SET_ORDER ) ) {
						foreach ( $nms as $nm ) { $name2font[ $nm[1] ] = (int) $nm[2]; }
					}
				}
			}
			if ( preg_match_all( '/\/Font\s+(\d+)\s+\d+\s+R/', $body, $fms2 ) ) {
				foreach ( $fms2[1] as $fref ) {
					if ( ! isset( $objs[ (int) $fref ] ) ) { continue; }
					if ( preg_match_all( '#/([^\s/<>\[\]()]+)\s+(\d+)\s+\d+\s+R#', $objs[ (int) $fref ], $nms2, PREG_SET_ORDER ) ) {
						foreach ( $nms2 as $nm ) { $name2font[ $nm[1] ] = (int) $nm[2]; }
					}
				}
			}
		}
		// 4) Quét content stream: Tf đặt font, () và <hex> là chuỗi chữ
		$pages = array();
		foreach ( $objs as $num => $body ) {
			$st = self::pdf_stream( $body );
			if ( ! $st || false === strpos( $st, 'BT' ) ) { continue; }
			$cur = null; $i = 0; $n = strlen( $st ); $buf = '';
			while ( $i < $n ) {
				$ch = $st[ $i ];
				if ( '/' === $ch ) {
					if ( preg_match( '#\G/([^\s/<>\[\]()]+)\s+[\d.]+\s+Tf#', $st, $fm, 0, $i ) ) {
						$fnum = isset( $name2font[ $fm[1] ] ) ? $name2font[ $fm[1] ] : -1;
						$cur  = isset( $cmaps[ $fnum ] ) ? $cmaps[ $fnum ] : null;
						$i   += strlen( $fm[0] ); continue;
					}
					$i++; continue;
				}
				if ( '(' === $ch ) {
					$j = $i + 1; $s = ''; $depth = 1;
					while ( $j < $n && $depth > 0 ) {
						$c = $st[ $j ];
						if ( '\\' === $c && $j + 1 < $n ) { $s .= $c . $st[ $j + 1 ]; $j += 2; continue; }
						if ( '(' === $c ) { $depth++; }
						elseif ( ')' === $c ) { $depth--; if ( 0 === $depth ) { break; } }
						$s .= $c; $j++;
					}
					$b = self::pdf_unesc( $s );
					if ( $cur ) {
						$mp = $cur[0]; $cl = $cur[1]; $bl = strlen( $b );
						for ( $x = 0; $x + $cl <= $bl; $x += $cl ) {
							$code = 0;
							for ( $y = 0; $y < $cl; $y++ ) { $code = ( $code << 8 ) | ord( $b[ $x + $y ] ); }
							if ( isset( $mp[ $code ] ) ) { $buf .= $mp[ $code ]; }
						}
					} else {
						$buf .= mb_convert_encoding( $b, 'UTF-8', 'ISO-8859-1' );
					}
					$i = $j + 1; continue;
				}
				if ( '<' === $ch && '<' !== substr( $st, $i + 1, 1 ) ) {
					$j = strpos( $st, '>', $i );
					if ( false === $j ) { $i++; continue; }
					$hx = preg_replace( '/[^0-9A-Fa-f]/', '', substr( $st, $i + 1, $j - $i - 1 ) );
					if ( strlen( $hx ) % 2 ) { $hx .= '0'; }
					$b = pack( 'H*', $hx );
					if ( $cur ) {
						$mp = $cur[0]; $cl = $cur[1]; $bl = strlen( $b );
						for ( $x = 0; $x + $cl <= $bl; $x += $cl ) {
							$code = 0;
							for ( $y = 0; $y < $cl; $y++ ) { $code = ( $code << 8 ) | ord( $b[ $x + $y ] ); }
							if ( isset( $mp[ $code ] ) ) { $buf .= $mp[ $code ]; }
						}
					} else {
						$buf .= mb_convert_encoding( $b, 'UTF-8', 'ISO-8859-1' );
					}
					$i = $j + 1; continue;
				}
				$two = substr( $st, $i, 2 );
				if ( 'Td' === $two || 'TD' === $two || 'T*' === $two || 'ET' === $two ) { $buf .= "\n"; $i += 2; continue; }
				if ( 'Tj' === $two || 'TJ' === $two ) { $buf .= ' '; $i += 2; continue; }
				$i++;
			}
			$buf = preg_replace( '/[ \t]+/', ' ', $buf );
			$buf = trim( preg_replace( '/\n{2,}/', "\n", $buf ) );
			if ( '' !== $buf ) { $pages[] = $buf; }
		}
		return implode( "\n", $pages );
	}

	/* Vá tên dự án bị cắt trong phụ lục (khôi phục từ tên đầy đủ của danh mục Excel) */
	public static function repair_phuluc( $plc ) {
		if ( ! is_array( $plc ) || empty( $plc['units'] ) ) { return $plc; }
		$dv = function_exists( 'lado_ai_get_donvi' ) ? lado_ai_get_donvi() : array();
		if ( empty( $dv['units'] ) || ! is_array( $dv['units'] ) ) { return $plc; }
		$npool = array();
		foreach ( $dv['units'] as $u ) {
			if ( empty( $u['projects'] ) ) { continue; }
			foreach ( $u['projects'] as $p ) {
				if ( ! empty( $p['ten'] ) ) { $npool[] = array( LaDo_AI_Directory::nrm( $p['ten'] ), $p['ten'] ); }
			}
		}
		if ( ! $npool ) { return $plc; }
		foreach ( $plc['units'] as $ui => $u ) {
			if ( empty( $u['projects'] ) ) { continue; }
			foreach ( $u['projects'] as $pi => $p ) {
				$ten = isset( $p['ten'] ) ? $p['ten'] : '';
				if ( mb_strlen( $ten ) < 88 ) { continue; }
				$k = LaDo_AI_Directory::nrm( $ten );
				foreach ( $npool as $cand ) {
					if ( 0 === strpos( $cand[0], $k ) && mb_strlen( $cand[1] ) > mb_strlen( $ten ) ) { $ten = $cand[1]; $k = $cand[0]; }
				}
				$plc['units'][ $ui ]['projects'][ $pi ]['ten'] = $ten;
			}
		}
		return $plc;
	}

	/* ---- Báo cáo TỔ CÔNG TÁC (từng tổ, theo nhóm vướng mắc) ---- */
	public static function parse_tct( $path ) {
		@ini_set( 'pcre.backtrack_limit', '50000000' );
		$text   = self::docx( $path );
		$tables = self::docx_tables_safe( $path );
		$to     = array();
		if ( ! preg_match( '#TỔ CÔNG TÁC SỐ\s*(\d+)\s*—\s*([^\n]+)#u', $text, $m ) ) { return null; }
		$to['so']  = (int) $m[1];
		$to['ten'] = trim( $m[2] );
		if ( preg_match( '#\((?:Ô\.?|Bà|B\.)\s*(.+?)\s+làm Tổ trưởng\)#u', $text, $m ) ) { $to['to_truong'] = trim( $m[1] ); }
		if ( preg_match( '#TỔ TRƯỞNG\s*—\s*([^\n]+)#u', $text, $m ) ) { $to['to_truong_full'] = trim( $m[1] ); }
		if ( preg_match( '#Kho bạc đến ngày\s*([\d/]+)#u', $text, $m ) ) { $to['as_of'] = $m[1]; }
		if ( preg_match( '#Tổng kế hoạch vốn[^:]*:\s*([\d.]+)[^(]*\(vốn năm 2026:\s*([\d.]+);\s*vốn 2025 kéo dài:\s*([\d.]+)\)#u', $text, $m ) ) {
			$to['kh'] = self::pnum( $m[1] ); $to['kh26'] = self::pnum( $m[2] ); $to['kh25'] = self::pnum( $m[3] );
		}
		if ( preg_match( '#Giải ngân đến ngày\s*[\d/]+:\s*([\d.]+)#u', $text, $m ) ) { $to['gn_truoc'] = self::pnum( $m[1] ); }
		if ( preg_match( '#Lũy kế giải ngân đến ngày\s*[\d/]+:\s*([\d.]+)[^—]*—\s*tỷ lệ\s*([\d.,]+)\s*%#u', $text, $m ) ) {
			$to['gn'] = self::pnum( $m[1] );
			$to['tl'] = (float) str_replace( ',', '.', str_replace( '.', '', $m[2] ) );
		}
		if ( preg_match( '#phát sinh trong kỳ[^:]*:\s*([\d.]+)#u', $text, $m ) ) { $to['ps'] = self::pnum( $m[1] ); }
		$to['dg_tot'] = array( 'n' => 0, 'text' => '' );
		if ( preg_match( '#3\.1\..*?:\s*(\d+)\s*dự án(?:,\s*tiêu biểu:\s*([^\n]+))?#u', $text, $m ) ) {
			$to['dg_tot'] = array( 'n' => (int) $m[1], 'text' => isset( $m[2] ) ? rtrim( trim( $m[2] ), '.' ) : '' );
		}
		$to['dg_chuatot'] = array( 'n' => 0, 'kh' => 0 );
		if ( preg_match( '#3\.2\..*?:\s*(\d+)\s*dự án,\s*tổng KH\s*([\d.]+)#u', $text, $m ) ) {
			$to['dg_chuatot'] = array( 'n' => (int) $m[1], 'kh' => self::pnum( $m[2] ) );
		}
		$to['dg_zero'] = array( 'n' => 0, 'kh' => 0, 'text' => '' );
		if ( preg_match( '#3\.3\..*?:\s*(\d+)\s*dự án,\s*tổng KH\s*([\d.]+)\.\s*Phân theo nguyên nhân\s*—\s*([^\n]+)#u', $text, $m ) ) {
			$to['dg_zero'] = array( 'n' => (int) $m[1], 'kh' => self::pnum( $m[2] ), 'text' => rtrim( trim( $m[3] ), '.' ) );
		}
		// Các nhóm vướng mắc (theo thứ tự xuất hiện) + bảng dự án tương ứng
		$heads = array();
		if ( preg_match_all( '#^Nhóm\s*(\d+)\s*—\s*(.+?)\s*—\s*(\d+)\s*dự án\s*·\s*KH\s*([\d.]+)\s*·\s*giải ngân\s*([\d.]+)\s*\(([\d.,%\-]+)\)#mu', $text, $mm, PREG_SET_ORDER ) ) {
			foreach ( $mm as $m ) {
				$heads[] = array( 'so' => (int) $m[1], 'ten' => trim( $m[2] ), 'n' => (int) $m[3], 'kh' => self::pnum( $m[4] ), 'gn' => self::pnum( $m[5] ), 'tl' => $m[6], 'projects' => array() );
			}
		}
		$tabs = array();
		foreach ( $tables as $tb ) {
			if ( count( $tb[0] ) >= 7 && isset( $tb[0][1] ) && false !== mb_stripos( $tb[0][1], 'Tên dự án' ) ) { $tabs[] = $tb; }
		}
		$ti = 0;
		foreach ( $heads as $hi => $h ) {
			if ( $h['n'] > 0 && isset( $tabs[ $ti ] ) ) {
				$tb = $tabs[ $ti ]; $ti++;
				$nc = count( $tb[0] );
				foreach ( $tb as $ri => $r ) {
					if ( 0 === $ri || empty( $r[1] ) ) { continue; }
					$heads[ $hi ]['projects'][] = array(
						'ten' => trim( $r[1] ),
						'ma'  => isset( $r[2] ) ? trim( $r[2] ) : '',
						'cdt' => isset( $r[3] ) ? trim( $r[3] ) : '',
						'kh'  => self::pnum( isset( $r[4] ) ? $r[4] : 0 ),
						'gn'  => self::pnum( isset( $r[5] ) ? $r[5] : 0 ),
						'tl'  => isset( $r[6] ) ? trim( $r[6] ) : '',
						'vm'  => ( $nc > 7 && isset( $r[7] ) ) ? trim( $r[7] ) : '',
					);
				}
			}
		}
		$to['nhom'] = $heads;
		return $to;
	}

	/* Vá tên dự án/vướng mắc bị cắt trong file Tổ (khôi phục từ danh mục Excel + phụ lục + kiến nghị) */
	public static function repair_tct( $tc ) {
		if ( ! is_array( $tc ) || empty( $tc['nhom'] ) ) { return $tc; }
		$dv   = function_exists( 'lado_ai_get_donvi' ) ? lado_ai_get_donvi() : array();
		$pool = array(); $ma2 = array();
		if ( isset( $dv['units'] ) && is_array( $dv['units'] ) ) {
			foreach ( $dv['units'] as $u ) {
				if ( empty( $u['projects'] ) ) { continue; }
				foreach ( $u['projects'] as $p ) { if ( ! empty( $p['ten'] ) ) { $pool[ $p['ten'] ] = 1; } }
			}
		}
		if ( isset( $dv['phuluc']['units'] ) && is_array( $dv['phuluc']['units'] ) ) {
			foreach ( $dv['phuluc']['units'] as $u ) {
				if ( empty( $u['projects'] ) ) { continue; }
				foreach ( $u['projects'] as $p ) {
					if ( ! empty( $p['ten'] ) ) { $pool[ $p['ten'] ] = 1; }
					if ( ! empty( $p['ma'] ) && '-' !== $p['ma'] ) {
						if ( ! isset( $ma2[ $p['ma'] ] ) || mb_strlen( $p['ten'] ) > mb_strlen( $ma2[ $p['ma'] ] ) ) { $ma2[ $p['ma'] ] = $p['ten']; }
					}
				}
			}
		}
		$npool = array();
		foreach ( array_keys( $pool ) as $f ) { $npool[] = array( LaDo_AI_Directory::nrm( $f ), $f ); }
		$kn = function_exists( 'lado_ai_get_kiennghi' ) ? lado_ai_get_kiennghi() : array();
		$knmap = array();
		if ( isset( $kn['items'] ) && is_array( $kn['items'] ) ) {
			foreach ( $kn['items'] as $x ) {
				if ( ! empty( $x['du_an'] ) && ! empty( $x['kho_khan'] ) ) {
					$k = LaDo_AI_Directory::nrm( $x['du_an'] );
					if ( ! isset( $knmap[ $k ] ) || mb_strlen( $x['kho_khan'] ) > mb_strlen( $knmap[ $k ] ) ) { $knmap[ $k ] = $x['kho_khan']; }
				}
			}
		}
		foreach ( $tc['nhom'] as $gi => $g ) {
			if ( empty( $g['projects'] ) ) { continue; }
			foreach ( $g['projects'] as $pi => $p ) {
				$ten = $p['ten'];
				if ( ! empty( $p['ma'] ) && '-' !== $p['ma'] && isset( $ma2[ $p['ma'] ] ) && mb_strlen( $ma2[ $p['ma'] ] ) > mb_strlen( $ten ) ) { $ten = $ma2[ $p['ma'] ]; }
				if ( mb_strlen( $ten ) >= 88 ) {
					$k = LaDo_AI_Directory::nrm( $ten );
					foreach ( $npool as $cand ) {
						if ( 0 === strpos( $cand[0], $k ) && mb_strlen( $cand[1] ) > mb_strlen( $ten ) ) { $ten = $cand[1]; $k = $cand[0]; }
					}
				}
				$tc['nhom'][ $gi ]['projects'][ $pi ]['ten'] = $ten;
				if ( ! empty( $p['vm'] ) && mb_strlen( $p['vm'] ) >= 100 ) {
					$k2 = LaDo_AI_Directory::nrm( $ten );
					if ( isset( $knmap[ $k2 ] ) && mb_strlen( $knmap[ $k2 ] ) > mb_strlen( $p['vm'] ) ) { $tc['nhom'][ $gi ]['projects'][ $pi ]['vm'] = $knmap[ $k2 ]; }
				}
			}
		}
		return $tc;
	}

	/* ---------------- Chuyển báo cáo Word -> số liệu biểu đồ ---------------- */
	public static function parse_report( $path ) {
		$tables = self::docx_tables( $path );
		$text   = self::extract( $path );
		if ( empty( $tables ) ) { return null; }
		$out = array();

		// 1) Bảng tổng hợp theo khối (có dòng "TOÀN TỈNH")
		foreach ( $tables as $tb ) {
			$has_toan = false;
			foreach ( $tb as $r ) { if ( isset( $r[0] ) && self::has( $r[0], 'TOÀN TỈNH' ) ) { $has_toan = true; break; } }
			if ( ! $has_toan ) { continue; }
			$khoi = array();
			foreach ( $tb as $r ) {
				if ( count( $r ) < 3 ) { continue; }
				$name = $r[0];
				$pi   = self::pct_idx( $r );
				if ( $pi < 1 ) { continue; }
				$tl = self::ppct( $r[ $pi ] );
				$gn = self::pnum( $r[ $pi - 1 ] );
				$kh = self::pnum( $r[1] );
				$gn26 = ( $pi - 1 >= 3 ) ? self::pnum( $r[2] ) : null;
				$gnkd = ( $pi - 1 >= 3 ) ? self::pnum( $r[3] ) : null;
				if ( self::has( $name, 'TOÀN TỈNH' ) ) {
					$tang = null; $tangpc = null;
					if ( $pi + 1 < count( $r ) ) {
						$parts = preg_split( '#[/]#', $r[ $pi + 1 ] );
						$tang = self::pnum( $parts[0] );
						if ( isset( $parts[1] ) ) { $tangpc = self::ppct( $parts[1] . '%' ); }
					}
					$tong = array( 'kh' => $kh, 'gn' => $gn, 'tl' => $tl );
					if ( null !== $tang ) { $tong['tang'] = $tang; }
					if ( null !== $tangpc ) { $tong['tang_pc'] = $tangpc; }
					$out['tong'] = $tong;
					if ( null !== $gn26 || null !== $gnkd ) {
						$out['nguon'] = array(
							array( 'ten' => 'Vốn năm 2026', 'gn' => $gn26 ),
							array( 'ten' => 'Vốn kéo dài 2025', 'gn' => $gnkd ),
						);
					}
				} elseif ( self::has( $name, 'Ban QLDA' ) || self::has( $name, 'Ban Quản lý' ) ) {
					$khoi[] = array( 'ten' => 'Ban QLDA', 'kh' => $kh, 'gn' => $gn, 'tl' => $tl );
				} elseif ( self::has( $name, 'Sở' ) && self::has( $name, 'ngành' ) ) {
					$khoi[] = array( 'ten' => 'Sở, ngành, đơn vị', 'kh' => $kh, 'gn' => $gn, 'tl' => $tl );
				} elseif ( self::has( $name, 'Xã' ) || self::has( $name, 'phường' ) ) {
					$khoi[] = array( 'ten' => 'Xã, phường, đặc khu', 'kh' => $kh, 'gn' => $gn, 'tl' => $tl );
				}
			}
			if ( $khoi ) { $out['khoi'] = $khoi; }
			break;
		}

		// 2) Bảng kế hoạch giao
		foreach ( $tables as $tb ) {
			$hit = array();
			foreach ( $tb as $r ) {
				if ( ! isset( $r[0] ) ) { continue; }
				$pi = self::pct_idx( $r ); if ( $pi < 1 ) { continue; }
				if ( self::has( $r[0], 'Thủ tướng' ) ) { $hit[] = array( 'ten' => 'Thủ tướng Chính phủ giao', 'kh' => self::pnum( $r[1] ), 'tl' => self::ppct( $r[ $pi ] ) ); }
				elseif ( self::has( $r[0], 'HĐND' ) ) { $hit[] = array( 'ten' => 'HĐND tỉnh giao', 'kh' => self::pnum( $r[1] ), 'tl' => self::ppct( $r[ $pi ] ) ); }
				elseif ( self::has( $r[0], 'UBND' ) ) { $hit[] = array( 'ten' => 'UBND tỉnh phân bổ', 'kh' => self::pnum( $r[1] ), 'tl' => self::ppct( $r[ $pi ] ) ); }
			}
			if ( count( $hit ) >= 2 ) { $out['kehoach_giao'] = $hit; break; }
		}

		// 3) Bảng chi tiết Ban -> all/top/bottom
		$ban_rows = array();
		foreach ( $tables as $tb ) {
			$tmp = array();
			foreach ( $tb as $r ) {
				$ni = -1;
				if ( isset( $r[1] ) && self::has( $r[1], 'Ban QLDA ĐTXD' ) ) { $ni = 1; }
				elseif ( isset( $r[0] ) && self::has( $r[0], 'Ban QLDA ĐTXD' ) ) { $ni = 0; }
				if ( $ni < 0 ) { continue; }
				$pi = self::pct_idx( $r ); if ( $pi < 1 ) { continue; }
				$nm = trim( preg_replace( '/\s+/u', ' ', str_replace( array( 'Ban QLDA ĐTXD', 'khu vực' ), array( '', 'KV' ), $r[ $ni ] ) ) );
				$tmp[] = array(
					'ten' => ( 0 === mb_stripos( $nm, 'KV' ) || 0 === mb_stripos( $nm, 'số' ) ? $nm : 'KV ' . $nm ),
					'kh'  => isset( $r[ $ni + 1 ] ) ? self::pnum( $r[ $ni + 1 ] ) : null,
					'gn'  => self::pnum( $r[ $pi - 1 ] ),
					'tl'  => self::ppct( $r[ $pi ] ),
				);
			}
			if ( count( $tmp ) > count( $ban_rows ) ) { $ban_rows = $tmp; }
		}
		$ban_rows = array_values( array_filter( $ban_rows, function ( $x ) { return null !== $x['tl']; } ) );
		if ( count( $ban_rows ) >= 6 ) {
			usort( $ban_rows, function ( $a, $b ) { return $b['tl'] <=> $a['tl']; } );
			$out['all_ban'] = $ban_rows;
			$out['top_ban'] = array_slice( $ban_rows, 0, 6 );
			$bottom = array_slice( $ban_rows, -5 );
			usort( $bottom, function ( $a, $b ) { return $a['tl'] <=> $b['tl']; } );
			$out['bottom_ban'] = $bottom;
		}

		// 4) Bảng chi tiết Sở -> top_so + 0% (chọn bảng nhiều dòng nhất = bảng đầy đủ 41 đơn vị)
		$best_all = array(); $best_zero = array();
		foreach ( $tables as $tb ) {
			$zero = array(); $all = array(); $ok = false;
			foreach ( $tb as $r ) {
				if ( ! isset( $r[1] ) ) { continue; }
				$pi = self::pct_idx( $r ); if ( $pi < 1 ) { continue; }
				$name = $r[1];
				if ( self::has( $name, 'Chủ đầu tư' ) ) { continue; }
				if ( self::has( $name, 'Chính sách xã hội' ) || self::has( $name, 'Sở ' ) || self::has( $name, 'Ban QLR' ) || self::has( $name, 'Công ty' ) ) { $ok = true; }
				$tl = self::ppct( $r[ $pi ] ); if ( null === $tl ) { continue; }
				$all[] = array( 'ten' => $name, 'kh' => ( $pi - 2 >= 0 ? self::pnum( $r[ $pi - 2 ] ) : 0 ), 'gn' => self::pnum( $r[ $pi - 1 ] ), 'tl' => $tl );
				if ( $tl <= 0.0001 ) { $zero[] = $name; }
			}
			if ( $ok && count( $all ) > count( $best_all ) ) { $best_all = $all; $best_zero = $zero; }
		}
		if ( $best_all ) {
			$sorted = $best_all;
			usort( $sorted, function ( $a, $b ) { return $b['tl'] <=> $a['tl']; } );
			$out['all_so'] = $sorted;
			$so_rank = array_values( array_filter( $sorted, function ( $x ) {
				return false === mb_stripos( $x['ten'], 'Chính sách xã hội' )
					&& ! preg_match( '/(^|\s)(xã|phường)\b|UBND xã|UBND huyện|đặc khu/iu', $x['ten'] )
					&& ( ! isset( $x['kh'] ) || (float) $x['kh'] >= 1000 );
			} ) );
			$out['top_so'] = array_slice( $so_rank, 0, 5 );
			$out['zero_list_so'] = array_values( $best_zero );
		}

		// 5) Bảng chi tiết Xã -> top_xa + 0% (chọn bảng nhiều dòng nhất = 124 đơn vị)
		$best_all = array(); $best_zero = array();
		foreach ( $tables as $tb ) {
			$zero = array(); $all = array(); $ok = false;
			foreach ( $tb as $r ) {
				if ( ! isset( $r[1] ) ) { continue; }
				$pi = self::pct_idx( $r ); if ( $pi < 1 ) { continue; }
				$name = $r[1];
				if ( self::has( $name, '/ phường' ) || self::has( $name, 'Xã /' ) ) { continue; }
				if ( self::has( $name, 'Xã ' ) || self::has( $name, 'Phường ' ) || self::has( $name, 'Đặc khu' ) ) { $ok = true; } else { continue; }
				$tl = self::ppct( $r[ $pi ] ); if ( null === $tl ) { continue; }
				$all[] = array( 'ten' => $name, 'kh' => ( $pi - 2 >= 0 ? self::pnum( $r[ $pi - 2 ] ) : null ), 'gn' => self::pnum( $r[ $pi - 1 ] ), 'tl' => $tl );
				if ( $tl <= 0.0001 ) { $zero[] = $name; }
			}
			if ( $ok && count( $all ) > count( $best_all ) ) { $best_all = $all; $best_zero = $zero; }
		}
		if ( count( $best_all ) >= 10 ) {
			$sorted = $best_all;
			usort( $sorted, function ( $a, $b ) { return $b['tl'] <=> $a['tl']; } );
			$out['all_xa'] = $sorted;
			$xa_rank = array_values( array_filter( $sorted, function ( $x ) { return ! isset( $x['kh'] ) || (float) $x['kh'] >= 1000; } ) );
			$out['top_xa'] = array_slice( $xa_rank, 0, 5 );
			$out['zero_list_xa'] = array_values( $best_zero );
		}

		$zso = isset( $out['zero_list_so'] ) ? count( $out['zero_list_so'] ) : 0;
		$zxa = isset( $out['zero_list_xa'] ) ? count( $out['zero_list_xa'] ) : 0;
		if ( $zso || $zxa ) { $out['zero'] = array( 'tong' => $zso + $zxa, 'so' => $zso, 'xa' => $zxa ); }

		if ( preg_match( '#đến ngày\s*([0-9]{1,2}/[0-9]{1,2}/[0-9]{4})#u', $text, $md ) ) { $out['as_of'] = $md[1]; }
		$out['tinh'] = 'Lâm Đồng';
		$out['unit'] = 'triệu đồng';

		if ( isset( $out['nguon'][1] ) ) {
			$kd = null;
			if ( preg_match( '#kéo dài[^%]{0,120}?([0-9][0-9\.]{6,})\s*(?:triệu đồng\s*)?(?:trên|/)\s*([0-9][0-9\.]{6,})#u', $text, $mm ) ) {
				$kd = self::pnum( $mm[2] );
			}
			if ( $kd && $kd > 0 ) {
				$out['nguon'][1]['kh'] = $kd;
				if ( ! empty( $out['nguon'][1]['gn'] ) ) {
					$out['nguon'][1]['tl'] = round( $out['nguon'][1]['gn'] / $kd * 100, 2 );
				}
				if ( isset( $out['tong']['kh'] ) ) {
					$kh26 = $out['tong']['kh'] - $kd;
					if ( $kh26 > 0 ) {
						$out['nguon'][0]['kh'] = $kh26;
						if ( ! empty( $out['nguon'][0]['gn'] ) ) {
							$out['nguon'][0]['tl'] = round( $out['nguon'][0]['gn'] / $kh26 * 100, 2 );
						}
					}
				}
			}
		}
		return $out;
	}

	/* ---------------- Thống kê kế hoạch tuần từ báo cáo tuần ---------------- */
	public static function parse_weekly( $path ) {
		$tables = self::docx_tables( $path );
		$text   = self::extract( $path );
		if ( empty( $tables ) ) { return null; }

		$tot = array(); $phan = array(); $khong = array(); $dk0 = array();
		foreach ( $tables as $tb ) {
			if ( empty( $tb ) ) { continue; }
			$head = $tb[0];
			if ( false === mb_stripos( implode( ' | ', $head ), 'KH tuần' ) ) { continue; }
			$ni = 0;
			foreach ( $head as $i => $h ) {
				if ( self::has( $h, 'Chủ đầu tư' ) || self::has( $h, 'Xã' ) || self::has( $h, 'phường' ) || self::has( $h, 'đơn vị' ) ) { $ni = $i; break; }
			}
			$ki = -1; $ti = -1;
			foreach ( $head as $i => $h ) {
				if ( $ki < 0 && self::has( $h, 'KH tuần' ) ) { $ki = $i; }
				elseif ( $ti < 0 && self::has( $h, 'TH tuần' ) ) { $ti = $i; }
			}
			if ( $ki < 0 ) { continue; }
			foreach ( array_slice( $tb, 1 ) as $r ) {
				if ( ! isset( $r[ $ni ] ) || '' === trim( $r[ $ni ] ) ) { continue; }
				if ( self::has( $r[ $ni ], 'TOÀN TỈNH' ) || self::has( $r[ $ni ], 'Khối ' ) ) { continue; }
				$name = $r[ $ni ];
				$kh   = isset( $r[ $ki ] ) ? self::pnum( $r[ $ki ] ) : null;
				$th   = ( $ti >= 0 && isset( $r[ $ti ] ) ) ? self::pnum( $r[ $ti ] ) : null;
				$pc   = self::ppct( end( $r ) );
				if ( null === $kh ) { continue; }
				if ( 0 === $kh ) { $khong[] = $name; }
				elseif ( ( null !== $th && 0 === $th ) || ( null !== $pc && $pc <= 0.0001 ) ) { $dk0[] = $name; }
				elseif ( null !== $pc && $pc >= 80 ) { $tot[] = $name; }
				else { $phan[] = $name; }
			}
		}
		$u = function ( $a ) { return array_values( array_unique( $a ) ); };
		$ky = '';
		if ( preg_match( '#Tuần\s*([0-9]+)#u', $text, $m ) ) { $ky = 'Tuần ' . $m[1]; }
		$mk = function ( $a ) use ( $u ) { $a = $u( $a ); return array( 'count' => count( $a ), 'list' => $a ); };
		return array(
			'ky'       => $ky,
			'tot'      => $mk( $tot ),
			'phan'     => $mk( $phan ),
			'khong_dk' => $mk( $khong ),
			'dk_0'     => $mk( $dk0 ),
		);
	}

	/* ---------------- Báo cáo NGÀY ---------------- */
	public static function parse_daily( $path ) {
		$tables = self::docx_tables( $path );
		$text   = self::extract( $path );
		if ( empty( $tables ) ) { return null; }
		$low   = function ( $s ) { return mb_strtolower( (string) $s, 'UTF-8' ); };
		$combo = function ( $s ) {
			if ( preg_match( '/([\d\.]+)\s*\(([\d,]+)%\)/u', (string) $s, $m ) ) { return array( self::pnum( $m[1] ), (float) str_replace( ',', '.', $m[2] ) ); }
			return array( 0, 0.0 );
		};
		$out = array( 'tinh' => 'Lâm Đồng', 'unit' => 'triệu đồng' );
		$tuan = null; $dk0 = array();

		foreach ( $tables as $tb ) {
			if ( empty( $tb ) ) { continue; }
			$H = $low( implode( ' | ', $tb[0] ) );

			if ( false !== mb_strpos( $H, 'khối chủ đầu tư' ) ) {
				$khoi = array();
				foreach ( array_slice( $tb, 1 ) as $r ) {
					if ( empty( $r[0] ) ) { continue; }
					$cb = $combo( end( $r ) ); $kh = self::pnum( $r[3] );
					if ( false !== mb_strpos( $low( $r[0] ), 'toàn tỉnh' ) ) {
						$out['tong'] = array( 'kh' => $kh, 'gn' => $cb[0], 'tl' => $cb[1] );
						$out['_kd'] = self::pnum( $r[1] ); $out['_v26'] = self::pnum( $r[2] );
					} else {
						$khoi[] = array( 'ten' => $r[0], 'kh' => $kh, 'gn' => $cb[0], 'tl' => $cb[1] );
					}
				}
				if ( $khoi ) { $out['khoi'] = $khoi; }
				continue;
			}
			if ( false !== mb_strpos( $H, 'mức kế hoạch giao' ) ) {
				$kg = array();
				foreach ( array_slice( $tb, 1 ) as $r ) {
					if ( empty( $r[0] ) ) { continue; }
					// T1: Mức giao | KH vốn | Đã giải ngân (vốn 2026) | Tỷ lệ — cột giữa là số giải ngân vốn 2026 ĐÚNG mẫu số giao
					$gn_giao = ( count( $r ) >= 4 ) ? self::pnum( $r[2] ) : 0;
					$kg[] = array( 'ten' => $r[0], 'kh' => self::pnum( $r[1] ), 'gn' => $gn_giao, 'tl' => self::ppct( end( $r ) ) );
				}
				if ( $kg ) { $out['kehoach_giao'] = $kg; }
				continue;
			}
			if ( false !== mb_strpos( $H, 'nguồn vốn' ) && false !== mb_strpos( $H, 'giải ngân' ) ) {
				$ng = array();
				foreach ( array_slice( $tb, 1 ) as $r ) {
					if ( empty( $r[0] ) || false !== mb_strpos( $low( $r[0] ), 'tổng' ) ) { continue; }
					$ng[] = array( 'ten' => $r[0], 'kh' => self::pnum( $r[1] ), 'gn' => self::pnum( $r[2] ), 'tl' => self::ppct( end( $r ) ) );
				}
				if ( count( $ng ) >= 2 ) { $out['nguon'] = array_slice( $ng, 0, 2 ); }
				continue;
			}
			if ( false !== mb_strpos( $H, 'kh tuần' ) && false !== mb_strpos( $H, 'đạt' ) ) {
				$t = $p = $z = $k = 0;
				foreach ( array_slice( $tb, 1 ) as $r ) {
					if ( empty( $r[0] ) || false !== mb_strpos( $low( $r[0] ), 'tổng' ) ) { continue; }
					$n = count( $r );
					$t += self::pnum( $r[ $n - 4 ] ); $p += self::pnum( $r[ $n - 3 ] );
					$z += self::pnum( $r[ $n - 2 ] ); $k += self::pnum( $r[ $n - 1 ] );
				}
				$tuan = array( $t, $p, $z, $k );
				continue;
			}
			if ( false !== mb_strpos( $H, 'đã đk' ) || false !== mb_strpos( $H, 'đã đăng ký' ) ) {
				foreach ( array_slice( $tb, 1 ) as $r ) {
					$dv = isset( $r[2] ) ? $r[2] : '';
					if ( '' !== $dv && false === mb_strpos( $low( $dv ), 'tổng' ) ) { $dk0[] = $dv; }
				}
				continue;
			}
			if ( false !== mb_strpos( $H, 'tổng kh' ) && false !== mb_strpos( $H, 'giải ngân' ) && false !== mb_strpos( $H, 'tỷ lệ' ) ) {
				$list = array();
				$curso = 0;
				foreach ( array_slice( $tb, 1 ) as $r ) {
					if ( empty( $r[1] ) || preg_match( '/^(CỘNG|TỔNG)/u', $r[1] ) ) { continue; }
					$ten = trim( $r[1] );
					if ( preg_match( '/Ban QLDA ĐTXD số (\d+)\s*\(tổng\)/u', $ten, $mso ) ) { $curso = (int) $mso[1]; }
					if ( $curso && preg_match( '/trực tiếp làm chủ đầu tư/u', $ten ) ) { $ten = 'Ban QLDA ĐTXD số ' . $curso . ' làm CĐT'; }
					$n = count( $r );
					$list[] = array( 'ten' => $ten, 'kh' => self::pnum( $r[ $n - 3 ] ), 'gn' => self::pnum( $r[ $n - 2 ] ), 'tl' => self::ppct( $r[ $n - 1 ] ) );
				}
				if ( ! $list ) { continue; }
				$first = trim( $list[0]['ten'] );
				if ( false !== mb_strpos( $first, 'Ban QL' ) ) { $out['all_ban'] = $list; }
				elseif ( preg_match( '/^(Xã|Phường|Đặc khu)/u', $first ) ) { $out['all_xa'] = $list; }
				else { $out['all_so'] = $list; }
				continue;
			}
		}

		// nguồn vốn: bổ sung kế hoạch nếu thiếu (từ tong)
		if ( isset( $out['nguon'][0] ) && empty( $out['nguon'][0]['kh'] ) && ! empty( $out['_v26'] ) ) { $out['nguon'][0]['kh'] = $out['_v26']; }
		if ( isset( $out['nguon'][1] ) && empty( $out['nguon'][1]['kh'] ) && ! empty( $out['_kd'] ) ) { $out['nguon'][1]['kh'] = $out['_kd']; }

		// xếp hạng + danh sách 0%
		$by_tl = function ( $arr, $desc, $n ) {
			usort( $arr, function ( $a, $b ) use ( $desc ) { return $desc ? ( $b['tl'] <=> $a['tl'] ) : ( $a['tl'] <=> $b['tl'] ); } );
			return array_slice( $arr, 0, $n );
		};
		$xa_like = function ( $x ) { return (bool) preg_match( '/(^|\s)(xã|phường)\b|UBND xã|UBND huyện|đặc khu/iu', isset( $x['ten'] ) ? $x['ten'] : '' ); };
		$big_enough = function ( $x ) { return ! isset( $x['kh'] ) || (float) $x['kh'] >= 1000; };
		if ( ! empty( $out['all_ban'] ) ) { $out['top_ban'] = $by_tl( $out['all_ban'], true, 6 ); $out['bottom_ban'] = $by_tl( $out['all_ban'], false, 5 ); }
		if ( ! empty( $out['all_so'] ) ) {
			$so_f = array_values( array_filter( $out['all_so'], function ( $x ) use ( $xa_like, $big_enough ) {
				return false === mb_stripos( isset( $x['ten'] ) ? $x['ten'] : '', 'Chính sách xã hội' ) && ! $xa_like( $x ) && $big_enough( $x );
			} ) );
			$out['top_so'] = $by_tl( $so_f, true, 5 );
		}
		if ( ! empty( $out['all_xa'] ) ) {
			$xa_f = array_values( array_filter( $out['all_xa'], $big_enough ) );
			$out['top_xa'] = $by_tl( $xa_f, true, 5 );
		}
		$zso = array(); $zxa = array();
		if ( ! empty( $out['all_so'] ) ) { foreach ( $out['all_so'] as $x ) { if ( $x['tl'] <= 0.001 ) { $zso[] = $x['ten']; } } }
		if ( ! empty( $out['all_xa'] ) ) { foreach ( $out['all_xa'] as $x ) { if ( $x['tl'] <= 0.001 ) { $zxa[] = $x['ten']; } } }
		if ( $zso || $zxa ) {
			$out['zero_list_so'] = $zso; $out['zero_list_xa'] = $zxa;
			$out['zero'] = array( 'tong' => count( $zso ) + count( $zxa ), 'so' => count( $zso ), 'xa' => count( $zxa ) );
		}

		// thống kê kế hoạch tuần
		if ( $tuan ) {
			$ky = '';
			if ( preg_match( '#[Tt]uần\s*([0-9]+)#u', $text, $m ) ) { $ky = 'Tuần ' . $m[1]; }
			$dk0 = array_values( array_unique( $dk0 ) );
			$out['tuan_thongke'] = array(
				'ky'       => $ky,
				'tot'      => array( 'count' => $tuan[0], 'list' => array() ),
				'phan'     => array( 'count' => $tuan[1], 'list' => array() ),
				'khong_dk' => array( 'count' => $tuan[3], 'list' => array() ),
				'dk_0'     => array( 'count' => max( $tuan[2], count( $dk0 ) ), 'list' => $dk0 ),
			);
		}

		if ( preg_match( '#đến ngày\s*([0-9]{1,2}/[0-9]{1,2}/[0-9]{4})#u', $text, $md ) ) { $out['as_of'] = $md[1]; }
		unset( $out['_kd'], $out['_v26'] );
		return $out;
	}

	/* ---------------- Báo cáo thống kê theo 06 TỔ công tác ---------------- */
	public static function parse_6to( $path ) {
		$text   = self::docx( $path );
		$tables = self::docx_tables( $path );
		$out    = array( 'tos' => array() );
		if ( preg_match( '#đến ngày\\s*([0-9]{1,2}/[0-9]{1,2}/[0-9]{4})#u', $text, $md ) ) { $out['as_of'] = $md[1]; }
		if ( preg_match( '#Đối soát toàn tỉnh:\\s*([^\\n]+)#u', $text, $ds ) ) { $out['doi_soat'] = trim( $ds[1] ); }
		if ( preg_match( '#Ghi chú:\\s*([^\\n]+)#u', $text, $gc ) ) { $out['ghi_chu'] = trim( $gc[1] ); }

		// Bảng tổng hợp T0: Tổ | Phạm vi/Tổ trưởng | KH25 | KH26 | Tổng KH | GN | Tỷ lệ
		$sum = array(); $detail = array();
		foreach ( $tables as $tb ) {
			$h = isset( $tb[0] ) ? implode( '|', $tb[0] ) : '';
			if ( false !== mb_stripos( $h, 'Phạm vi' ) ) { $sum = $tb; }
			elseif ( false !== mb_stripos( $h, 'Chủ đầu tư' ) && count( $tb[0] ) >= 7 ) { $detail[] = $tb; }
		}
		$summ = array();
		foreach ( $sum as $ri => $r ) {
			if ( 0 === $ri ) { continue; }
			$n = count( $r );
			if ( preg_match( '#Tổ\\s*(\\d+)#u', isset( $r[0] ) ? $r[0] : '', $mo ) ) {
				$pv = isset( $r[1] ) ? trim( $r[1] ) : '';
				$tt = '';
				if ( false !== mb_strpos( $pv, '—' ) ) { $parts = explode( '—', $pv ); $tt = trim( array_pop( $parts ) ); $pv = trim( implode( '—', $parts ) ); }
				$summ[ (int) $mo[1] ] = array(
					'pham_vi' => $pv, 'to_truong' => $tt,
					'kh25' => self::pnum( isset( $r[ $n - 5 ] ) ? $r[ $n - 5 ] : 0 ),
					'kh26' => self::pnum( isset( $r[ $n - 4 ] ) ? $r[ $n - 4 ] : 0 ),
					'kh'   => self::pnum( isset( $r[ $n - 3 ] ) ? $r[ $n - 3 ] : 0 ),
					'gn'   => self::pnum( isset( $r[ $n - 2 ] ) ? $r[ $n - 2 ] : 0 ),
					'tl'   => self::ppct( isset( $r[ $n - 1 ] ) ? $r[ $n - 1 ] : '' ),
				);
			} elseif ( false !== mb_stripos( implode( ' ', $r ), 'CỘNG' ) ) {
				$out['tong'] = array(
					'kh25' => self::pnum( isset( $r[ $n - 5 ] ) ? $r[ $n - 5 ] : 0 ),
					'kh26' => self::pnum( isset( $r[ $n - 4 ] ) ? $r[ $n - 4 ] : 0 ),
					'kh'   => self::pnum( isset( $r[ $n - 3 ] ) ? $r[ $n - 3 ] : 0 ),
					'gn'   => self::pnum( isset( $r[ $n - 2 ] ) ? $r[ $n - 2 ] : 0 ),
					'tl'   => self::ppct( isset( $r[ $n - 1 ] ) ? $r[ $n - 1 ] : '' ),
				);
			}
		}

		// Mô tả + số dự án/CĐT từ văn bản
		$meta = array();
		if ( preg_match_all( '#TỔ\\s*(\\d+)\\s*:\\s*([^\\n]+)\\n\\s*Tổ trưởng:\\s*([^\\n]+)\\n\\s*Kết quả:\\s*([^\\n]+)#u', $text, $mm, PREG_SET_ORDER ) ) {
			foreach ( $mm as $m ) {
				$kq = $m[4]; $gn = $kh = 0; $tl = 0; $cdt = 0; $da = 0;
				if ( preg_match( '#giải ngân\\s*([\\d.]+)\\s*/\\s*([\\d.]+)#u', $kq, $g ) ) { $gn = self::pnum( $g[1] ); $kh = self::pnum( $g[2] ); }
				if ( preg_match( '#đạt\\s*([\\d,]+)\\s*%#u', $kq, $t ) ) { $tl = (float) str_replace( ',', '.', $t[1] ); }
				if ( preg_match( '#\\((\\d+)\\s*dự án#u', $kq, $d2 ) ) { $da = (int) $d2[1]; }
				if ( preg_match( '#(\\d+)\\s*chủ đầu tư#u', $kq, $c ) ) { $cdt = (int) $c[1]; }
				$meta[ (int) $m[1] ] = array( 'pham_vi' => trim( $m[2] ), 'to_truong' => trim( $m[3] ), 'gn' => $gn, 'kh' => $kh, 'tl' => $tl, 'da' => $da, 'cdt' => $cdt );
			}
		}

		$n = count( $detail );
		for ( $i = 0; $i < $n; $i++ ) {
			$stt = $i + 1;
			$rows = array();
			$cols = count( $detail[ $i ][0] );
			foreach ( $detail[ $i ] as $ri => $r ) {
				if ( 0 === $ri ) { continue; }
				$name = isset( $r[1] ) ? trim( $r[1] ) : '';
				if ( '' === $name ) { continue; }
				$low = mb_strtolower( $name );
				if ( 0 === mb_strpos( $low, 'cộng' ) || 0 === mb_strpos( $low, 'tổng' ) || preg_match( '#^[\\d.,\\s]+$#u', $name ) ) { continue; }
				$nc = count( $r );
				$rows[] = array(
					'ten' => $name,
					'da'  => ( $cols >= 8 && isset( $r[2] ) ) ? (int) self::pnum( $r[2] ) : 0,
					'kh'  => self::pnum( isset( $r[ $nc - 3 ] ) ? $r[ $nc - 3 ] : 0 ),
					'gn'  => self::pnum( isset( $r[ $nc - 2 ] ) ? $r[ $nc - 2 ] : 0 ),
					'tl'  => self::ppct( isset( $r[ $nc - 1 ] ) ? $r[ $nc - 1 ] : '' ),
				);
			}
			$mt = isset( $meta[ $stt ] ) ? $meta[ $stt ] : array();
			$sm = isset( $summ[ $stt ] ) ? $summ[ $stt ] : array();
			$pick = function ( $k, $d = 0 ) use ( $mt, $sm ) { if ( isset( $sm[ $k ] ) && $sm[ $k ] ) { return $sm[ $k ]; } return isset( $mt[ $k ] ) ? $mt[ $k ] : $d; };
			$out['tos'][] = array(
				'stt'       => $stt,
				'ten'       => 'Tổ ' . $stt,
				'pham_vi'   => $pick( 'pham_vi', '' ),
				'to_truong' => $pick( 'to_truong', '' ),
				'kh25'      => isset( $sm['kh25'] ) ? $sm['kh25'] : 0,
				'kh26'      => isset( $sm['kh26'] ) ? $sm['kh26'] : 0,
				'kh'        => $pick( 'kh' ),
				'gn'        => $pick( 'gn' ),
				'tl'        => $pick( 'tl' ),
				'da'        => isset( $mt['da'] ) ? $mt['da'] : 0,
				'cdt'       => isset( $mt['cdt'] ) ? $mt['cdt'] : count( $rows ),
				'count'     => isset( $mt['cdt'] ) ? $mt['cdt'] : count( $rows ),
				'rows'      => $rows,
			);
		}
		return $out;
	}
}
