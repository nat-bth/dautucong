<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class LaDo_AI_Ajax {

	public function __construct() {
		add_action( 'wp_ajax_lado_chat', array( $this, 'chat' ) );
		add_action( 'wp_ajax_nopriv_lado_chat', array( $this, 'chat' ) );
		add_action( 'wp_ajax_lado_report', array( $this, 'report' ) );
		add_action( 'wp_ajax_nopriv_lado_report', array( $this, 'report' ) );
	}

	protected function verify() {
		check_ajax_referer( 'lado_ai_front', 'nonce' );
	}

	protected function rate_ok() {
		$limit = (int) lado_ai_get( 'rate_limit', 20 );
		$ip    = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : 'x';
		$key   = 'lado_rl_' . md5( $ip );
		$n     = (int) get_transient( $key );
		if ( $n >= $limit ) { return false; }
		set_transient( $key, $n + 1, 10 * MINUTE_IN_SECONDS );
		return true;
	}

	public function chat() {
		$this->verify();
		if ( ! $this->rate_ok() ) {
			wp_send_json_error( array( 'message' => 'Bạn đã gửi quá nhiều câu hỏi trong thời gian ngắn. Vui lòng thử lại sau ít phút.' ), 429 );
		}
		$raw = isset( $_POST['history'] ) ? wp_unslash( $_POST['history'] ) : '[]';
		$history = json_decode( $raw, true );
		if ( ! is_array( $history ) ) {
			wp_send_json_error( array( 'message' => 'Dữ liệu không hợp lệ.' ) );
		}
		// keep last 12 turns
		if ( count( $history ) > 12 ) { $history = array_slice( $history, -12 ); }

		$res = LaDo_AI_Claude::ask( $history );
		if ( ! empty( $res['ok'] ) ) {
			wp_send_json_success( array( 'reply' => $res['text'] ) );
		}
		wp_send_json_error( array( 'message' => $res['error'] ) );
	}

	public function report() {
		$this->verify();
		$type = isset( $_POST['type'] ) ? sanitize_key( $_POST['type'] ) : 'week';
		$id   = ( 'month' === $type ) ? (int) lado_ai_get( 'report_month' ) : (int) lado_ai_get( 'report_week' );
		if ( ! $id ) {
			wp_send_json_error( array( 'message' => 'Quản trị viên chưa đính kèm file báo cáo ' . ( 'month' === $type ? 'tháng' : 'tuần' ) . '.' ) );
		}
		$url = wp_get_attachment_url( $id );
		if ( ! $url ) {
			wp_send_json_error( array( 'message' => 'Không tìm thấy file báo cáo.' ) );
		}
		wp_send_json_success( array(
			'url'   => $url,
			'name'  => basename( get_attached_file( $id ) ),
		) );
	}
}
