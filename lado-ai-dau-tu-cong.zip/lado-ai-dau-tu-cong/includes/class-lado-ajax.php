<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class LaDo_AI_Ajax {

	public function __construct() {
		add_action( 'wp_ajax_lado_chat', array( $this, 'chat' ) );
		add_action( 'wp_ajax_nopriv_lado_chat', array( $this, 'chat' ) );
		add_action( 'wp_ajax_lado_report', array( $this, 'report' ) );
		add_action( 'wp_ajax_nopriv_lado_report', array( $this, 'report' ) );
		add_action( 'wp_ajax_lado_kiennghi', array( $this, 'kiennghi' ) );
		add_action( 'wp_ajax_nopriv_lado_kiennghi', array( $this, 'kiennghi' ) );
		add_action( 'wp_ajax_lado_donvi', array( $this, 'donvi' ) );
		add_action( 'wp_ajax_nopriv_lado_donvi', array( $this, 'donvi' ) );
	}

	protected function verify() {
		check_ajax_referer( 'lado_ai_front', 'nonce' );
	}

	protected function rate_ok() {
		$limit = (int) lado_ai_get( 'rate_limit', 20 );
		$ip    = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : 'x';
		$key   = 'lado_rl_' . md5( $ip );
		$n     = (int) get_transient( $key );
		if ( $n >= $limit ) { return false; }
		set_transient( $key, $n + 1, 10 * MINUTE_IN_SECONDS );
		return true;
	}

	public function chat() {
		$this->verify();
		if ( ! $this->rate_ok() ) {
			wp_send_json_error( array( 'message' => 'Bạn đã gửi quá nhiều câu hỏi trong thời gian ngắn. Vui lòng thử lại sau ít phút.' ), 429 );
		}
		$raw = isset( $_POST['history'] ) ? wp_unslash( $_POST['history'] ) : '[]';
		$history = json_decode( $raw, true );
		if ( ! is_array( $history ) ) {
			wp_send_json_error( array( 'message' => 'Dữ liệu không hợp lệ.' ) );
		}
		// keep last 12 turns
		if ( count( $history ) > 12 ) { $history = array_slice( $history, -12 ); }

		$res = LaDo_AI_Claude::ask( $history );
		if ( ! empty( $res['ok'] ) ) {
			wp_send_json_success( array( 'reply' => $res['text'] ) );
		}
		wp_send_json_error( array( 'message' => $res['error'] ) );
	}

	public function kiennghi() {
		$this->verify();
		$kn = lado_ai_get_kiennghi();
		wp_send_json_success( array(
			'updated' => isset( $kn['updated'] ) ? $kn['updated'] : '',
			'total'   => isset( $kn['total'] ) ? (int) $kn['total'] : 0,
			'items'   => isset( $kn['items'] ) ? $kn['items'] : array(),
		) );
	}

	public function donvi() {
		$this->verify();
		$dv = lado_ai_get_donvi();
		wp_send_json_success( array(
			'updated'  => isset( $dv['updated'] ) ? $dv['updated'] : '',
			'units'    => isset( $dv['units'] ) ? $dv['units'] : (object) array(),
			'contacts' => isset( $dv['contacts'] ) ? $dv['contacts'] : (object) array(),
			'big_zero' => isset( $dv['big_zero'] ) ? $dv['big_zero'] : array(),
			'big_zero_kb' => isset( $dv['big_zero_kb'] ) ? $dv['big_zero_kb'] : array(),
			'phuluc'   => isset( $dv['phuluc'] ) ? $dv['phuluc'] : null,
		) );
	}

	public function report() {
		$this->verify();
		$type = isset( $_POST['type'] ) ? sanitize_key( $_POST['type'] ) : 'week';

		if ( 'week_idx' === $type ) {
			$idx   = isset( $_POST['idx'] ) ? (int) $_POST['idx'] : -1;
			$weeks = (array) lado_ai_get( 'weeks', array() );
			if ( ! isset( $weeks[ $idx ] ) || empty( $weeks[ $idx ]['file'] ) ) {
				wp_send_json_error( array( 'message' => 'Tuần này chưa được đính kèm file báo cáo.' ) );
			}
			$id = (int) $weeks[ $idx ]['file'];
		} elseif ( 'day_idx' === $type ) {
			$idx  = isset( $_POST['idx'] ) ? (int) $_POST['idx'] : -1;
			$days = (array) lado_ai_get( 'days', array() );
			if ( ! isset( $days[ $idx ] ) || empty( $days[ $idx ]['att'] ) ) {
				wp_send_json_error( array( 'message' => 'Ngày này chưa được đính kèm file báo cáo.' ) );
			}
			$id = (int) $days[ $idx ]['att'];
		} elseif ( 'day' === $type ) {
			$id = (int) lado_ai_get( 'report_day' );
			if ( ! $id ) {
				wp_send_json_error( array( 'message' => 'Quản trị viên chưa nhập báo cáo ngày.' ) );
			}
		} else {
			$id = ( 'month' === $type ) ? (int) lado_ai_get( 'report_month' ) : (int) lado_ai_get( 'report_week' );
			if ( ! $id ) {
				wp_send_json_error( array( 'message' => 'Quản trị viên chưa đính kèm file báo cáo ' . ( 'month' === $type ? 'tháng' : 'tuần' ) . '.' ) );
			}
		}

		$url = wp_get_attachment_url( $id );
		if ( ! $url ) {
			wp_send_json_error( array( 'message' => 'Không tìm thấy file báo cáo.' ) );
		}
		wp_send_json_success( array(
			'url'  => $url,
			'name' => basename( get_attached_file( $id ) ),
		) );
	}
}
