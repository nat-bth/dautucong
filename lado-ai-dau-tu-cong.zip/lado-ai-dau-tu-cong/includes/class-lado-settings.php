<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class LaDo_AI_Settings {

	public function __construct() {
		add_action( 'admin_menu', array( $this, 'menu' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'assets' ) );
		add_action( 'admin_post_lado_ai_save', array( $this, 'save' ) );
	}

	public function menu() {
		add_menu_page(
			'LaDo-AI', 'LaDo-AI', 'manage_options', 'lado-ai',
			array( $this, 'render' ), 'dashicons-chart-area', 58
		);
	}

	public function assets( $hook ) {
		if ( 'toplevel_page_lado-ai' !== $hook ) { return; }
		wp_enqueue_media();
		$acss = LADO_AI_DIR . 'assets/css/lado-admin.css';
		$ajs  = LADO_AI_DIR . 'assets/js/lado-admin.js';
		wp_enqueue_style( 'lado-admin', LADO_AI_URL . 'assets/css/lado-admin.css', array(), file_exists( $acss ) ? (string) filemtime( $acss ) : LADO_AI_VERSION );
		wp_enqueue_script( 'lado-admin', LADO_AI_URL . 'assets/js/lado-admin.js', array( 'jquery' ), file_exists( $ajs ) ? (string) filemtime( $ajs ) : LADO_AI_VERSION, true );
	}

	public function save() {
		if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'Không đủ quyền.' ); }
		check_admin_referer( 'lado_ai_save' );

		$o = get_option( LADO_AI_OPT, lado_ai_default_settings() );

		$o['api_key']        = isset( $_POST['api_key'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['api_key'] ) ) ) : '';
		$o['model']          = isset( $_POST['model'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['model'] ) ) ) : 'claude-opus-4-8';
		$o['ai_provider']    = ( isset( $_POST['ai_provider'] ) && 'deepseek' === $_POST['ai_provider'] ) ? 'deepseek' : 'anthropic';
		$o['deepseek_key']   = isset( $_POST['deepseek_key'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['deepseek_key'] ) ) ) : '';
		$o['deepseek_model'] = isset( $_POST['deepseek_model'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['deepseek_model'] ) ) ) : 'deepseek-chat';
		$o['max_tokens']     = isset( $_POST['max_tokens'] ) ? max( 256, min( 1000000, (int) $_POST['max_tokens'] ) ) : 1200;
		$o['temperature']    = isset( $_POST['temperature'] ) ? (string) floatval( $_POST['temperature'] ) : '0.2';
		$o['assistant_name'] = isset( $_POST['assistant_name'] ) ? sanitize_text_field( wp_unslash( $_POST['assistant_name'] ) ) : 'LaDo-AI';
		$o['avatar']         = isset( $_POST['avatar'] ) ? (int) $_POST['avatar'] : 0;
		$o['persona']        = isset( $_POST['persona'] ) ? sanitize_textarea_field( wp_unslash( $_POST['persona'] ) ) : '';
		$o['rate_limit']     = isset( $_POST['rate_limit'] ) ? max( 1, (int) $_POST['rate_limit'] ) : 20;
		$o['report_week']    = isset( $_POST['report_week'] ) ? (int) $_POST['report_week'] : 0;
		$o['report_month']   = isset( $_POST['report_month'] ) ? (int) $_POST['report_month'] : 0;

		// Báo cáo theo tuần (danh sách): {ky, tl, file}
		if ( isset( $_POST['weeks_json'] ) ) {
			$rows = json_decode( wp_unslash( $_POST['weeks_json'] ), true );
			$weeks = array();
			if ( is_array( $rows ) ) {
				foreach ( $rows as $r ) {
					$ky = isset( $r['ky'] ) ? sanitize_text_field( $r['ky'] ) : '';
					if ( '' === trim( $ky ) ) { continue; }
					$weeks[] = array(
						'ky'   => $ky,
						'tl'   => isset( $r['tl'] ) ? (float) $r['tl'] : 0,
						'file' => isset( $r['file'] ) ? (int) $r['file'] : 0,
					);
				}
			}
			$o['weeks'] = $weeks;
		}

		// Convert báo cáo Word -> số liệu biểu đồ
		if ( ! empty( $_FILES['data_docx']['name'] ) && empty( $_FILES['data_docx']['error'] ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
			$moved = wp_handle_upload( $_FILES['data_docx'], array( 'test_form' => false, 'mimes' => array( 'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' ) ) );
			if ( isset( $moved['file'] ) ) {
				$parsed = LaDo_AI_Data::parse_report( $moved['file'] );
				@unlink( $moved['file'] );
				if ( $parsed && ( isset( $parsed['tong'] ) || isset( $parsed['khoi'] ) ) ) {
					$cur = json_decode( $o['data'], true );
					if ( ! is_array( $cur ) ) { $cur = array(); }
					$o['data'] = wp_json_encode( array_merge( $cur, $parsed ), JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT );
					$notice = 'imported';
				} else {
					$notice = 'importfail';
				}
			}
		}

		// Convert báo cáo TUẦN -> thống kê kế hoạch tuần
		if ( ! isset( $notice ) && ! empty( $_FILES['tuan_docx']['name'] ) && empty( $_FILES['tuan_docx']['error'] ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
			$moved = wp_handle_upload( $_FILES['tuan_docx'], array( 'test_form' => false, 'mimes' => array( 'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' ) ) );
			if ( isset( $moved['file'] ) ) {
				$tt = LaDo_AI_Data::parse_weekly( $moved['file'] );
				@unlink( $moved['file'] );
				if ( $tt && ( ! empty( $tt['tot']['count'] ) || ! empty( $tt['khong_dk']['count'] ) || ! empty( $tt['dk_0']['count'] ) || ! empty( $tt['phan']['count'] ) ) ) {
					$cur = json_decode( $o['data'], true );
					if ( ! is_array( $cur ) ) { $cur = array(); }
					$cur['tuan_thongke'] = $tt;
					$o['data'] = wp_json_encode( $cur, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT );
					$notice = 'imported_week';
				} else {
					$notice = 'importfail';
				}
			}
		}

		// Convert Excel "Danh mục kế hoạch theo tuần" -> kiến nghị, đề xuất
		if ( ! isset( $notice ) && ! empty( $_FILES['kiennghi_xlsx']['name'] ) && empty( $_FILES['kiennghi_xlsx']['error'] ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
			$moved = wp_handle_upload( $_FILES['kiennghi_xlsx'], array( 'test_form' => false, 'mimes' => array( 'xlsx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' ) ) );
			if ( isset( $moved['file'] ) ) {
				$kn = LaDo_AI_Excel::parse_proposals( $moved['file'] );
				$units = LaDo_AI_Directory::parse_units( $moved['file'] );
				@unlink( $moved['file'] );
				if ( is_array( $units ) && ! empty( $units ) ) {
					$dv = lado_ai_get_donvi();
					if ( ! isset( $dv['units'] ) || ! is_array( $dv['units'] ) ) { $dv['units'] = array(); }
					foreach ( $units as $key => $u ) {
						$ex = isset( $dv['units'][ $key ] ) ? $dv['units'][ $key ] : array();
						$ex['ten']      = $u['ten'];
						$ex['khoi']     = $u['khoi'];
						$ex['projects'] = $u['projects'];
						$dv['units'][ $key ] = $ex;
					}
					$dv['updated'] = date_i18n( 'd/m/Y H:i' );

					// Bảng "dự án vốn lớn nhưng giải ngân 0%" + khó khăn (ghép từ kiến nghị)
					$kho = array();
					if ( $kn && ! empty( $kn['items'] ) ) {
						foreach ( $kn['items'] as $it ) {
							$nk = LaDo_AI_Directory::nrm( isset( $it['du_an'] ) ? $it['du_an'] : '' );
							if ( '' !== $nk && ! isset( $kho[ $nk ] ) ) {
								$kho[ $nk ] = array(
									'kho_khan'   => isset( $it['kho_khan'] ) ? $it['kho_khan'] : '',
									'nhom'       => isset( $it['nhom'] ) ? $it['nhom'] : '',
									'tham_quyen' => isset( $it['tham_quyen'] ) ? $it['tham_quyen'] : '',
									'kien_nghi'  => isset( $it['kien_nghi'] ) ? $it['kien_nghi'] : '',
									'thoi_gian'  => isset( $it['thoi_gian'] ) ? $it['thoi_gian'] : '',
								);
							}
						}
					}
					$bz = array();
					foreach ( $units as $u ) {
						if ( empty( $u['projects'] ) ) { continue; }
						foreach ( $u['projects'] as $p ) {
							$tlp = isset( $p['tl'] ) ? (float) str_replace( array( '%', ',' ), array( '', '.' ), (string) $p['tl'] ) : 0;
							$gnp = isset( $p['gn'] ) ? (float) $p['gn'] : 0;
							$khp = isset( $p['kh'] ) ? (float) $p['kh'] : 0;
							if ( $khp <= 0 || $gnp > 0 || $tlp > 0.001 ) { continue; }
						$tenl = mb_strtolower( trim( (string) $p['ten'] ) );
						if ( '' === $tenl || false !== mb_strpos( $tenl, 'thông báo sau' ) || false !== mb_strpos( $tenl, 'chi đầu tư khác' ) || false !== mb_strpos( $tenl, 'ngân hàng chính sách' ) ) { continue; }
							$nk  = LaDo_AI_Directory::nrm( $p['ten'] );
							$row = array( 'cdt' => $u['ten'], 'khoi' => $u['khoi'], 'ten' => $p['ten'], 'kh' => $khp );
							if ( isset( $kho[ $nk ] ) ) { $row = array_merge( $row, $kho[ $nk ] ); }
							$bz[] = $row;
						}
					}
					usort( $bz, function ( $a, $b ) { return ( $b['kh'] <=> $a['kh'] ); } );
					$dv['big_zero'] = $bz;
					$dv['ban_qlda'] = LaDo_AI_Directory::parse_ban_qlda( $moved['file'] );
					$dv['weekly_status'] = LaDo_AI_Directory::parse_weekly_status( $moved['file'] );
					$dv['dk_traj'] = LaDo_AI_Directory::parse_dk_trajectory( $moved['file'] );

					update_option( LADO_AI_DONVI_OPT, $dv, false );
				}
				if ( $kn && ! empty( $kn['items'] ) ) {
					update_option( LADO_AI_KN_OPT, $kn, false );
					$notice = 'imported_kn';
				} else {
					$notice = 'importfail_kn';
				}
			}
		}

		// ===== Mục RIÊNG: cập nhật DANH MỤC DỰ ÁN theo chủ đầu tư (chỉ đọc dự án) =====
		if ( ! isset( $notice ) && ! empty( $_FILES['duan_xlsx']['name'] ) && empty( $_FILES['duan_xlsx']['error'] ) ) {
			$f   = $_FILES['duan_xlsx'];
			$ext = strtolower( pathinfo( $f['name'], PATHINFO_EXTENSION ) );
			// Đọc trực tiếp file tạm (chỉ mở dạng zip để trích dữ liệu) — tránh bị chặn theo MIME
			if ( 'xlsx' === $ext && is_uploaded_file( $f['tmp_name'] ) ) {
				$units = LaDo_AI_Directory::parse_units( $f['tmp_name'] );
				if ( is_array( $units ) && ! empty( $units ) ) {
					$dv = lado_ai_get_donvi();
					if ( ! isset( $dv['units'] ) || ! is_array( $dv['units'] ) ) { $dv['units'] = array(); }
					$nproj = 0;
					foreach ( $units as $key => $u ) {
						$ex = isset( $dv['units'][ $key ] ) ? $dv['units'][ $key ] : array(); // giữ nguyên liên hệ nếu đã có
						$ex['ten']      = $u['ten'];
						$ex['khoi']     = $u['khoi'];
						$ex['projects'] = $u['projects'];
						$dv['units'][ $key ] = $ex;
						$nproj += count( $u['projects'] );
					}
					// Cập nhật lại bảng "dự án vốn lớn 0%" (ghép khó khăn từ kiến nghị đã lưu nếu có)
					$kn  = lado_ai_get_kiennghi();
					$kho = array();
					if ( $kn && ! empty( $kn['items'] ) ) {
						foreach ( $kn['items'] as $it ) {
							$nk = LaDo_AI_Directory::nrm( isset( $it['du_an'] ) ? $it['du_an'] : '' );
							if ( '' !== $nk && ! isset( $kho[ $nk ] ) ) {
								$kho[ $nk ] = array(
									'kho_khan'   => isset( $it['kho_khan'] ) ? $it['kho_khan'] : '',
									'nhom'       => isset( $it['nhom'] ) ? $it['nhom'] : '',
									'tham_quyen' => isset( $it['tham_quyen'] ) ? $it['tham_quyen'] : '',
									'kien_nghi'  => isset( $it['kien_nghi'] ) ? $it['kien_nghi'] : '',
									'thoi_gian'  => isset( $it['thoi_gian'] ) ? $it['thoi_gian'] : '',
								);
							}
						}
					}
					$bz = array();
					foreach ( $units as $u ) {
						foreach ( $u['projects'] as $p ) {
							$tlp = (float) str_replace( array( '%', ',' ), array( '', '.' ), (string) ( $p['tl'] ?? '' ) );
							$gnp = (float) ( $p['gn'] ?? 0 ); $khp = (float) ( $p['kh'] ?? 0 );
							if ( $khp <= 0 || $gnp > 0 || $tlp > 0.001 ) { continue; }
						$tenl = mb_strtolower( trim( (string) $p['ten'] ) );
						if ( '' === $tenl || false !== mb_strpos( $tenl, 'thông báo sau' ) || false !== mb_strpos( $tenl, 'chi đầu tư khác' ) || false !== mb_strpos( $tenl, 'ngân hàng chính sách' ) ) { continue; }
							$nk  = LaDo_AI_Directory::nrm( $p['ten'] );
							$row = array( 'cdt' => $u['ten'], 'khoi' => $u['khoi'], 'ten' => $p['ten'], 'kh' => $khp );
							if ( isset( $kho[ $nk ] ) ) { $row = array_merge( $row, $kho[ $nk ] ); }
							$bz[] = $row;
						}
					}
					usort( $bz, function ( $a, $b ) { return ( $b['kh'] <=> $a['kh'] ); } );
					$dv['big_zero'] = $bz;
					$dv['ban_qlda'] = LaDo_AI_Directory::parse_ban_qlda( $f['tmp_name'] );
					$dv['weekly_status'] = LaDo_AI_Directory::parse_weekly_status( $f['tmp_name'] );
					$dv['dk_traj'] = LaDo_AI_Directory::parse_dk_trajectory( $f['tmp_name'] );
					$dv['updated']  = date_i18n( 'd/m/Y H:i' );
					$dv['stats']    = array( 'units' => count( $units ), 'projects' => $nproj );
					update_option( LADO_AI_DONVI_OPT, $dv, false );
					$notice = 'imported_duan';
				} else {
					$notice = 'importfail_duan';
				}
			}
		}

		// Convert báo cáo NGÀY -> cập nhật toàn bộ số liệu + điểm biểu đồ ngày + lưu file tải
		if ( ! isset( $notice ) && ! empty( $_FILES['daily_docx']['name'] ) && empty( $_FILES['daily_docx']['error'] ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
			require_once ABSPATH . 'wp-admin/includes/media.php';
			require_once ABSPATH . 'wp-admin/includes/image.php';
			$att = media_handle_upload( 'daily_docx', 0 );
			if ( ! is_wp_error( $att ) ) {
				$fpath = get_attached_file( $att );
				$dd = $fpath ? LaDo_AI_Data::parse_daily( $fpath ) : null;
				if ( $dd && ! empty( $dd['tong'] ) ) {
					$cur = json_decode( $o['data'], true );
					if ( ! is_array( $cur ) ) { $cur = array(); }
					$o['data'] = wp_json_encode( array_merge( $cur, $dd ), JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT );
					$date = isset( $dd['as_of'] ) ? $dd['as_of'] : date_i18n( 'd/m/Y' );
					$tl   = isset( $dd['tong']['tl'] ) ? (float) $dd['tong']['tl'] : 0;
					$days = ( isset( $o['days'] ) && is_array( $o['days'] ) ) ? $o['days'] : array();
					$nrmd = function ( $s ) { $p = array_map( 'intval', explode( '/', (string) $s ) ); return implode( '/', $p ); };
					$days = array_values( array_filter( $days, function ( $x ) use ( $date, $nrmd ) { return $nrmd( isset( $x['date'] ) ? $x['date'] : '' ) !== $nrmd( $date ); } ) );
					$ttg = 0;
					$gn26 = 0;
					// Lấy từ bảng "Mức kế hoạch giao" dòng Thủ tướng: tỷ lệ VÀ số giải ngân CÙNG mẫu số (KH Thủ tướng giao)
					if ( ! empty( $dd['kehoach_giao'] ) ) {
						foreach ( $dd['kehoach_giao'] as $g ) {
							if ( preg_match( '/Thủ tướng/u', isset( $g['ten'] ) ? $g['ten'] : '' ) ) {
								$ttg  = (float) ( isset( $g['tl'] ) ? $g['tl'] : 0 );
								$gn26 = (float) ( isset( $g['gn'] ) ? $g['gn'] : 0 );
								break;
							}
						}
					}
					$gntt = isset( $dd['tong']['gn'] ) ? (float) $dd['tong']['gn'] : 0;
					// Dự phòng: nếu bảng giao không có cột giải ngân, lấy từ bảng nguồn vốn (Vốn năm 2026)
					if ( $gn26 <= 0 && ! empty( $dd['nguon'] ) && is_array( $dd['nguon'] ) ) {
						foreach ( $dd['nguon'] as $ng ) {
							$nt = isset( $ng['ten'] ) ? $ng['ten'] : '';
							if ( preg_match( '/2026/', $nt ) && ! preg_match( '/kéo dài/iu', $nt ) ) { $gn26 = (float) ( isset( $ng['gn'] ) ? $ng['gn'] : 0 ); break; }
						}
					}
					$days[] = array( 'date' => $date, 'tl' => $tl, 'ttg' => $ttg, 'gn' => $gntt, 'gn26' => $gn26, 'att' => (int) $att );
					if ( count( $days ) > 60 ) { $days = array_slice( $days, -60 ); }
					$o['days']       = $days;
					$o['report_day'] = (int) $att;
					$notice = 'imported_day';
				} else {
					wp_delete_attachment( $att, true );
					$notice = 'importfail';
				}
			}
		}

		// Danh bạ liên hệ (.docx) -> thông tin người đứng đầu/bí thư/chủ tịch theo đơn vị
		if ( ! isset( $notice ) && ! empty( $_FILES['danhba_docx']['name'] ) && empty( $_FILES['danhba_docx']['error'] ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
			$moved = wp_handle_upload( $_FILES['danhba_docx'], array( 'test_form' => false, 'mimes' => array( 'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' ) ) );
			if ( isset( $moved['file'] ) ) {
				$contacts = LaDo_AI_Directory::parse_contacts( $moved['file'] );
				@unlink( $moved['file'] );
				if ( is_array( $contacts ) && ! empty( $contacts ) ) {
					$dv = lado_ai_get_donvi();
					if ( ! isset( $dv['units'] ) || ! is_array( $dv['units'] ) ) { $dv['units'] = array(); }
					foreach ( $contacts as $key => $c ) {
						$ex = isset( $dv['units'][ $key ] ) ? $dv['units'][ $key ] : array( 'ten' => $c['ten'], 'projects' => array() );
						if ( empty( $ex['ten'] ) ) { $ex['ten'] = $c['ten']; }
						$ex['contact'] = $c;
						$dv['units'][ $key ] = $ex;
					}
					$dv['contacts'] = $contacts; // bản đồ riêng để khớp độc lập phía giao diện
					$dv['updated'] = date_i18n( 'd/m/Y H:i' );
					update_option( LADO_AI_DONVI_OPT, $dv, false );
					$notice = 'imported_contacts';
				} else {
					$notice = 'importfail';
				}
			}
		}

		// Báo cáo thống kê 06 TỔ (lưu file để tải về theo ngày)
		if ( ! isset( $notice ) && ! empty( $_FILES['sixto_docx']['name'] ) && empty( $_FILES['sixto_docx']['error'] ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
			require_once ABSPATH . 'wp-admin/includes/media.php';
			require_once ABSPATH . 'wp-admin/includes/image.php';
			$att6 = media_handle_upload( 'sixto_docx', 0 );
			if ( ! is_wp_error( $att6 ) ) {
				$fp6 = get_attached_file( $att6 );
				$six = $fp6 ? LaDo_AI_Data::parse_6to( $fp6 ) : null;
				if ( is_array( $six ) && ! empty( $six['tos'] ) ) {
					$cur = json_decode( $o['data'], true );
					if ( ! is_array( $cur ) ) { $cur = array(); }
					$cur['sixto'] = $six;
					$o['data'] = wp_json_encode( $cur, JSON_UNESCAPED_UNICODE );
					$d6 = isset( $six['as_of'] ) ? $six['as_of'] : date_i18n( 'd/m/Y' );
					$nrmd = function ( $s ) { $p = array_map( 'intval', explode( '/', (string) $s ) ); return implode( '/', $p ); };
					$sf = ( isset( $o['sixto_files'] ) && is_array( $o['sixto_files'] ) ) ? $o['sixto_files'] : array();
					$sf = array_values( array_filter( $sf, function ( $x ) use ( $d6, $nrmd ) { return $nrmd( isset( $x['date'] ) ? $x['date'] : '' ) !== $nrmd( $d6 ); } ) );
					$sf[] = array( 'date' => $d6, 'att' => (int) $att6 );
					if ( count( $sf ) > 60 ) { $sf = array_slice( $sf, -60 ); }
					$o['sixto_files'] = $sf;
					$notice = 'imported_6to';
				} else {
					wp_delete_attachment( $att6, true );
					$notice = 'importfail';
				}
			}
		}

		// Phụ lục: kết quả giải ngân TỪNG DỰ ÁN theo chủ đầu tư (Kho bạc) — lưu file tải về theo ngày
		if ( ! isset( $notice ) && ! empty( $_FILES['phuluc_docx']['name'] ) && empty( $_FILES['phuluc_docx']['error'] ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
			require_once ABSPATH . 'wp-admin/includes/media.php';
			require_once ABSPATH . 'wp-admin/includes/image.php';
			$attp = media_handle_upload( 'phuluc_docx', 0 );
			if ( ! is_wp_error( $attp ) ) {
				$fpp = get_attached_file( $attp );
				$plc = $fpp ? LaDo_AI_Data::parse_phuluc( $fpp ) : null;
				if ( is_array( $plc ) ) { $plc = LaDo_AI_Data::repair_phuluc( $plc ); }
				if ( is_array( $plc ) && ! empty( $plc['units'] ) ) {
					$dv = lado_ai_get_donvi();
					$dv['phuluc'] = $plc;
					// Dự án 0% theo SỐ KHO BẠC (từ phụ lục) — nguồn chính cho mục "Các dự án chưa giải ngân (0%)"
					$kho = array();
					$knd = function_exists( 'lado_ai_get_kiennghi' ) ? lado_ai_get_kiennghi() : array();
					if ( isset( $knd['items'] ) && is_array( $knd['items'] ) ) {
						foreach ( $knd['items'] as $x ) {
							if ( ! empty( $x['du_an'] ) && ! empty( $x['kho_khan'] ) ) {
								$nk2 = LaDo_AI_Directory::nrm( $x['du_an'] );
								if ( ! isset( $kho[ $nk2 ] ) || mb_strlen( $x['kho_khan'] ) > mb_strlen( $kho[ $nk2 ]['kho_khan'] ) ) { $kho[ $nk2 ] = array( 'kho_khan' => $x['kho_khan'] ); }
							}
						}
					}
					$bzk = array();
					foreach ( $plc['units'] as $u ) {
						if ( empty( $u['projects'] ) ) { continue; }
						foreach ( $u['projects'] as $p ) {
							$khp = isset( $p['kh'] ) ? (float) $p['kh'] : 0;
							$gnp = isset( $p['gn'] ) ? (float) $p['gn'] : 0;
							if ( $khp <= 0 || $gnp > 0 ) { continue; }
							$tenl = mb_strtolower( trim( (string) $p['ten'] ) );
							if ( '' === $tenl || false !== mb_strpos( $tenl, 'thông báo sau' ) || false !== mb_strpos( $tenl, 'chi đầu tư khác' ) || false !== mb_strpos( $tenl, 'ngân hàng chính sách' ) ) { continue; }
							$row = array( 'cdt' => $u['ten'], 'khoi' => isset( $u['khoi'] ) ? $u['khoi'] : '', 'ten' => $p['ten'], 'kh' => $khp, 'ma' => isset( $p['ma'] ) ? $p['ma'] : '' );
							$nk = LaDo_AI_Directory::nrm( $p['ten'] );
							if ( isset( $kho[ $nk ] ) ) { $row = array_merge( $row, $kho[ $nk ] ); }
							$bzk[] = $row;
						}
					}
					usort( $bzk, function ( $a, $b ) { return ( $b['kh'] <=> $a['kh'] ); } );
					$dv['big_zero_kb'] = $bzk;
					$dv['big_zero_kb_asof'] = isset( $plc['as_of'] ) ? $plc['as_of'] : '';
					update_option( LADO_AI_DONVI_OPT, $dv );
					$dp = isset( $plc['as_of'] ) ? $plc['as_of'] : date_i18n( 'd/m/Y' );
					$nrmd = function ( $s ) { $p = array_map( 'intval', explode( '/', (string) $s ) ); return implode( '/', $p ); };
					$pf = ( isset( $o['phuluc_files'] ) && is_array( $o['phuluc_files'] ) ) ? $o['phuluc_files'] : array();
					$pf = array_values( array_filter( $pf, function ( $x ) use ( $dp, $nrmd ) { return $nrmd( isset( $x['date'] ) ? $x['date'] : '' ) !== $nrmd( $dp ); } ) );
					$pf[] = array( 'date' => $dp, 'att' => (int) $attp );
					if ( count( $pf ) > 60 ) { $pf = array_slice( $pf, -60 ); }
					$o['phuluc_files'] = $pf;
					$notice = 'imported_phuluc';
				} else {
					wp_delete_attachment( $attp, true );
					$notice = 'importfail';
				}
			}
		}

		// Báo cáo TỔ CÔNG TÁC (chọn được nhiều file cùng lúc, mỗi file 1 tổ)
		if ( ! isset( $notice ) && ! empty( $_FILES['tct_docx']['name'] ) && is_array( $_FILES['tct_docx']['name'] ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
			require_once ABSPATH . 'wp-admin/includes/media.php';
			require_once ABSPATH . 'wp-admin/includes/image.php';
			$nrmd = function ( $s ) { $p = array_map( 'intval', explode( '/', (string) $s ) ); return implode( '/', $p ); };
			$okc = 0;
			$cnt = count( $_FILES['tct_docx']['name'] );
			for ( $fi = 0; $fi < $cnt; $fi++ ) {
				if ( empty( $_FILES['tct_docx']['name'][ $fi ] ) || ! empty( $_FILES['tct_docx']['error'][ $fi ] ) ) { continue; }
				$_FILES['tct_one'] = array(
					'name'     => $_FILES['tct_docx']['name'][ $fi ],
					'type'     => $_FILES['tct_docx']['type'][ $fi ],
					'tmp_name' => $_FILES['tct_docx']['tmp_name'][ $fi ],
					'error'    => $_FILES['tct_docx']['error'][ $fi ],
					'size'     => $_FILES['tct_docx']['size'][ $fi ],
				);
				$attt = media_handle_upload( 'tct_one', 0 );
				if ( is_wp_error( $attt ) ) { continue; }
				$fpt = get_attached_file( $attt );
				$tc  = $fpt ? LaDo_AI_Data::parse_tct( $fpt ) : null;
				if ( is_array( $tc ) ) { $tc = LaDo_AI_Data::repair_tct( $tc ); }
				if ( is_array( $tc ) && ! empty( $tc['so'] ) && ! empty( $tc['nhom'] ) ) {
					$cur = json_decode( $o['data'], true );
					if ( ! is_array( $cur ) ) { $cur = array(); }
					if ( ! isset( $cur['tct'] ) || ! is_array( $cur['tct'] ) ) { $cur['tct'] = array( 'tos' => array() ); }
					if ( isset( $tc['as_of'] ) ) { $cur['tct']['as_of'] = $tc['as_of']; }
					$tos = isset( $cur['tct']['tos'] ) && is_array( $cur['tct']['tos'] ) ? $cur['tct']['tos'] : array();
					$tos = array_values( array_filter( $tos, function ( $x ) use ( $tc ) { return (int) ( isset( $x['so'] ) ? $x['so'] : 0 ) !== (int) $tc['so']; } ) );
					$tos[] = $tc;
					usort( $tos, function ( $a, $b ) { return ( isset( $a['so'] ) ? $a['so'] : 0 ) <=> ( isset( $b['so'] ) ? $b['so'] : 0 ); } );
					$cur['tct']['tos'] = $tos;
					$o['data'] = wp_json_encode( $cur, JSON_UNESCAPED_UNICODE );
					$dt = isset( $tc['as_of'] ) ? $tc['as_of'] : date_i18n( 'd/m/Y' );
					$tf = ( isset( $o['tct_files'] ) && is_array( $o['tct_files'] ) ) ? $o['tct_files'] : array();
					$tf = array_values( array_filter( $tf, function ( $x ) use ( $tc, $dt, $nrmd ) {
						return ! ( (int) ( isset( $x['to'] ) ? $x['to'] : 0 ) === (int) $tc['so'] && $nrmd( isset( $x['date'] ) ? $x['date'] : '' ) === $nrmd( $dt ) );
					} ) );
					$tf[] = array( 'to' => (int) $tc['so'], 'date' => $dt, 'att' => (int) $attt );
					if ( count( $tf ) > 90 ) { $tf = array_slice( $tf, -90 ); }
					$o['tct_files'] = $tf;
					$okc++;
				} else {
					wp_delete_attachment( $attt, true );
				}
			}
			unset( $_FILES['tct_one'] );
			$notice = $okc ? 'imported_tct' : 'importfail';
		}

		// Validate JSON data field (chỉ khi không nhập từ Word ở lần này)
		if ( ! isset( $notice ) && isset( $_POST['data'] ) ) {
			$raw = wp_unslash( $_POST['data'] );
			$decoded = json_decode( $raw, true );
			if ( null !== $decoded ) {
				$o['data'] = wp_json_encode( $decoded, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT );
				$notice = 'saved';
			} else {
				$notice = 'badjson';
			}
		}

		// Knowledge-base file upload (docx/xlsx/csv/txt, nhiều file) -> extract text
		if ( ! empty( $_FILES['kb_file']['name'] ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
			$allowed = array(
				'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
				'xlsx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
				'csv'  => 'text/csv',
				'txt'  => 'text/plain',
				'pdf'  => 'application/pdf',
			);
			$names = is_array( $_FILES['kb_file']['name'] ) ? $_FILES['kb_file']['name'] : array( $_FILES['kb_file']['name'] );
			$first = true;
			for ( $ki = 0; $ki < count( $names ); $ki++ ) {
				$one = is_array( $_FILES['kb_file']['name'] ) ? array(
					'name'     => $_FILES['kb_file']['name'][ $ki ],
					'type'     => $_FILES['kb_file']['type'][ $ki ],
					'tmp_name' => $_FILES['kb_file']['tmp_name'][ $ki ],
					'error'    => $_FILES['kb_file']['error'][ $ki ],
					'size'     => $_FILES['kb_file']['size'][ $ki ],
				) : $_FILES['kb_file'];
				if ( empty( $one['name'] ) || ! empty( $one['error'] ) ) { continue; }
				$_FILES['kb_one'] = $one;
				$moved = wp_handle_upload( $_FILES['kb_one'], array( 'test_form' => false, 'mimes' => $allowed ) );
				if ( ! isset( $moved['file'] ) ) { continue; }
				$text = LaDo_AI_Data::extract( $moved['file'] );
				$name = sanitize_file_name( $one['name'] );
				if ( $first && empty( $_POST['kb_append'] ) ) {
					$o['kb_text']  = '===== ' . $name . " =====\n" . $text;
					$o['kb_files'] = array();
				} else {
					$o['kb_text'] = trim( $o['kb_text'] . "\n\n===== " . $name . " =====\n" . $text );
				}
				if ( ! isset( $o['kb_files'] ) || ! is_array( $o['kb_files'] ) ) { $o['kb_files'] = array(); }
				$o['kb_files'][] = array( 'name' => $name, 'len' => mb_strlen( $text ) );
				@unlink( $moved['file'] );
				$first = false;
			}
			unset( $_FILES['kb_one'] );
		}
		if ( isset( $_POST['kb_clear'] ) ) { $o['kb_text'] = ''; $o['kb_files'] = array(); }

		// Xóa riêng từng file ngữ cảnh (theo chỉ số)
		if ( isset( $_POST['kb_delete'] ) && is_numeric( $_POST['kb_delete'] ) ) {
			$di    = (int) $_POST['kb_delete'];
			$files = ( isset( $o['kb_files'] ) && is_array( $o['kb_files'] ) ) ? array_values( $o['kb_files'] ) : array();
			if ( isset( $files[ $di ] ) ) {
				$del_name = isset( $files[ $di ]['name'] ) ? $files[ $di ]['name'] : '';
				$sections = array();
				if ( preg_match_all( '/=====\s*(.*?)\s*=====\r?\n(.*?)(?=\r?\n\r?\n=====\s|\z)/s', (string) $o['kb_text'], $ms, PREG_SET_ORDER ) ) {
					foreach ( $ms as $m ) { $sections[] = array( 'name' => trim( $m[1] ), 'text' => rtrim( $m[2] ) ); }
				}
				array_splice( $files, $di, 1 );
				if ( count( $sections ) === count( $files ) + 1 ) {
					array_splice( $sections, $di, 1 );
				} else {
					foreach ( $sections as $k => $s ) { if ( $s['name'] === $del_name ) { array_splice( $sections, $k, 1 ); break; } }
				}
				$parts = array();
				foreach ( $sections as $s ) { $parts[] = '===== ' . $s['name'] . ' =====' . "\n" . $s['text']; }
				$o['kb_text']  = implode( "\n\n", $parts );
				$o['kb_files'] = $files;
				$notice        = 'kb_deleted';
			}
		}

		// Xóa điểm biểu đồ ngày (file báo cáo ngày tải nhầm/trùng)
		if ( isset( $_POST['day_delete'] ) && is_numeric( $_POST['day_delete'] ) ) {
			$di   = (int) $_POST['day_delete'];
			$days = ( isset( $o['days'] ) && is_array( $o['days'] ) ) ? array_values( $o['days'] ) : array();
			if ( isset( $days[ $di ] ) ) {
				if ( ! empty( $days[ $di ]['att'] ) ) { wp_delete_attachment( (int) $days[ $di ]['att'], true ); }
				array_splice( $days, $di, 1 );
				$o['days'] = $days;
				$notice    = 'day_deleted';
			}
		}

		// Xóa file 6 tổ theo ngày
		if ( isset( $_POST['sixto_delete'] ) && is_numeric( $_POST['sixto_delete'] ) ) {
			$di = (int) $_POST['sixto_delete'];
			$sf = ( isset( $o['sixto_files'] ) && is_array( $o['sixto_files'] ) ) ? array_values( $o['sixto_files'] ) : array();
			if ( isset( $sf[ $di ] ) ) {
				if ( ! empty( $sf[ $di ]['att'] ) ) { wp_delete_attachment( (int) $sf[ $di ]['att'], true ); }
				array_splice( $sf, $di, 1 );
				$o['sixto_files'] = $sf;
				$notice = 'day_deleted';
			}
		}

		// Xóa file phụ lục theo ngày
		if ( isset( $_POST['phuluc_delete'] ) && is_numeric( $_POST['phuluc_delete'] ) ) {
			$di = (int) $_POST['phuluc_delete'];
			$pf = ( isset( $o['phuluc_files'] ) && is_array( $o['phuluc_files'] ) ) ? array_values( $o['phuluc_files'] ) : array();
			if ( isset( $pf[ $di ] ) ) {
				if ( ! empty( $pf[ $di ]['att'] ) ) { wp_delete_attachment( (int) $pf[ $di ]['att'], true ); }
				array_splice( $pf, $di, 1 );
				$o['phuluc_files'] = $pf;
				$notice = 'day_deleted';
			}
		}

		// Xóa file báo cáo Tổ công tác theo tổ/ngày
		if ( isset( $_POST['tct_delete'] ) && is_numeric( $_POST['tct_delete'] ) ) {
			$di = (int) $_POST['tct_delete'];
			$tf = ( isset( $o['tct_files'] ) && is_array( $o['tct_files'] ) ) ? array_values( $o['tct_files'] ) : array();
			if ( isset( $tf[ $di ] ) ) {
				if ( ! empty( $tf[ $di ]['att'] ) ) { wp_delete_attachment( (int) $tf[ $di ]['att'], true ); }
				array_splice( $tf, $di, 1 );
				$o['tct_files'] = $tf;
				$notice = 'day_deleted';
			}
		}

		update_option( LADO_AI_OPT, $o );
		$notice = isset( $notice ) ? $notice : 'saved';
		wp_safe_redirect( admin_url( 'admin.php?page=lado-ai&notice=' . $notice ) );
		exit;
	}

	public function render() {
		$o = get_option( LADO_AI_OPT, lado_ai_default_settings() );
		$notice = isset( $_GET['notice'] ) ? sanitize_text_field( wp_unslash( $_GET['notice'] ) ) : '';
		$week_url  = $o['report_week'] ? wp_get_attachment_url( $o['report_week'] ) : '';
		$month_url = $o['report_month'] ? wp_get_attachment_url( $o['report_month'] ) : '';
		?>
		<div class="wrap lado-admin">
			<h1>⚙️ LaDo-AI — Cấu hình</h1>
			<?php if ( 'saved' === $notice ) : ?>
				<div class="notice notice-success is-dismissible"><p>Đã lưu cấu hình.</p></div>
			<?php elseif ( 'imported' === $notice ) : ?>
				<div class="notice notice-success is-dismissible"><p>✅ Đã nhập số liệu biểu đồ từ báo cáo THÁNG và lưu lại.</p></div>
			<?php elseif ( 'imported_week' === $notice ) : ?>
				<div class="notice notice-success is-dismissible"><p>✅ Đã nhập thống kê kế hoạch tuần từ báo cáo TUẦN và lưu lại.</p></div>
			<?php elseif ( 'imported_day' === $notice ) : ?>
				<div class="notice notice-success is-dismissible"><p>✅ Đã nhập báo cáo NGÀY: cập nhật toàn bộ số liệu, thêm điểm biểu đồ theo ngày và lưu file để tải về.</p></div>
			<?php elseif ( 'imported_contacts' === $notice ) : ?>
				<div class="notice notice-success is-dismissible"><p>✅ Đã nhập danh bạ liên hệ theo đơn vị.</p></div>
			<?php elseif ( 'imported_6to' === $notice ) : ?>
				<div class="notice notice-success is-dismissible"><p>✅ Đã nhập báo cáo thống kê theo 06 TỔ công tác.</p></div>
			<?php elseif ( 'imported_phuluc' === $notice ) : ?>
				<div class="notice notice-success is-dismissible"><p>✅ Đã nhập phụ lục kết quả giải ngân từng dự án (Kho bạc) và lưu file tải về theo ngày.</p></div>
			<?php elseif ( 'imported_tct' === $notice ) : ?>
				<div class="notice notice-success is-dismissible"><p>✅ Đã nhập báo cáo Tổ công tác và lưu file tải về theo tổ/ngày.</p></div>
			<?php elseif ( 'kb_deleted' === $notice ) : ?>
				<div class="notice notice-success is-dismissible"><p>✅ Đã xóa file ngữ cảnh đã chọn.</p></div>
			<?php elseif ( 'imported_duan' === $notice ) : ?>
				<?php $dvs = lado_ai_get_donvi(); $st = isset( $dvs['stats'] ) ? $dvs['stats'] : array(); ?>
				<div class="notice notice-success is-dismissible"><p>✅ Đã cập nhật danh mục dự án theo chủ đầu tư: <strong><?php echo (int) ( $st['units'] ?? 0 ); ?></strong> chủ đầu tư / <strong><?php echo (int) ( $st['projects'] ?? 0 ); ?></strong> dự án.</p></div>
			<?php elseif ( 'importfail_duan' === $notice ) : ?>
				<div class="notice notice-error is-dismissible"><p>Không đọc được danh mục dự án. Hãy chắc chắn đây là file "Danh mục kế hoạch giải ngân theo tuần" (.xlsx).</p></div>
			<?php elseif ( 'imported_kn' === $notice ) : ?>
				<?php $knc = lado_ai_get_kiennghi(); ?>
				<div class="notice notice-success is-dismissible"><p>✅ Đã nhập <strong><?php echo (int) ( $knc['total'] ?? 0 ); ?></strong> kiến nghị, đề xuất từ file Excel.</p></div>
			<?php elseif ( 'importfail_kn' === $notice ) : ?>
				<div class="notice notice-error is-dismissible"><p>Không đọc được kiến nghị từ file Excel. Hãy kiểm tra file đúng mẫu "Danh mục kế hoạch giải ngân theo tuần".</p></div>
			<?php elseif ( 'importfail' === $notice ) : ?>
				<div class="notice notice-error is-dismissible"><p>⚠️ Không đọc được số liệu từ file vừa nhập. Hãy kiểm tra đã chọn <strong>đúng ô</strong> cho loại file: 📥 Báo cáo chính / 📆 Báo cáo NGÀY (cần dòng "TOÀN TỈNH") · 🧩 Thống kê 06 TỔ · 📎 Phụ lục từng dự án · 🧭 Báo cáo TỔ CÔNG TÁC. Nếu chỉ muốn nạp file làm <strong>ngữ cảnh cho Trợ lý AI</strong>, dùng ô "Dữ liệu ngữ cảnh" ở cuối trang (nhận mọi file Word/Excel).</p></div>
			<?php elseif ( 'badjson' === $notice ) : ?>
				<div class="notice notice-error is-dismissible"><p>Dữ liệu JSON không hợp lệ — các mục khác đã lưu, riêng phần số liệu biểu đồ chưa được cập nhật.</p></div>
			<?php endif; ?>

			<p class="lado-help">Chèn bảng điều khiển vào bất kỳ trang nào bằng shortcode: <code>[lado_ai_dashboard]</code></p>

			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" enctype="multipart/form-data">
				<input type="hidden" name="action" value="lado_ai_save" />
				<?php wp_nonce_field( 'lado_ai_save' ); ?>

				<div class="lado-card">
					<h2>1) Kết nối API trợ lý ảo</h2>
					<table class="form-table">
						<tr><th>Nhà cung cấp mô hình</th><td>
							<?php $prov = isset( $o['ai_provider'] ) ? $o['ai_provider'] : 'anthropic'; ?>
							<label style="margin-right:18px"><input type="radio" name="ai_provider" value="anthropic" <?php checked( $prov, 'anthropic' ); ?> /> Claude (Anthropic)</label>
							<label><input type="radio" name="ai_provider" value="deepseek" <?php checked( $prov, 'deepseek' ); ?> /> DeepSeek</label>
							<p class="description">Chọn nguồn mô hình cho trợ lý ảo LaDo-AI. Mỗi nguồn dùng API key &amp; tên mô hình riêng bên dưới.</p>
						</td></tr>
					</table>

					<h3 style="margin:6px 0 2px">🟣 Claude (Anthropic)</h3>
					<table class="form-table">
						<tr><th>API key Claude</th><td>
							<input type="password" name="api_key" value="<?php echo esc_attr( $o['api_key'] ); ?>" class="regular-text" autocomplete="off" placeholder="sk-ant-..." />
							<p class="description">Khóa lưu phía máy chủ, không hiển thị ra trình duyệt người dùng.</p>
						</td></tr>
						<tr><th>Mô hình Claude (nhập thủ công)</th><td>
							<input type="text" name="model" value="<?php echo esc_attr( $o['model'] ); ?>" class="regular-text" placeholder="claude-opus-4-8" />
							<p class="description">Ví dụ: <code>claude-opus-4-8</code>, <code>claude-sonnet-4-6</code>, <code>claude-haiku-4-5-20251001</code>…</p>
						</td></tr>
					</table>

					<h3 style="margin:10px 0 2px">🔵 DeepSeek</h3>
					<table class="form-table">
						<tr><th>API key DeepSeek</th><td>
							<input type="password" name="deepseek_key" value="<?php echo esc_attr( isset( $o['deepseek_key'] ) ? $o['deepseek_key'] : '' ); ?>" class="regular-text" autocomplete="off" placeholder="sk-..." />
							<p class="description">Lấy tại platform.deepseek.com. Khóa lưu phía máy chủ.</p>
						</td></tr>
						<tr><th>Mô hình DeepSeek (nhập thủ công)</th><td>
							<input type="text" name="deepseek_model" value="<?php echo esc_attr( isset( $o['deepseek_model'] ) ? $o['deepseek_model'] : 'deepseek-chat' ); ?>" class="regular-text" placeholder="deepseek-chat" />
							<p class="description">Ví dụ: <code>deepseek-chat</code>, <code>deepseek-reasoner</code>…</p>
						</td></tr>
					</table>

					<h3 style="margin:10px 0 2px">Tham số chung</h3>
					<table class="form-table">
						<tr><th>max_tokens</th><td><input type="number" name="max_tokens" value="<?php echo esc_attr( $o['max_tokens'] ); ?>" min="256" max="1000000" />
							<p class="description">Số token tối đa cho mỗi câu trả lời. DeepSeek hỗ trợ giá trị rất lớn; với Claude hãy giữ trong giới hạn của mô hình đã chọn.</p></td></tr>
						<tr><th>temperature</th><td><input type="number" step="0.1" min="0" max="1" name="temperature" value="<?php echo esc_attr( $o['temperature'] ); ?>" /></td></tr>
						<tr><th>Giới hạn (req/10 phút/IP)</th><td><input type="number" name="rate_limit" value="<?php echo esc_attr( $o['rate_limit'] ); ?>" min="1" /></td></tr>
					</table>
				</div>

				<div class="lado-card">
					<h2>2) Trợ lý ảo</h2>
					<table class="form-table">
						<tr><th>Tên trợ lý</th><td><input type="text" name="assistant_name" value="<?php echo esc_attr( $o['assistant_name'] ); ?>" class="regular-text" /></td></tr>
						<tr><th>Logo / icon trợ lý</th><td>
							<?php $av_url = ! empty( $o['avatar'] ) ? wp_get_attachment_image_url( $o['avatar'], 'thumbnail' ) : ''; ?>
							<input type="hidden" id="avatar" name="avatar" value="<?php echo esc_attr( $o['avatar'] ); ?>" />
							<img id="avatar-preview" src="<?php echo esc_url( $av_url ); ?>" style="<?php echo $av_url ? '' : 'display:none;'; ?>width:46px;height:46px;border-radius:50%;object-fit:cover;vertical-align:middle;margin-right:10px;border:1px solid #cdd9ea" />
							<button type="button" class="button lado-pick-img" data-target="avatar">Chọn ảnh…</button>
							<button type="button" class="button lado-clear-img" data-target="avatar">Xóa</button>
							<p class="description">Ảnh vuông (vd 256×256). Nếu để trống sẽ dùng biểu tượng mặc định.</p>
						</td></tr>
						<tr><th>Tính cách / chỉ dẫn (system prompt)</th><td>
							<textarea name="persona" rows="5" class="large-text"><?php echo esc_textarea( $o['persona'] ); ?></textarea>
						</td></tr>
					</table>
				</div>

				<div class="lado-card">
					<h2>3) Cơ sở dữ liệu ngữ cảnh (Excel / Word)</h2>
					<p class="description">Tải lên file <code>.docx</code>, <code>.xlsx</code>, <code>.csv</code>, <code>.txt</code> hoặc <code>.pdf</code>. Hệ thống trích xuất văn bản làm ngữ cảnh để LaDo-AI trả lời.</p>
					<p>
						<input type="file" name="kb_file[]" accept=".docx,.xlsx,.csv,.txt,.pdf" multiple />
						<label style="margin-left:10px"><input type="checkbox" name="kb_append" value="1" checked /> Nối thêm vào dữ liệu hiện có</label>
					</p>
					<p class="description">Nhận Word (.docx), Excel (.xlsx), CSV, TXT và <strong>PDF</strong> — chọn được nhiều file một lần. Lưu ý: PDF dạng <em>scan/ảnh</em> không trích được chữ (cần file PDF gốc xuất từ Word hoặc phần mềm soạn thảo).</p>
					<p><strong>Đã nạp:</strong>
						<?php if ( ! empty( $o['kb_files'] ) ) : ?>
							<?php foreach ( $o['kb_files'] as $fi => $f ) : ?>
								<span class="lado-chip"><?php echo esc_html( $f['name'] ); ?> (<?php echo esc_html( number_format_i18n( $f['len'] ) ); ?> ký tự)<button type="submit" name="kb_delete" value="<?php echo (int) $fi; ?>" class="lado-chip-x" title="Xóa riêng file này" onclick="return confirm('Xóa file ngữ cảnh này?');">×</button></span>
							<?php endforeach; ?>
						<?php else : ?> <em>chưa có</em> <?php endif; ?>
					</p>
					<p><label><input type="checkbox" name="kb_clear" value="1" /> Xóa toàn bộ dữ liệu ngữ cảnh</label></p>
				</div>

				<div class="lado-card">
					<h2>4) File báo cáo cho nút tải về</h2>
					<p class="description">Quản trị viên đính kèm file báo cáo định kỳ; người dùng bấm nút để tải.</p>
					<table class="form-table">
						<tr><th>Báo cáo TUẦN (.docx)</th><td>
							<input type="hidden" id="report_week" name="report_week" value="<?php echo esc_attr( $o['report_week'] ); ?>" />
							<button type="button" class="button lado-pick" data-target="report_week">Chọn file…</button>
							<span class="lado-file-name" data-for="report_week"><?php echo $week_url ? esc_html( basename( $week_url ) ) : 'chưa chọn'; ?></span>
						</td></tr>
						<tr><th>Báo cáo THÁNG (.docx)</th><td>
							<input type="hidden" id="report_month" name="report_month" value="<?php echo esc_attr( $o['report_month'] ); ?>" />
							<button type="button" class="button lado-pick" data-target="report_month">Chọn file…</button>
							<span class="lado-file-name" data-for="report_month"><?php echo $month_url ? esc_html( basename( $month_url ) ) : 'chưa chọn'; ?></span>
						</td></tr>
					</table>

					<h3 style="margin:18px 0 6px">📅 Báo cáo theo tuần (tab "Tỷ lệ giải ngân theo tuần")</h3>
					<p class="description">Mỗi dòng là một tuần: nhãn (vd "Tuần 22"), tỷ lệ giải ngân lũy kế toàn tỉnh (%) để vẽ biểu đồ đường, và file .docx để người dùng tải. Sắp xếp từ tuần cũ → tuần mới.</p>
					<input type="hidden" name="weeks_json" id="weeks_json" value="" />
					<table class="widefat lado-weeks" id="lado-weeks" style="max-width:760px;margin-bottom:8px">
						<thead><tr><th style="width:160px">Nhãn tuần</th><th style="width:110px">Tỷ lệ (%)</th><th>File .docx</th><th style="width:60px"></th></tr></thead>
						<tbody>
						<?php foreach ( (array) $o['weeks'] as $wk ) :
							$wurl = ! empty( $wk['file'] ) ? wp_get_attachment_url( $wk['file'] ) : ''; ?>
							<tr class="wk-row">
								<td><input type="text" class="wk-ky" value="<?php echo esc_attr( $wk['ky'] ); ?>" placeholder="Tuần 22" /></td>
								<td><input type="number" step="0.01" class="wk-tl" value="<?php echo esc_attr( $wk['tl'] ); ?>" /></td>
								<td>
									<input type="hidden" class="wk-file" value="<?php echo esc_attr( $wk['file'] ); ?>" />
									<button type="button" class="button wk-pick"><?php echo $wurl ? esc_html( basename( $wurl ) ) : 'Chọn file…'; ?></button>
								</td>
								<td><button type="button" class="button wk-del">✕</button></td>
							</tr>
						<?php endforeach; ?>
						</tbody>
					</table>
					<button type="button" class="button" id="wk-add">➕ Thêm tuần</button>
				</div>

				<div class="lado-card lado-import">
					<h2>5) Cập nhật số liệu (chỉ cần upload báo cáo .docx)</h2>
					<p class="lado-help" style="margin-top:0">⚡ Quy trình chuẩn: mỗi kỳ chỉ cần tải đúng file báo cáo lên, hệ thống tự đọc và cập nhật. Báo cáo cần đúng mẫu (xem skill "lado-ai-capnhat-du-lieu").</p>

					<table class="form-table">
						<tr><th>📆 Báo cáo NGÀY (.docx)</th><td>
							<input type="file" name="daily_docx" accept=".docx" />
							<button type="submit" class="button button-primary">Nhập báo cáo ngày</button>
							<p class="description">Cập nhật <strong>toàn bộ</strong> số liệu theo ngày mới nhất, tự thêm điểm vào <em>biểu đồ tỷ lệ giải ngân theo ngày</em>, và lưu file để người dùng <strong>tải báo cáo ngày</strong>.
							<?php $rd = ! empty( $o['report_day'] ) ? wp_get_attachment_url( $o['report_day'] ) : ''; if ( $rd ) : ?> Hiện có: <a href="<?php echo esc_url( $rd ); ?>" target="_blank">file báo cáo ngày</a>.<?php endif; ?></p>
						<?php $dlist = ( isset( $o['days'] ) && is_array( $o['days'] ) ) ? array_values( $o['days'] ) : array(); if ( $dlist ) : ?>
						<details style="margin-top:8px"><summary><strong>🗂 Quản lý điểm biểu đồ ngày (<?php echo count( $dlist ); ?>)</strong> — xóa điểm trùng/tải nhầm</summary>
							<div style="margin-top:6px;display:flex;flex-wrap:wrap;gap:6px">
							<?php foreach ( $dlist as $di => $dp ) : ?>
								<span class="lado-chip"><?php echo esc_html( ( $dp['date'] ?? '?' ) . ' • ' . ( $dp['tl'] ?? 0 ) . '%' . ( isset( $dp['ttg'] ) && $dp['ttg'] ? ' • TTg ' . $dp['ttg'] . '%' : '' ) ); ?><button type="submit" name="day_delete" value="<?php echo (int) $di; ?>" class="lado-chip-x" title="Xóa điểm ngày này" onclick="return confirm('Xóa điểm ngày này khỏi biểu đồ?');">×</button></span>
							<?php endforeach; ?>
							</div>
						</details>
						<?php endif; ?>
						</td></tr>
						<tr><th>📅 Báo cáo THÁNG (.docx)</th><td>
							<input type="file" name="data_docx" accept=".docx" />
							<button type="submit" class="button button-primary">Nhập số liệu biểu đồ</button>
							<p class="description">Cập nhật toàn bộ biểu đồ &amp; bảng: tổng tỉnh, theo nhóm, nguồn vốn 2026/2025, kế hoạch giao, xếp hạng, danh sách 0%, bảng chi tiết 196 đơn vị.</p>
						</td></tr>
						<tr><th>🗓️ Báo cáo TUẦN (.docx)</th><td>
							<input type="file" name="tuan_docx" accept=".docx" />
							<button type="submit" class="button button-primary">Nhập thống kê tuần</button>
							<p class="description">Cập nhật thẻ "Thực hiện kế hoạch giải ngân tuần": đơn vị đăng ký &amp; thực hiện tốt, không đăng ký, đăng ký nhưng 0%.</p>
						</td></tr>
						<tr><th>📁 Danh mục DỰ ÁN theo CĐT (.xlsx)</th><td>
							<?php $dvp = lado_ai_get_donvi(); $stp = isset( $dvp['stats'] ) ? $dvp['stats'] : array(); ?>
							<input type="file" name="duan_xlsx" accept=".xlsx" />
							<button type="submit" class="button button-primary">Cập nhật dự án</button>
							<p class="description"><strong>Mục riêng để cập nhật danh mục dự án cho chuẩn.</strong> Tải file Excel "Danh mục kế hoạch giải ngân theo tuần" — hệ thống đọc <em>toàn bộ dự án theo từng chủ đầu tư</em> (kế hoạch vốn, giải ngân, tỷ lệ) để hiển thị trong popup khi bấm vào chủ đầu tư. Không ảnh hưởng tới liên hệ/kiến nghị đã nạp.
							<?php if ( ! empty( $stp['projects'] ) ) : ?> <strong>Hiện có <?php echo (int) ( $stp['units'] ?? 0 ); ?> chủ đầu tư / <?php echo (int) $stp['projects']; ?> dự án.</strong><?php endif; ?></p>
						</td></tr>
						<tr><th>💡 Kiến nghị, đề xuất (.xlsx)</th><td>
							<?php $knc = lado_ai_get_kiennghi(); ?>
							<input type="file" name="kiennghi_xlsx" accept=".xlsx" />
							<button type="submit" class="button button-primary">Nhập kiến nghị, đề xuất</button>
							<p class="description">Tải file Excel "Danh mục kế hoạch giải ngân theo tuần" — tự tổng hợp toàn bộ kiến nghị, đề xuất theo từng dự án/đơn vị (3 khối) hiển thị trên dashboard.
							<?php if ( ! empty( $knc['total'] ) ) : ?> <strong>Hiện có <?php echo (int) $knc['total']; ?> kiến nghị</strong> (cập nhật <?php echo esc_html( $knc['updated'] ?? '' ); ?>).<?php endif; ?></p>
						</td></tr>
						<tr><th>📇 Danh bạ liên hệ (.docx)</th><td>
							<?php $dvc = lado_ai_get_donvi(); $dvn = isset( $dvc['units'] ) ? count( $dvc['units'] ) : 0; ?>
							<input type="file" name="danhba_docx" accept=".docx" />
							<button type="submit" class="button button-primary">Nhập danh bạ</button>
							<p class="description">Tải file Word "Danh sách danh bạ các cơ quan" — thông tin người đứng đầu / bí thư / chủ tịch + số điện thoại, hiển thị trong popup khi bấm vào từng chủ đầu tư.
							<?php if ( $dvn ) : ?> <strong>Đang lưu <?php echo (int) $dvn; ?> đơn vị</strong> (gồm danh mục dự án &amp; liên hệ).<?php endif; ?></p>
						</td></tr>
						<tr><th>🧩 Báo cáo 06 TỔ (.docx)</th><td>
							<?php $sx = ( $sd = json_decode( $o['data'], true ) ) && isset( $sd['sixto']['tos'] ) ? count( $sd['sixto']['tos'] ) : 0; ?>
							<input type="file" name="sixto_docx" accept=".docx" />
							<button type="submit" class="button button-primary">Nhập 06 tổ</button>
							<p class="description">Tải file Word "Báo cáo thống kê chi tiết theo 06 tổ công tác" — tạo tab thống kê theo tổ (ẩn mặc định) với danh sách chủ đầu tư từng tổ. Bấm vào chủ đầu tư sẽ hiện danh mục dự án (từ Excel) + liên hệ.
							<?php if ( $sx ) : ?> <strong>Đang lưu <?php echo (int) $sx; ?> tổ.</strong><?php endif; ?></p>
						<?php $sflist = ( isset( $o['sixto_files'] ) && is_array( $o['sixto_files'] ) ) ? array_values( $o['sixto_files'] ) : array(); if ( $sflist ) : ?>
						<details style="margin-top:8px" open><summary><strong>🗂 File 06 tổ theo ngày (<?php echo count( $sflist ); ?>)</strong> — người dùng tải về theo ngày</summary>
							<div style="margin-top:6px;display:flex;flex-wrap:wrap;gap:6px">
							<?php foreach ( $sflist as $si => $sfp ) : $surl = ! empty( $sfp['att'] ) ? wp_get_attachment_url( (int) $sfp['att'] ) : ''; ?>
								<span class="lado-chip"><?php if ( $surl ) : ?><a href="<?php echo esc_url( $surl ); ?>" target="_blank"><?php echo esc_html( $sfp['date'] ?? '?' ); ?></a><?php else : ?><?php echo esc_html( $sfp['date'] ?? '?' ); ?><?php endif; ?><button type="submit" name="sixto_delete" value="<?php echo (int) $si; ?>" class="lado-chip-x" title="Xóa file ngày này" onclick="return confirm('Xóa file 6 tổ của ngày này?');">×</button></span>
							<?php endforeach; ?>
							</div>
						</details>
						<?php endif; ?>
						</td></tr>
						<tr><th>📎 Phụ lục GIẢI NGÂN TỪNG DỰ ÁN (.docx)</th><td>
							<?php $dvp = lado_ai_get_donvi(); $pln = isset( $dvp['phuluc']['units'] ) ? count( $dvp['phuluc']['units'] ) : 0; ?>
							<input type="file" name="phuluc_docx" accept=".docx" />
							<button type="submit" class="button button-primary">Nhập phụ lục</button>
							<p class="description">Tải file Word "Phụ lục — Kết quả giải ngân từng dự án theo chủ đầu tư" (số Kho bạc theo mã dự án). Khi bấm vào một chủ đầu tư, bảng dự án sẽ hiển thị <strong>số chính thức Kho bạc</strong>, kèm cột đối chiếu số tự nhập từ danh mục. Người dùng tải được phụ lục theo ngày tại mục "Tải báo cáo".
							<?php if ( $pln ) : ?> <strong>Đang lưu <?php echo (int) $pln; ?> chủ đầu tư<?php echo isset( $dvp['phuluc']['as_of'] ) ? ' (đến ' . esc_html( $dvp['phuluc']['as_of'] ) . ')' : ''; ?>.</strong><?php endif; ?></p>
						<?php $pflist = ( isset( $o['phuluc_files'] ) && is_array( $o['phuluc_files'] ) ) ? array_values( $o['phuluc_files'] ) : array(); if ( $pflist ) : ?>
						<details style="margin-top:8px" open><summary><strong>🗂 File phụ lục theo ngày (<?php echo count( $pflist ); ?>)</strong> — người dùng tải về theo ngày</summary>
							<div style="margin-top:6px;display:flex;flex-wrap:wrap;gap:6px">
							<?php foreach ( $pflist as $pi => $pfp ) : $purl = ! empty( $pfp['att'] ) ? wp_get_attachment_url( (int) $pfp['att'] ) : ''; ?>
								<span class="lado-chip"><?php if ( $purl ) : ?><a href="<?php echo esc_url( $purl ); ?>" target="_blank"><?php echo esc_html( $pfp['date'] ?? '?' ); ?></a><?php else : ?><?php echo esc_html( $pfp['date'] ?? '?' ); ?><?php endif; ?><button type="submit" name="phuluc_delete" value="<?php echo (int) $pi; ?>" class="lado-chip-x" title="Xóa file ngày này" onclick="return confirm('Xóa file phụ lục của ngày này?');">×</button></span>
							<?php endforeach; ?>
							</div>
						</details>
						<?php endif; ?>
						</td></tr>
						<tr><th>🧭 Báo cáo TỔ CÔNG TÁC (.docx — chọn nhiều file)</th><td>
							<?php $tdd = json_decode( $o['data'], true ); $tcn = isset( $tdd['tct']['tos'] ) ? count( $tdd['tct']['tos'] ) : 0; ?>
							<input type="file" name="tct_docx[]" accept=".docx" multiple />
							<button type="submit" class="button button-primary">Nhập báo cáo Tổ</button>
							<p class="description">Tải các file "BaoCao_TCT_SoN_…" của từng Tổ công tác (chọn được cả 6 file một lần). Mục "Thống kê theo 06 tổ" sẽ hiển thị chi tiết từng tổ: số liệu giải ngân, nhóm vướng mắc, danh sách dự án (bấm vào dự án xem vướng mắc/kiến nghị); người dùng tải báo cáo của từng tổ theo ngày.
							<?php if ( $tcn ) : ?> <strong>Đang lưu <?php echo (int) $tcn; ?>/6 tổ<?php echo isset( $tdd['tct']['as_of'] ) ? ' (đến ' . esc_html( $tdd['tct']['as_of'] ) . ')' : ''; ?>.</strong><?php endif; ?></p>
						<?php $tflist = ( isset( $o['tct_files'] ) && is_array( $o['tct_files'] ) ) ? array_values( $o['tct_files'] ) : array(); if ( $tflist ) : ?>
						<details style="margin-top:8px" open><summary><strong>🗂 File báo cáo Tổ theo ngày (<?php echo count( $tflist ); ?>)</strong></summary>
							<div style="margin-top:6px;display:flex;flex-wrap:wrap;gap:6px">
							<?php foreach ( $tflist as $tfi => $tfp ) : $turl = ! empty( $tfp['att'] ) ? wp_get_attachment_url( (int) $tfp['att'] ) : ''; $tlb = 'Tổ ' . ( $tfp['to'] ?? '?' ) . ' • ' . ( $tfp['date'] ?? '?' ); ?>
								<span class="lado-chip"><?php if ( $turl ) : ?><a href="<?php echo esc_url( $turl ); ?>" target="_blank"><?php echo esc_html( $tlb ); ?></a><?php else : ?><?php echo esc_html( $tlb ); ?><?php endif; ?><button type="submit" name="tct_delete" value="<?php echo (int) $tfi; ?>" class="lado-chip-x" title="Xóa file này" onclick="return confirm('Xóa file báo cáo tổ này?');">×</button></span>
							<?php endforeach; ?>
							</div>
						</details>
						<?php endif; ?>
						</td></tr>
					</table>

					<details style="margin-top:6px">
						<summary style="cursor:pointer;font-weight:600;color:#16407a">Chỉnh số liệu thủ công (JSON nâng cao)</summary>
						<p class="description">Đơn vị: triệu đồng. Giữ đúng cấu trúc JSON.</p>
						<textarea name="data" rows="20" class="large-text code" spellcheck="false"><?php echo esc_textarea( $o['data'] ); ?></textarea>
					</details>
				</div>

				<p><button type="submit" class="button button-primary button-hero">💾 Lưu cấu hình</button></p>
			</form>
		</div>
		<?php
	}
}
