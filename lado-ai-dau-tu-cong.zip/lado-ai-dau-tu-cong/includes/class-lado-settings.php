<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class LaDo_AI_Settings {

	public function __construct() {
		add_action( 'admin_menu', array( $this, 'menu' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'assets' ) );
		add_action( 'admin_post_lado_ai_save', array( $this, 'save' ) );
	}

	public function menu() {
		add_menu_page(
			'LaDo-AI', 'LaDo-AI', 'manage_options', 'lado-ai',
			array( $this, 'render' ), 'dashicons-chart-area', 58
		);
	}

	public function assets( $hook ) {
		if ( 'toplevel_page_lado-ai' !== $hook ) { return; }
		wp_enqueue_media();
		wp_enqueue_style( 'lado-admin', LADO_AI_URL . 'assets/css/lado-admin.css', array(), LADO_AI_VERSION );
		wp_enqueue_script( 'lado-admin', LADO_AI_URL . 'assets/js/lado-admin.js', array( 'jquery' ), LADO_AI_VERSION, true );
	}

	public function save() {
		if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'Không đủ quyền.' ); }
		check_admin_referer( 'lado_ai_save' );

		$o = get_option( LADO_AI_OPT, lado_ai_default_settings() );

		$o['api_key']        = isset( $_POST['api_key'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['api_key'] ) ) ) : '';
		$o['model']          = isset( $_POST['model'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['model'] ) ) ) : 'claude-opus-4-8';
		$o['max_tokens']     = isset( $_POST['max_tokens'] ) ? max( 256, min( 8000, (int) $_POST['max_tokens'] ) ) : 1200;
		$o['temperature']    = isset( $_POST['temperature'] ) ? (string) floatval( $_POST['temperature'] ) : '0.2';
		$o['assistant_name'] = isset( $_POST['assistant_name'] ) ? sanitize_text_field( wp_unslash( $_POST['assistant_name'] ) ) : 'LaDo-AI';
		$o['persona']        = isset( $_POST['persona'] ) ? sanitize_textarea_field( wp_unslash( $_POST['persona'] ) ) : '';
		$o['rate_limit']     = isset( $_POST['rate_limit'] ) ? max( 1, (int) $_POST['rate_limit'] ) : 20;
		$o['report_week']    = isset( $_POST['report_week'] ) ? (int) $_POST['report_week'] : 0;
		$o['report_month']   = isset( $_POST['report_month'] ) ? (int) $_POST['report_month'] : 0;

		// Convert báo cáo Word -> số liệu biểu đồ
		if ( ! empty( $_FILES['data_docx']['name'] ) && empty( $_FILES['data_docx']['error'] ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
			$moved = wp_handle_upload( $_FILES['data_docx'], array( 'test_form' => false, 'mimes' => array( 'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' ) ) );
			if ( isset( $moved['file'] ) ) {
				$parsed = LaDo_AI_Data::parse_report( $moved['file'] );
				@unlink( $moved['file'] );
				if ( $parsed && ( isset( $parsed['tong'] ) || isset( $parsed['khoi'] ) ) ) {
					$cur = json_decode( $o['data'], true );
					if ( ! is_array( $cur ) ) { $cur = array(); }
					$o['data'] = wp_json_encode( array_merge( $cur, $parsed ), JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT );
					$notice = 'imported';
				} else {
					$notice = 'importfail';
				}
			}
		}

		// Validate JSON data field (chỉ khi không nhập từ Word ở lần này)
		if ( ! isset( $notice ) && isset( $_POST['data'] ) ) {
			$raw = wp_unslash( $_POST['data'] );
			$decoded = json_decode( $raw, true );
			if ( null !== $decoded ) {
				$o['data'] = wp_json_encode( $decoded, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT );
				$notice = 'saved';
			} else {
				$notice = 'badjson';
			}
		}

		// Knowledge-base file upload (docx/xlsx/csv/txt) -> extract text
		if ( ! empty( $_FILES['kb_file']['name'] ) && empty( $_FILES['kb_file']['error'] ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
			$allowed = array(
				'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
				'xlsx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
				'csv'  => 'text/csv',
				'txt'  => 'text/plain',
			);
			$moved = wp_handle_upload( $_FILES['kb_file'], array( 'test_form' => false, 'mimes' => $allowed ) );
			if ( isset( $moved['file'] ) ) {
				$text = LaDo_AI_Data::extract( $moved['file'] );
				$name = sanitize_file_name( $_FILES['kb_file']['name'] );
				if ( ! empty( $_POST['kb_append'] ) ) {
					$o['kb_text'] = trim( $o['kb_text'] . "\n\n===== " . $name . " =====\n" . $text );
				} else {
					$o['kb_text'] = "===== " . $name . " =====\n" . $text;
					$o['kb_files'] = array();
				}
				$o['kb_files'][] = array( 'name' => $name, 'len' => mb_strlen( $text ) );
				@unlink( $moved['file'] );
			}
		}
		if ( isset( $_POST['kb_clear'] ) ) { $o['kb_text'] = ''; $o['kb_files'] = array(); }

		update_option( LADO_AI_OPT, $o );
		$notice = isset( $notice ) ? $notice : 'saved';
		wp_safe_redirect( admin_url( 'admin.php?page=lado-ai&notice=' . $notice ) );
		exit;
	}

	public function render() {
		$o = get_option( LADO_AI_OPT, lado_ai_default_settings() );
		$notice = isset( $_GET['notice'] ) ? sanitize_text_field( wp_unslash( $_GET['notice'] ) ) : '';
		$week_url  = $o['report_week'] ? wp_get_attachment_url( $o['report_week'] ) : '';
		$month_url = $o['report_month'] ? wp_get_attachment_url( $o['report_month'] ) : '';
		?>
		<div class="wrap lado-admin">
			<h1>⚙️ LaDo-AI — Cấu hình</h1>
			<?php if ( 'saved' === $notice ) : ?>
				<div class="notice notice-success is-dismissible"><p>Đã lưu cấu hình.</p></div>
			<?php elseif ( 'imported' === $notice ) : ?>
				<div class="notice notice-success is-dismissible"><p>✅ Đã nhập số liệu biểu đồ từ file Word và lưu lại. Bạn có thể kiểm tra/điều chỉnh trong ô JSON bên dưới.</p></div>
			<?php elseif ( 'importfail' === $notice ) : ?>
				<div class="notice notice-error is-dismissible"><p>Không đọc được số liệu từ file Word. Hãy đảm bảo đây là báo cáo có bảng tổng hợp theo khối (dòng "TOÀN TỈNH").</p></div>
			<?php elseif ( 'badjson' === $notice ) : ?>
				<div class="notice notice-error is-dismissible"><p>Dữ liệu JSON không hợp lệ — các mục khác đã lưu, riêng phần số liệu biểu đồ chưa được cập nhật.</p></div>
			<?php endif; ?>

			<p class="lado-help">Chèn bảng điều khiển vào bất kỳ trang nào bằng shortcode: <code>[lado_ai_dashboard]</code></p>

			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" enctype="multipart/form-data">
				<input type="hidden" name="action" value="lado_ai_save" />
				<?php wp_nonce_field( 'lado_ai_save' ); ?>

				<div class="lado-card">
					<h2>1) Kết nối Claude API</h2>
					<table class="form-table">
						<tr><th>API key</th><td>
							<input type="password" name="api_key" value="<?php echo esc_attr( $o['api_key'] ); ?>" class="regular-text" autocomplete="off" placeholder="sk-ant-..." />
							<p class="description">Khóa lưu phía máy chủ, không hiển thị ra trình duyệt người dùng.</p>
						</td></tr>
						<tr><th>Mô hình Claude (nhập thủ công)</th><td>
							<input type="text" name="model" value="<?php echo esc_attr( $o['model'] ); ?>" class="regular-text" placeholder="claude-opus-4-8" />
							<p class="description">Ví dụ: <code>claude-opus-4-8</code>, <code>claude-sonnet-4-6</code>, <code>claude-haiku-4-5-20251001</code>…</p>
						</td></tr>
						<tr><th>max_tokens</th><td><input type="number" name="max_tokens" value="<?php echo esc_attr( $o['max_tokens'] ); ?>" min="256" max="8000" /></td></tr>
						<tr><th>temperature</th><td><input type="number" step="0.1" min="0" max="1" name="temperature" value="<?php echo esc_attr( $o['temperature'] ); ?>" /></td></tr>
						<tr><th>Giới hạn (req/10 phút/IP)</th><td><input type="number" name="rate_limit" value="<?php echo esc_attr( $o['rate_limit'] ); ?>" min="1" /></td></tr>
					</table>
				</div>

				<div class="lado-card">
					<h2>2) Trợ lý ảo</h2>
					<table class="form-table">
						<tr><th>Tên trợ lý</th><td><input type="text" name="assistant_name" value="<?php echo esc_attr( $o['assistant_name'] ); ?>" class="regular-text" /></td></tr>
						<tr><th>Tính cách / chỉ dẫn (system prompt)</th><td>
							<textarea name="persona" rows="5" class="large-text"><?php echo esc_textarea( $o['persona'] ); ?></textarea>
						</td></tr>
					</table>
				</div>

				<div class="lado-card">
					<h2>3) Cơ sở dữ liệu ngữ cảnh (Excel / Word)</h2>
					<p class="description">Tải lên file <code>.docx</code>, <code>.xlsx</code>, <code>.csv</code> hoặc <code>.txt</code>. Hệ thống trích xuất văn bản làm ngữ cảnh để LaDo-AI trả lời.</p>
					<p>
						<input type="file" name="kb_file" accept=".docx,.xlsx,.csv,.txt" />
						<label style="margin-left:10px"><input type="checkbox" name="kb_append" value="1" /> Nối thêm vào dữ liệu hiện có</label>
					</p>
					<p><strong>Đã nạp:</strong>
						<?php if ( ! empty( $o['kb_files'] ) ) : ?>
							<?php foreach ( $o['kb_files'] as $f ) : ?>
								<span class="lado-chip"><?php echo esc_html( $f['name'] ); ?> (<?php echo esc_html( number_format_i18n( $f['len'] ) ); ?> ký tự)</span>
							<?php endforeach; ?>
						<?php else : ?> <em>chưa có</em> <?php endif; ?>
					</p>
					<p><label><input type="checkbox" name="kb_clear" value="1" /> Xóa toàn bộ dữ liệu ngữ cảnh</label></p>
				</div>

				<div class="lado-card">
					<h2>4) File báo cáo cho nút tải về</h2>
					<p class="description">Quản trị viên đính kèm file báo cáo định kỳ; người dùng bấm nút để tải.</p>
					<table class="form-table">
						<tr><th>Báo cáo TUẦN (.docx)</th><td>
							<input type="hidden" id="report_week" name="report_week" value="<?php echo esc_attr( $o['report_week'] ); ?>" />
							<button type="button" class="button lado-pick" data-target="report_week">Chọn file…</button>
							<span class="lado-file-name" data-for="report_week"><?php echo $week_url ? esc_html( basename( $week_url ) ) : 'chưa chọn'; ?></span>
						</td></tr>
						<tr><th>Báo cáo THÁNG (.docx)</th><td>
							<input type="hidden" id="report_month" name="report_month" value="<?php echo esc_attr( $o['report_month'] ); ?>" />
							<button type="button" class="button lado-pick" data-target="report_month">Chọn file…</button>
							<span class="lado-file-name" data-for="report_month"><?php echo $month_url ? esc_html( basename( $month_url ) ) : 'chưa chọn'; ?></span>
						</td></tr>
					</table>
				</div>

				<div class="lado-card lado-import">
					<h2>5) Cập nhật số liệu biểu đồ</h2>
					<p class="lado-help" style="margin-top:0">⚡ <strong>Cách nhanh:</strong> tải lên file báo cáo Word (.docx) — hệ thống tự đọc các bảng (tổng hợp theo khối, kế hoạch giao, xếp hạng, danh sách 0%) và điền số liệu biểu đồ. Không cần sửa JSON thủ công.</p>
					<p>
						<input type="file" name="data_docx" accept=".docx" />
						<button type="submit" class="button button-primary">📤 Nhập số liệu từ file Word</button>
					</p>
					<p class="description">File báo cáo cần có bảng tổng hợp theo khối (có dòng <code>TOÀN TỈNH</code>) và các bảng chi tiết. Sau khi nhập, số liệu hiển thị trong ô JSON bên dưới để bạn kiểm tra.</p>
					<details style="margin-top:10px">
						<summary style="cursor:pointer;font-weight:600;color:#16407a">Hoặc chỉnh số liệu thủ công (JSON nâng cao)</summary>
						<p class="description">Đơn vị: triệu đồng. Giữ đúng cấu trúc JSON.</p>
						<textarea name="data" rows="20" class="large-text code" spellcheck="false"><?php echo esc_textarea( $o['data'] ); ?></textarea>
					</details>
				</div>

				<p><button type="submit" class="button button-primary button-hero">💾 Lưu cấu hình</button></p>
			</form>
		</div>
		<?php
	}
}
