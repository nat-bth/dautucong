<?php
/**
 * Plugin Name:       LaDo-AI – Giải ngân vốn đầu tư công Lâm Đồng
 * Plugin URI:        https://lamdong.gov.vn
 * Description:        Bảng điều khiển (dashboard) trực quan hóa số liệu giải ngân vốn đầu tư công tỉnh Lâm Đồng, kèm trợ lý ảo LaDo-AI (Claude API) và nút tải báo cáo tuần/tháng. Dùng shortcode [lado_ai_dashboard].
 * Version:           1.0.0
 * Author:            Văn phòng UBND tỉnh Lâm Đồng
 * License:           GPLv2 or later
 * Text Domain:       lado-ai
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

define( 'LADO_AI_VERSION', '1.0.0' );
define( 'LADO_AI_FILE', __FILE__ );
define( 'LADO_AI_DIR', plugin_dir_path( __FILE__ ) );
define( 'LADO_AI_URL', plugin_dir_url( __FILE__ ) );
define( 'LADO_AI_OPT', 'lado_ai_settings' );

require_once LADO_AI_DIR . 'includes/class-lado-data.php';
require_once LADO_AI_DIR . 'includes/lado-fulldata.php';
require_once LADO_AI_DIR . 'includes/class-lado-claude.php';
require_once LADO_AI_DIR . 'includes/class-lado-settings.php';
require_once LADO_AI_DIR . 'includes/class-lado-ajax.php';
require_once LADO_AI_DIR . 'includes/class-lado-shortcode.php';

/**
 * Default options seeded on activation. Số liệu mặc định = báo cáo đến 28/5/2026.
 */
function lado_ai_default_settings() {
	return array(
		'api_key'        => '',
		'model'          => 'claude-opus-4-8',
		'max_tokens'     => 1200,
		'temperature'    => '0.2',
		'assistant_name' => 'LaDo-AI',
		'persona'        => "Bạn là LaDo-AI – trợ lý ảo của Văn phòng UBND tỉnh Lâm Đồng, chuyên trả lời các câu hỏi về phân bổ và giải ngân vốn đầu tư công của tỉnh Lâm Đồng. Trả lời ngắn gọn, chính xác, lịch sự bằng tiếng Việt; ưu tiên trích dẫn số liệu từ phần NGỮ CẢNH được cung cấp. Nếu không có dữ liệu, hãy nói rõ là chưa có thông tin và gợi ý liên hệ Văn phòng UBND tỉnh. Không bịa số liệu.",
		'kb_text'        => '',
		'kb_files'       => array(),       // [{name, type}]
		'report_week'    => 0,             // attachment ID
		'report_month'   => 0,             // attachment ID
		'rate_limit'     => 20,            // requests / 10 min / IP
		'data'           => lado_ai_default_data_json(),
	);
}

function lado_ai_default_data_json() {
	$data = array(
		'tinh'   => 'Lâm Đồng',
		'as_of'  => '28/5/2026',
		'unit'   => 'triệu đồng',
		'tong'   => array( 'kh' => 18065801, 'gn' => 1623778, 'tl' => 8.99, 'tang' => 524148, 'tang_pc' => 2.90 ),
		'nguon'  => array(
			array( 'ten' => 'Vốn năm 2026', 'gn' => 1229671 ),
			array( 'ten' => 'Vốn kéo dài 2025', 'gn' => 394107, 'kh' => 4268235, 'tl' => 9.23 ),
		),
		'khoi'   => array(
			array( 'ten' => 'Ban QLDA (31 đơn vị)',       'kh' => 10695596, 'gn' => 999018, 'tl' => 9.34 ),
			array( 'ten' => 'Sở, ngành, đơn vị (41)',     'kh' => 6025281,  'gn' => 400417, 'tl' => 6.65 ),
			array( 'ten' => 'Xã, phường, đặc khu (124)',  'kh' => 1344924,  'gn' => 224343, 'tl' => 16.68 ),
		),
		'kehoach_giao' => array(
			array( 'ten' => 'Thủ tướng Chính phủ giao', 'kh' => 14867147, 'tl' => 8.27 ),
			array( 'ten' => 'HĐND tỉnh giao',           'kh' => 15847247, 'tl' => 7.76 ),
			array( 'ten' => 'UBND tỉnh phân bổ',        'kh' => 14994828, 'tl' => 8.20 ),
		),
		'top_ban' => array(
			array( 'ten' => 'KV La Gi', 'tl' => 61.77 ), array( 'ten' => 'KV Bảo Lâm', 'tl' => 29.72 ),
			array( 'ten' => 'KV Cư Jút', 'tl' => 28.55 ), array( 'ten' => 'KV Đắk Song', 'tl' => 26.40 ),
			array( 'ten' => 'KV Đắk Glong', 'tl' => 24.02 ), array( 'ten' => 'KV Bảo Lộc', 'tl' => 22.30 ),
		),
		'bottom_ban' => array(
			array( 'ten' => 'KV Tánh Linh', 'tl' => 0.45 ), array( 'ten' => 'KV Hàm Tân', 'tl' => 2.04 ),
			array( 'ten' => 'KV Đắk Mil', 'tl' => 2.22 ), array( 'ten' => "KV Đắk R'lấp", 'tl' => 4.45 ),
			array( 'ten' => 'KV Tuy Phong', 'tl' => 5.52 ),
		),
		'top_so' => array(
			array( 'ten' => 'Ngân hàng CSXH tỉnh', 'tl' => 100 ), array( 'ten' => 'Cty CTTL Đắk Nông', 'tl' => 80.59 ),
			array( 'ten' => 'Sở Xây dựng', 'tl' => 65.82 ), array( 'ten' => 'Sở Nội vụ', 'tl' => 53.12 ),
			array( 'ten' => 'Sở Tài chính', 'tl' => 42.58 ),
		),
		'top_xa' => array(
			array( 'ten' => 'Xã Lương Sơn', 'tl' => 97.56 ), array( 'ten' => 'Xã Đạ Tẻh 3', 'tl' => 71.12 ),
			array( 'ten' => 'Xã Hải Ninh', 'tl' => 69.97 ), array( 'ten' => 'Xã Đam Rông 2', 'tl' => 67.22 ),
			array( 'ten' => 'Xã Nghị Đức', 'tl' => 67.06 ),
		),
		'zero' => array( 'tong' => 51, 'so' => 26, 'xa' => 25 ),
		'zero_list_so' => array(
			'Sở Y tế', 'Bộ Chỉ huy quân sự tỉnh', 'Công ty TNHH MTV lâm nghiệp Bảo Lâm', 'Công ty TNHH MTV lâm nghiệp Đạ Tẻh',
			'Công ty TNHH MTV lâm nghiệp Đơn Dương', 'Công ty TNHH MTV lâm nghiệp Lộc Bắc', 'Công ty TNHH MTV lâm nghiệp Tam Hiệp',
			"Ban QLR PH D'Ran", 'Ban QLR PH Tân Thượng - Hòa Bắc', 'Ban QLRPH Đa Nhim', "Ban QLRPH Đam B'ri", 'Ban QLRPH Lâm Hà',
			'Ban QLRPH Nam Huoai', 'Ban QLRPH Sêrêpôk', 'Ban QLRPH Đức Trọng', 'Ban quản lý rừng PH Lâm Viên', 'Tỉnh đoàn',
			'Công ty TNHH MTV KTCT thuỷ lợi Bình Thuận', 'Trường Cao đẳng Đà Lạt', 'Công ty TNHH MTV Lâm Nghiệp Đạ',
			'BCH Bộ đội Biên phòng tỉnh Lâm Đồng', 'Bệnh viện đa khoa Đắk Nông', 'Trung tâm Y tế Quân dân y đặc khu Phú Quý',
			'Trường Cao đẳng Bình Thuận', 'Sở Khoa học và Công nghệ', 'Công an tỉnh',
		),
		'zero_list_xa' => array(
			'Xã Tà Hine', 'Xã Tà Năng', 'Xã Hoà Bắc', 'Xã Sơn Điền', 'Xã Bảo Lâm 4', 'Xã Nam Dong', 'Xã Nâm Nung',
			'Xã Đắk Mil', 'Xã Đắk Sắk', 'Xã Đắk Song', 'Xã Thuận Hạnh', 'Xã Quảng Hòa', 'Xã Quảng Sơn', 'Phường Phan Thiết',
			'Xã Tuyên Quang', 'Phường Hàm Thắng', 'Phường Bình Thuận', 'Xã Phan Sơn', 'Xã Sông Lũy', 'Xã Hồng Sơn',
			'Xã Đông Giang', 'Xã La Dạ', 'Xã Hàm Thuận Nam', 'Xã Suối Kiết', 'Đặc khu Phú Quý',
		),
	);
	$full = function_exists( 'lado_ai_full_lists' ) ? lado_ai_full_lists() : array();
	if ( is_array( $full ) ) { $data = array_merge( $data, $full ); }
	return wp_json_encode( $data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT );
}

register_activation_hook( __FILE__, function () {
	$existing = get_option( LADO_AI_OPT );
	if ( ! $existing ) {
		add_option( LADO_AI_OPT, lado_ai_default_settings() );
	} else {
		// fill any missing keys
		$merged = wp_parse_args( $existing, lado_ai_default_settings() );
		update_option( LADO_AI_OPT, $merged );
	}
} );

/** Helper: get a setting */
function lado_ai_get( $key, $default = '' ) {
	$o = get_option( LADO_AI_OPT, array() );
	return isset( $o[ $key ] ) ? $o[ $key ] : $default;
}

// Boot
add_action( 'plugins_loaded', function () {
	new LaDo_AI_Settings();
	new LaDo_AI_Ajax();
	new LaDo_AI_Shortcode();
} );
