(function () {
  'use strict';
  if (typeof LADO_AI === 'undefined') return;
  var D = LADO_AI.data || {};
  var NAME = LADO_AI.name || 'LaDo-AI';
  var AV = LADO_AI.avatar || '';
  function avHtml() { return AV ? '<img src="' + AV.replace(/"/g, '') + '" alt="">' : '🤖'; }
  var app = document.getElementById('lado-app');
  if (!app) return;

  /* ---------- helpers ---------- */
  function vn(n) { try { return Math.round(n).toLocaleString('vi-VN'); } catch (e) { return n; } }
  function pc(n) { return (Number(n).toFixed(2)).replace('.', ',') + '%'; }
  function tyd(n) { return (n / 1000).toLocaleString('vi-VN', { maximumFractionDigits: 0 }); }
  function el(html) { var d = document.createElement('div'); d.innerHTML = html.trim(); return d.firstChild; }
  function esc(s){return (s==null?'':String(s)).replace(/[&<>"]/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c];});}

  var tong = D.tong || {}, khoi = D.khoi || [], giao = D.kehoach_giao || [];
  var color = { navy:'#0f2c52', blue:'#2563eb', sky:'#38bdf8', green:'#16a34a', amber:'#d97706', red:'#dc2626', line:'#e2e8f0' };

  /* ---------- build shell ---------- */
  app.classList.remove('lado-loading');
  app.innerHTML = ''
  + '<div class="lado-top">'
  +   '<div class="lado-brand"><div class="lado-logo">' + (LADO_AI.avatar ? '<img src="' + esc(LADO_AI.avatar) + '" alt="">' : '📊') + '</div>'
  +     '<div><h1>Hệ thống dữ liệu giải ngân vốn đầu tư công tỉnh ' + esc(D.tinh || 'Lâm Đồng') + '</h1>'
  +     '<p>Văn phòng UBND tỉnh</p></div></div>'
  +   '<div class="lado-spacer"></div>'
  +   '<div class="lado-asof">🗓️ Lũy kế đến ' + esc(D.as_of || '') + '</div>'
  + '</div>'
  + '<nav class="lado-nav"><button class="ln-arrow ln-prev" id="ln-prev" aria-label="Trái">‹</button><div class="ln-track" id="lado-nav"></div><button class="ln-arrow ln-next" id="ln-next" aria-label="Phải">›</button></nav>'
  + '<div class="lado-body">'
  +   '<div class="lado-kpis" id="sec-tong"></div>'
  +   '<div class="card" id="sec-dl"><h3>📥 Tải báo cáo</h3><p class="hint">Bấm để ' + esc(NAME) + ' tổng hợp và xuất báo cáo định kỳ (.docx).</p>'
  +     '<div class="lado-actions">'
  +       '<button class="dlbtn week" data-type="week"><span class="ic">📄</span><span>Tải báo cáo TUẦN<small>Bản cập nhật mới nhất</small></span></button>'
  +       '<button class="dlbtn month" data-type="month"><span class="ic">📑</span><span>Tải báo cáo THÁNG<small>Tổng hợp theo tháng</small></span></button>'
  +     '</div></div>'
  +   '<div class="lado-grid" id="sec-khoi">'
  +     '<div class="card gauge"><h3>🎯 Tỷ lệ giải ngân toàn tỉnh</h3><p class="hint">Tổng kế hoạch ' + vn(tong.kh) + ' • đã giải ngân ' + vn(tong.gn) + ' (triệu đồng)</p>'
  +       '<div class="chart-wrap"><canvas id="c-gauge"></canvas><div class="gauge-center"><div class="pct">' + pc(tong.tl || 0) + '</div><div class="cap">lũy kế giải ngân</div></div></div></div>'
  +     '<div class="card"><h3>🏗️ Theo nhóm chủ đầu tư</h3><p class="hint">Kế hoạch vốn và đã giải ngân (tỷ đồng)</p><div class="chart-wrap"><canvas id="c-khoi"></canvas></div></div>'
  +   '</div>'
  +   '<div class="card src-card" id="sec-nguon"><h3>🎯 Tỷ lệ giải ngân theo nguồn vốn</h3><p class="hint">Tách riêng tiến độ vốn năm 2026 và vốn kéo dài năm 2025.</p>'
  +     '<div class="src-gauges" id="src-gauges"></div></div>'
  +   '<div class="lado-grid">'
  +     '<div class="card"><h3>🧭 Cơ cấu theo nhóm</h3><p class="hint">Tỷ trọng giá trị đã giải ngân</p><div class="chart-wrap"><canvas id="c-pie"></canvas></div></div>'
  +   '</div>'
  +   '<div class="card week-card" id="sec-week"><h3>📅 Tỷ lệ giải ngân theo tuần</h3><p class="hint">Diễn biến tỷ lệ giải ngân lũy kế toàn tỉnh qua các tuần. Bấm để tải báo cáo từng tuần.</p>'
  +     '<div class="chart-wrap" style="height:240px"><canvas id="c-week"></canvas></div>'
  +     '<div class="week-list" id="week-list"></div></div>'
  +   '<div class="two-col" id="sec-rank">'
  +     '<div class="card"><h3>🥇 Ban QLDA giải ngân tốt nhất</h3><div class="rank" id="r-topban"></div></div>'
  +     '<div class="card"><h3>🐢 Ban QLDA giải ngân thấp nhất</h3><div class="rank bad" id="r-botban"></div></div>'
  +   '</div>'
  +   '<div class="two-col">'
  +     '<div class="card"><h3>🏆 Xã/phường tiêu biểu</h3><div class="rank" id="r-topxa"></div></div>'
  +     '<div class="card"><h3>🏢 Sở, ngành, đơn vị tiêu biểu</h3><div class="rank" id="r-topso"></div></div>'
  +   '</div>'
  +   '<div class="card lado-detail" id="sec-detail"><h3>📋 Bảng kết quả giải ngân chi tiết (toàn bộ đơn vị)</h3>'
  +     '<p class="hint">Số liệu lũy kế theo từng chủ đầu tư (triệu đồng). Chọn nhóm và gõ để lọc theo tên.</p>'
  +     '<div class="ld-tabs">'
  +       '<button class="ld-tab on" data-g="ban">Ban QLDA (<span id="cnt-ban">0</span>)</button>'
  +       '<button class="ld-tab" data-g="so">Sở, ngành (<span id="cnt-so">0</span>)</button>'
  +       '<button class="ld-tab" data-g="xa">Xã, phường (<span id="cnt-xa">0</span>)</button>'
  +     '</div>'
  +     '<input type="search" class="ld-search" id="ld-search" placeholder="🔍 Tìm theo tên đơn vị…">'
  +     '<div class="ld-table-wrap" id="ld-table"></div>'
  +   '</div>'
  +   '<div class="card wkstat-card" id="sec-wkstat"><h3>📊 Thực hiện kế hoạch giải ngân tuần</h3><p class="hint" id="wkstat-ky"></p><div class="wk-stats" id="wk-stats"></div></div>'
  +   '<div class="card" id="sec-zero"><h3>🚫 Đơn vị chưa giải ngân (0%)</h3><p class="hint">Danh sách đầy đủ các đơn vị/địa phương được giao vốn nhưng đến nay chưa phát sinh giải ngân.</p><div id="zero-box"></div></div>'
  +   '<div class="card kn-card" id="kn-card"><h3>💡 Kiến nghị, đề xuất tổng hợp</h3>'
  +     '<p class="hint" id="kn-sub"></p>'
  +     '<div class="kn-controls">'
  +       '<input type="search" id="kn-q" placeholder="🔍 Tìm theo đơn vị, dự án, nội dung…">'
  +       '<select id="kn-khoi"><option value="">Tất cả khối</option><option value="Ban QLDA">Ban QLDA</option><option value="Sở, ngành">Sở, ngành</option><option value="Xã, phường, đặc khu">Xã, phường, đặc khu</option></select>'
  +       '<select id="kn-nhom"><option value="">Tất cả nhóm khó khăn</option></select>'
  +     '</div>'
  +     '<div class="kn-chips" id="kn-chips"></div>'
  +     '<div class="kn-list" id="kn-list"></div>'
  +     '<div class="kn-more-wrap"><button id="kn-more" class="kn-more" style="display:none">Xem thêm</button></div>'
  +   '</div>'
  +   '<div class="lado-footer">Phát triển bởi <b>Nguyễn Anh Trung</b></div>'
  + '</div>'
  /* stats popup modal */
  + '<div class="lado-modal" id="lado-modal"><div class="lm-box"><div class="lm-head"><h4 id="lm-title"></h4><button class="lm-x" id="lm-x">✕</button></div><div class="lm-body" id="lm-body"></div></div></div>'
  /* download overlay */
  + '<div class="lado-ov" id="lado-ov"><div class="ov-box">'
  +   '<div class="ov-orb"></div>'
  +   '<h4><span class="who">' + esc(NAME) + '</span> đang tổng hợp dữ liệu</h4>'
  +   '<div id="ov-sub" style="font-size:13px;opacity:.85">Vui lòng đợi trong giây lát…</div>'
  +   '<div class="ov-steps">'
  +     '<div class="ov-step" data-s="0"><span class="dot">1</span> Kết nối cơ sở dữ liệu giải ngân</div>'
  +     '<div class="ov-step" data-s="1"><span class="dot">2</span> Tổng hợp số liệu Kho bạc &amp; Sở Tài chính</div>'
  +     '<div class="ov-step" data-s="2"><span class="dot">3</span> Dựng biểu đồ &amp; bảng phân tích</div>'
  +     '<div class="ov-step" data-s="3"><span class="dot">4</span> Xuất báo cáo định dạng .docx</div>'
  +   '</div>'
  +   '<div class="ov-prog"><i id="ov-prog"></i></div>'
  +   '<button class="ov-cancel" id="ov-cancel">Hủy</button>'
  + '</div></div>'
  /* chat */
  + '<button class="lado-fab" id="lado-fab"><span class="av">' + avHtml() + '</span> Hỏi ' + esc(NAME) + '</button>'
  + '<div class="lado-chat" id="lado-chat">'
  +   '<div class="chat-head"><div class="av">' + avHtml() + '</div><div class="ch-meta"><b>' + esc(NAME) + '</b><span><i class="dot-on"></i> Trực tuyến • Trợ lý giải ngân ĐTC</span></div><button class="x" id="chat-x">✕</button></div>'
  +   '<div class="chat-body" id="chat-body"></div>'
  +   '<div class="chat-foot"><textarea id="chat-in" rows="1" placeholder="Nhập câu hỏi về phân bổ, giải ngân…"></textarea><button id="chat-send">➤</button></div>'
  +   '<div class="foot-note">' + esc(NAME) + ' có thể trả lời chưa đầy đủ. Vui lòng đối chiếu văn bản chính thức.</div>'
  + '</div>';

  /* ---------- KPIs ---------- */
  var kpis = app.querySelector('.lado-kpis');
  var nguon = D.nguon || [];
  var v26 = (nguon[0] && nguon[0].gn) || 0, vkd = (nguon[1] && nguon[1].gn) || 0;
  kpis.appendChild(el('<div class="kpi n"><div class="lab">Tổng kế hoạch vốn</div><div class="val">' + tyd(tong.kh) + '<span style="font-size:14px"> tỷ</span></div><div class="sub">gồm vốn kéo dài 2025</div></div>'));
  kpis.appendChild(el('<div class="kpi"><div class="lab">Lũy kế giải ngân</div><div class="val">' + tyd(tong.gn) + '<span style="font-size:14px"> tỷ</span></div><div class="sub"><span class="up">▲ +' + vn(tong.tang) + '</span> so tháng trước</div></div>'));
  kpis.appendChild(el('<div class="kpi g"><div class="lab">Tỷ lệ giải ngân</div><div class="val">' + pc(tong.tl || 0) + '</div><div class="sub">+' + pc(tong.tang_pc || 0).replace('%','') + '% so tháng trước</div></div>'));
  kpis.appendChild(el('<div class="kpi a"><div class="lab">Đơn vị chưa giải ngân</div><div class="val">' + ((D.zero && D.zero.tong) || 0) + '</div><div class="sub">' + ((D.zero && D.zero.so) || 0) + ' sở/ngành • ' + ((D.zero && D.zero.xa) || 0) + ' xã/phường</div></div>'));

  /* ---------- charts ---------- */
  if (window.Chart) {
    Chart.defaults.font.family = "'Inter','Segoe UI',sans-serif";
    Chart.defaults.font.size = 12.5;

    var g = (tong.tl || 0);
    new Chart(document.getElementById('c-gauge'), {
      type: 'doughnut',
      data: { datasets: [{ data: [g, 100 - g], backgroundColor: [color.navy, '#e8eef6'], borderWidth: 0 }] },
      options: { cutout: '74%', plugins: { legend: { display: false }, tooltip: { enabled: false } }, animation: { animateRotate: true } }
    });

    new Chart(document.getElementById('c-khoi'), {
      type: 'bar',
      data: {
        labels: khoi.map(function (k) { return k.ten.replace(/\s*\(.*\)/, ''); }),
        datasets: [
          { label: 'Kế hoạch', data: khoi.map(function (k) { return k.kh / 1000; }), backgroundColor: '#cdddf0', borderRadius: 6 },
          { label: 'Đã giải ngân', data: khoi.map(function (k) { return k.gn / 1000; }), backgroundColor: color.navy, borderRadius: 6 }
        ]
      },
      options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'bottom' }, tooltip: { callbacks: { label: function (c) { return c.dataset.label + ': ' + vn(c.raw) + ' tỷ'; } } } }, scales: { y: { ticks: { callback: function (v) { return vn(v); } } } } }
    });

    new Chart(document.getElementById('c-giao'), {
      type: 'bar',
      data: { labels: giao.map(function (x) { return x.ten; }), datasets: [{ label: 'Tỷ lệ giải ngân', data: giao.map(function (x) { return x.tl; }), backgroundColor: [color.blue, color.sky, '#6366f1'], borderRadius: 6 }] },
      options: { indexAxis: 'y', responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false }, tooltip: { callbacks: { label: function (c) { return pc(c.raw); } } } }, scales: { x: { ticks: { callback: function (v) { return v + '%'; } }, suggestedMax: 12 } } }
    });

    new Chart(document.getElementById('c-pie'), {
      type: 'doughnut',
      data: { labels: khoi.map(function (k) { return k.ten.replace(/\s*\(.*\)/, ''); }), datasets: [{ data: khoi.map(function (k) { return k.gn; }), backgroundColor: [color.navy, color.blue, color.sky], borderWidth: 2, borderColor: '#fff' }] },
      options: { responsive: true, maintainAspectRatio: false, cutout: '55%', plugins: { legend: { position: 'bottom' }, tooltip: { callbacks: { label: function (c) { return c.label + ': ' + vn(c.raw) + ' tr.đ'; } } } } }
    });

    /* source-vốn gauges (2026 / 2025) */
    (function () {
      var host = document.getElementById('src-gauges'); if (!host) return;
      if (nguon.length === 2 && tong.kh) {
        if (nguon[1].kh && nguon[0].kh == null) nguon[0].kh = tong.kh - nguon[1].kh;
        if (nguon[0].kh && nguon[1].kh == null) nguon[1].kh = tong.kh - nguon[0].kh;
      }
      var palette = [color.blue, '#7c3aed', color.sky];
      (nguon || []).forEach(function (s, i) {
        var tl = (s.tl != null) ? s.tl : (s.kh ? (s.gn / s.kh * 100) : null);
        if (tl == null) return;
        var cell = el('<div class="src-item"><div class="src-canv"><canvas></canvas><div class="src-mid"><b>' + pc(tl) + '</b></div></div>'
          + '<div class="src-meta"><div class="src-name">' + esc(s.ten) + '</div><div class="src-sub">GN ' + vn(s.gn) + (s.kh ? ' / ' + vn(s.kh) : '') + ' tr.đ</div></div></div>');
        host.appendChild(cell);
        new Chart(cell.querySelector('canvas'), {
          type: 'doughnut',
          data: { datasets: [{ data: [tl, Math.max(0, 100 - tl)], backgroundColor: [palette[i % palette.length], '#e8eef6'], borderWidth: 0 }] },
          options: { cutout: '72%', plugins: { legend: { display: false }, tooltip: { enabled: false } } }
        });
      });
    })();

    /* weekly trend line */
    (function () {
      var weeks = (LADO_AI.weeks || []).filter(function (w) { return w.tl != null; });
      var cv = document.getElementById('c-week'); if (!cv || !weeks.length) { var wc = document.querySelector('.week-card .chart-wrap'); if (wc && !weeks.length) wc.style.display = 'none'; return; }
      new Chart(cv, {
        type: 'line',
        data: {
          labels: weeks.map(function (w) { return w.ky; }),
          datasets: [{
            label: 'Tỷ lệ giải ngân', data: weeks.map(function (w) { return w.tl; }),
            borderColor: color.blue, backgroundColor: 'rgba(37,99,235,.12)', fill: true,
            tension: .3, pointRadius: 4, pointBackgroundColor: color.blue, borderWidth: 2.5
          }]
        },
        options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false }, tooltip: { callbacks: { label: function (c) { return pc(c.raw); } } } }, scales: { y: { ticks: { callback: function (v) { return v + '%'; } }, beginAtZero: true } } }
      });
    })();
  }

  /* ---------- ranking lists ---------- */
  function fillRank(id, arr, bad) {
    var box = document.getElementById(id); if (!box || !arr) return;
    var max = Math.max.apply(null, arr.map(function (x) { return x.tl; }).concat([1]));
    arr.forEach(function (x) {
      var w = Math.max(4, (x.tl / max) * 100);
      box.appendChild(el('<div class="row"><div class="nm">' + esc(x.ten) + '</div><div class="bar"><i style="width:' + w + '%"></i></div><div class="pc">' + pc(x.tl) + '</div></div>'));
    });
  }
  fillRank('r-topban', D.top_ban); fillRank('r-botban', D.bottom_ban, true);
  fillRank('r-topxa', D.top_xa); fillRank('r-topso', D.top_so);

  /* ---------- full 0% list ---------- */
  (function () {
    var box = document.getElementById('zero-box'); if (!box) return;
    var so = D.zero_list_so || [], xa = D.zero_list_xa || [];
    var tot = (D.zero && D.zero.tong) || (so.length + xa.length);
    var head = '<div class="zero-head"><span class="zero-stat">Tổng: ' + tot + ' đơn vị</span><span class="zero-stat">Sở, ngành: ' + so.length + '</span><span class="zero-stat">Xã, phường: ' + xa.length + '</span></div>';
    function col(title, arr) {
      var h = '<div class="zero-col"><h4>' + title + ' (' + arr.length + ')</h4><div class="zero-list">';
      if (!arr.length) { h += '<div class="zero-item"><span>—</span></div>'; }
      arr.forEach(function (n, idx) { h += '<div class="zero-item"><span class="i">' + (idx + 1) + '</span><span>' + esc(n) + '</span></div>'; });
      return h + '</div></div>';
    }
    box.innerHTML = head + '<div class="zero-grid">' + col('Khối sở, ngành, đơn vị', so) + col('Khối xã, phường, đặc khu', xa) + '</div>';
  })();

  /* ---------- stats popup modal ---------- */
  var modal = document.getElementById('lado-modal');
  function openModal(title, items) {
    document.getElementById('lm-title').textContent = title;
    var b = document.getElementById('lm-body');
    if (!items || !items.length) { b.innerHTML = '<p class="hint" style="margin:0">Không có đơn vị nào.</p>'; }
    else {
      b.innerHTML = '<ol class="lm-list">' + items.map(function (n) { return '<li>' + esc(n) + '</li>'; }).join('') + '</ol>';
    }
    modal.classList.add('on');
  }
  document.getElementById('lm-x').addEventListener('click', function () { modal.classList.remove('on'); });
  modal.addEventListener('click', function (e) { if (e.target === modal) modal.classList.remove('on'); });

  /* ---------- weekly plan stats ---------- */
  (function () {
    var host = document.getElementById('wk-stats'); if (!host) return;
    var tt = D.tuan_thongke;
    if (!tt) { document.querySelector('.wkstat-card').style.display = 'none'; return; }
    var kyEl = document.getElementById('wkstat-ky'); if (kyEl) kyEl.textContent = (tt.ky ? tt.ky + ' — ' : '') + 'mức độ đăng ký và thực hiện kế hoạch giải ngân trong tuần. Bấm mỗi ô để xem danh sách.';
    var tiles = [
      { k: 'tot', ic: '✅', cls: 'g', lab: 'Đăng ký & thực hiện tốt', note: 'đạt ≥ 80% KH tuần' },
      { k: 'phan', ic: '🔄', cls: 'b', lab: 'Đăng ký, thực hiện một phần', note: 'đạt < 80% KH tuần' },
      { k: 'khong_dk', ic: '⚠️', cls: 'a', lab: 'Không đăng ký KH tuần', note: 'không đăng ký kế hoạch tuần' },
      { k: 'dk_0', ic: '❌', cls: 'r', lab: 'Đăng ký nhưng thực hiện 0%', note: 'đăng ký nhưng chưa giải ngân' }
    ];
    tiles.forEach(function (t) {
      var obj = tt[t.k] || { count: 0, list: [] };
      var tile = el('<button class="wk-stat ' + t.cls + '"><div class="ws-ic">' + t.ic + '</div><div class="ws-num">' + (obj.count || 0) + '</div><div class="ws-lab">' + t.lab + '</div><div class="ws-note">' + t.note + '</div></button>');
      tile.addEventListener('click', function () { openModal(t.lab + ' (' + (obj.count || 0) + ' đơn vị)', obj.list || []); });
      host.appendChild(tile);
    });
  })();

  /* ---------- kiến nghị, đề xuất module ---------- */
  (function () {
    var card = document.getElementById('kn-card'); if (!card) return;
    var meta = LADO_AI.kn || {};
    if (!meta.has) { card.style.display = 'none'; return; }
    var by = meta.by_khoi || {};
    document.getElementById('kn-sub').innerHTML = 'Tổng hợp <b>' + (meta.total || 0) + '</b> kiến nghị, đề xuất theo từng dự án/đơn vị'
      + (meta.updated ? ' • cập nhật ' + esc(meta.updated) : '') + '. Nguồn: file Excel danh mục kế hoạch giải ngân theo tuần.';
    var ALL = [], shown = 0, STEP = 40, filtered = [];
    var listEl = document.getElementById('kn-list'), moreBtn = document.getElementById('kn-more');
    var qEl = document.getElementById('kn-q'), khoiEl = document.getElementById('kn-khoi'), nhomEl = document.getElementById('kn-nhom'), chipsEl = document.getElementById('kn-chips');
    function khoiBadge(k) { var c = k.indexOf('Ban') > -1 ? 'b' : (k.indexOf('Sở') > -1 ? 'a' : 'g'); return '<span class="tl-badge ' + c + '">' + esc(k) + '</span>'; }
    function row(x) {
      var f = '';
      if (x.kho_khan) f += '<div class="kn-f"><span>Khó khăn, vướng mắc</span>' + esc(x.kho_khan) + '</div>';
      if (x.tham_quyen) f += '<div class="kn-f"><span>Thẩm quyền giải quyết</span>' + esc(x.tham_quyen) + '</div>';
      if (x.kien_nghi) f += '<div class="kn-f kn-hl"><span>Kiến nghị, đề xuất</span>' + esc(x.kien_nghi) + '</div>';
      if (x.thoi_gian) f += '<div class="kn-f"><span>Thời gian hoàn thành</span>' + esc(x.thoi_gian) + '</div>';
      return '<div class="kn-item"><div class="kn-top">' + khoiBadge(x.khoi) + '<span class="kn-nhom">' + esc(x.nhom) + '</span></div>'
        + '<div class="kn-dv">' + esc(x.don_vi || '') + '</div>'
        + (x.du_an ? '<div class="kn-da">' + esc(x.du_an) + '</div>' : '') + f + '</div>';
    }
    function render(reset) {
      if (reset) { shown = 0; listEl.innerHTML = ''; }
      if (!filtered.length) { listEl.innerHTML = '<p class="hint" style="margin:0">Không có kiến nghị phù hợp bộ lọc.</p>'; moreBtn.style.display = 'none'; return; }
      var slice = filtered.slice(shown, shown + STEP);
      listEl.insertAdjacentHTML('beforeend', slice.map(row).join(''));
      shown += slice.length;
      moreBtn.style.display = shown < filtered.length ? '' : 'none';
      moreBtn.textContent = 'Xem thêm (' + (filtered.length - shown) + ')';
    }
    function filter() {
      var q = (qEl.value || '').toLowerCase().trim(), kk = khoiEl.value, nh = nhomEl.value;
      filtered = ALL.filter(function (x) {
        if (kk && x.khoi !== kk) return false;
        if (nh && (x.nhom || '').indexOf(nh) < 0) return false;
        if (q) { var hay = ((x.don_vi || '') + ' ' + (x.du_an || '') + ' ' + (x.kho_khan || '') + ' ' + (x.kien_nghi || '') + ' ' + (x.tham_quyen || '')).toLowerCase(); if (hay.indexOf(q) < 0) return false; }
        return true;
      });
      render(true);
    }
    function buildNhom() {
      var counts = {};
      ALL.forEach(function (x) { (x.nhom || '').split(/[,;]/).forEach(function (tok) { tok = tok.trim(); if (tok && tok.length < 42) counts[tok] = (counts[tok] || 0) + 1; }); });
      var arr = Object.keys(counts).map(function (k) { return [k, counts[k]]; }).sort(function (a, b) { return b[1] - a[1]; }).slice(0, 8);
      arr.forEach(function (p) { var o = document.createElement('option'); o.value = p[0]; o.textContent = p[0] + ' (' + p[1] + ')'; nhomEl.appendChild(o); });
      chipsEl.innerHTML = arr.slice(0, 6).map(function (p) { return '<button class="kn-chip" data-n="' + esc(p[0]) + '">' + esc(p[0]) + ' <b>' + p[1] + '</b></button>'; }).join('');
      chipsEl.querySelectorAll('.kn-chip').forEach(function (b) {
        b.addEventListener('click', function () {
          var on = b.classList.contains('on');
          chipsEl.querySelectorAll('.kn-chip').forEach(function (x) { x.classList.remove('on'); });
          if (on) { nhomEl.value = ''; } else { b.classList.add('on'); nhomEl.value = b.dataset.n; }
          filter();
        });
      });
    }
    qEl.addEventListener('input', filter); khoiEl.addEventListener('change', filter); nhomEl.addEventListener('change', filter);
    moreBtn.addEventListener('click', function () { render(false); });
    listEl.innerHTML = '<p class="hint" style="margin:0">Đang tải danh sách kiến nghị…</p>';
    var fd = new FormData(); fd.append('action', 'lado_kiennghi'); fd.append('nonce', LADO_AI.nonce);
    fetch(LADO_AI.ajax, { method: 'POST', body: fd }).then(function (r) { return r.json(); }).then(function (res) {
      if (res && res.success && res.data && res.data.items && res.data.items.length) {
        ALL = res.data.items; filtered = ALL.slice(); buildNhom(); render(true);
      } else { listEl.innerHTML = '<p class="hint" style="margin:0">Chưa có dữ liệu kiến nghị.</p>'; }
    }).catch(function () { listEl.innerHTML = '<p class="hint" style="margin:0">Không tải được dữ liệu kiến nghị.</p>'; });
  })();

  /* ---------- full detail tables (3 nhóm) ---------- */
  (function () {
    var wrap = document.getElementById('ld-table'); if (!wrap) return;
    var groups = {
      ban: { rows: D.all_ban || [], cols: ['kh', 'gn'], head: ['Chủ đầu tư (Ban QLDA)', 'Kế hoạch', 'Giải ngân', 'Tỷ lệ'] },
      so:  { rows: D.all_so || [],  cols: ['gn'],       head: ['Đơn vị', 'Giải ngân', 'Tỷ lệ'] },
      xa:  { rows: D.all_xa || [],  cols: ['kh', 'gn'], head: ['Xã / phường / đặc khu', 'Kế hoạch', 'Giải ngân', 'Tỷ lệ'] }
    };
    var setc = function (id, n) { var e = document.getElementById(id); if (e) e.textContent = n; };
    setc('cnt-ban', groups.ban.rows.length); setc('cnt-so', groups.so.rows.length); setc('cnt-xa', groups.xa.rows.length);
    var cur = 'ban';
    function tlCls(t) { return t >= 20 ? 'g' : (t < 5 ? 'r' : 'a'); }
    function render(g, filter) {
      var info = groups[g], f = (filter || '').toLowerCase().trim();
      var rows = info.rows.filter(function (r) { return !f || (r.ten || '').toLowerCase().indexOf(f) > -1; });
      var h = '<table class="ld-table"><thead><tr><th class="c-tt">#</th><th>' + info.head[0] + '</th>';
      info.cols.forEach(function (c, i) { h += '<th class="num">' + info.head[i + 1] + '</th>'; });
      h += '<th class="num">Tỷ lệ</th></tr></thead><tbody>';
      if (!rows.length) {
        h += '<tr><td colspan="6" style="text-align:center;color:var(--muted);padding:16px">Không tìm thấy đơn vị phù hợp.</td></tr>';
      }
      rows.forEach(function (r, idx) {
        h += '<tr><td class="c-tt">' + (idx + 1) + '</td><td>' + esc(r.ten) + '</td>';
        info.cols.forEach(function (c) { h += '<td class="num">' + (r[c] != null ? vn(r[c]) : '—') + '</td>'; });
        h += '<td class="num"><span class="tl-badge ' + tlCls(r.tl) + '">' + pc(r.tl) + '</span></td></tr>';
      });
      wrap.innerHTML = h + '</tbody></table>';
    }
    app.querySelectorAll('.ld-tab').forEach(function (b) {
      b.addEventListener('click', function () {
        app.querySelectorAll('.ld-tab').forEach(function (x) { x.classList.remove('on'); });
        b.classList.add('on'); cur = b.dataset.g;
        render(cur, document.getElementById('ld-search').value);
        wrap.scrollTop = 0;
      });
    });
    document.getElementById('ld-search').addEventListener('input', function () { render(cur, this.value); });
    render('ban', '');
  })();

  /* ---------- navigation menu (scroll to section + scroll-spy) ---------- */
  (function () {
    var track = document.getElementById('lado-nav'); if (!track) return;
    var items = [
      { id: 'sec-tong', ic: '📊', t: 'Tổng quan' },
      { id: 'sec-dl', ic: '📥', t: 'Tải báo cáo' },
      { id: 'sec-khoi', ic: '🎯', t: 'Tỷ lệ & nhóm' },
      { id: 'sec-nguon', ic: '💰', t: 'Nguồn vốn' },
      { id: 'sec-week', ic: '📅', t: 'Theo tuần' },
      { id: 'sec-rank', ic: '🏆', t: 'Xếp hạng' },
      { id: 'sec-detail', ic: '📋', t: 'Bảng chi tiết' },
      { id: 'sec-wkstat', ic: '🗓️', t: 'Kế hoạch tuần' },
      { id: 'sec-zero', ic: '🚫', t: 'Chưa giải ngân' },
      { id: 'kn-card', ic: '💡', t: 'Kiến nghị' }
    ].filter(function (it) { var n = document.getElementById(it.id); return n && n.style.display !== 'none'; });

    var nav = track.parentNode;
    var btns = items.map(function (it) {
      var b = el('<button class="ln-btn" data-id="' + it.id + '"><span class="ln-ic">' + it.ic + '</span>' + esc(it.t) + '</button>');
      b.addEventListener('click', function (e) {
        if (e && e.preventDefault) e.preventDefault();
        var target = document.getElementById(it.id); if (!target) return;
        var off = nav.offsetHeight + 12;
        // chọn đúng phần tử cuộn: .lado-app nếu nó cuộn được, ngược lại là cửa sổ
        if (app.scrollHeight > app.clientHeight + 4) {
          var top = app.scrollTop + (target.getBoundingClientRect().top - app.getBoundingClientRect().top) - off;
          app.scrollTo({ top: top < 0 ? 0 : top, behavior: 'smooth' });
        } else {
          var y = (window.pageYOffset || document.documentElement.scrollTop || 0) + target.getBoundingClientRect().top - off;
          window.scrollTo({ top: y < 0 ? 0 : y, behavior: 'smooth' });
        }
        setActive(it.id);
        centerBtn(b);
      });
      track.appendChild(b);
      return b;
    });

    // chỉ cuộn NGANG thanh menu để nút active vào giữa (không đụng cuộn dọc)
    function centerBtn(b) {
      var t = b.offsetLeft - (track.clientWidth - b.offsetWidth) / 2;
      track.scrollTo({ left: t < 0 ? 0 : t, behavior: 'smooth' });
    }

    function setActive(id) {
      btns.forEach(function (b) { b.classList.toggle('on', b.getAttribute('data-id') === id); });
    }

    // scroll-spy: chuyên mục nào gần đỉnh thì sáng
    var ticking = false;
    function spy() {
      ticking = false;
      var ar = app.getBoundingClientRect();
      var line = nav.offsetHeight + 28;
      var current = items[0] && items[0].id;
      for (var i = 0; i < items.length; i++) {
        var n = document.getElementById(items[i].id); if (!n) continue;
        if ((n.getBoundingClientRect().top - ar.top) <= line) { current = items[i].id; }
      }
      setActive(current);
    }
    app.addEventListener('scroll', function () { if (!ticking) { ticking = true; requestAnimationFrame(spy); } }, { passive: true });
    spy();

    // mũi tên cuộn menu (desktop khi tràn)
    function upd() {
      var prev = document.getElementById('ln-prev'), next = document.getElementById('ln-next');
      var sc = track.scrollWidth - track.clientWidth - 2;
      if (prev) prev.style.display = track.scrollLeft > 2 ? '' : 'none';
      if (next) next.style.display = track.scrollLeft < sc ? '' : 'none';
    }
    var prevB = document.getElementById('ln-prev'), nextB = document.getElementById('ln-next');
    if (prevB) prevB.addEventListener('click', function () { track.scrollBy({ left: -220, behavior: 'smooth' }); });
    if (nextB) nextB.addEventListener('click', function () { track.scrollBy({ left: 220, behavior: 'smooth' }); });
    track.addEventListener('scroll', upd, { passive: true });
    window.addEventListener('resize', upd);
    upd();
  })();

  /* ---------- download experience ---------- */
  var ov = document.getElementById('lado-ov'), ovProg = document.getElementById('ov-prog'), ovSub = document.getElementById('ov-sub');
  var dlTimer = null, dlCancelled = false;
  function steps(on){ app.querySelectorAll('.ov-step').forEach(function(s){ var i=+s.dataset.s; s.classList.toggle('on', i===on); s.classList.toggle('done', i<on); }); }
  app.querySelectorAll('.dlbtn').forEach(function (b) {
    b.addEventListener('click', function () { startDownload(b.dataset.type); });
  });
  document.getElementById('ov-cancel').addEventListener('click', function(){ dlCancelled = true; clearTimeout(dlTimer); ov.classList.remove('on'); });

  /* week download list */
  (function () {
    var host = document.getElementById('week-list'); if (!host) return;
    var weeks = LADO_AI.weeks || [];
    if (!weeks.length) { host.innerHTML = '<p class="hint" style="margin:0">Chưa có báo cáo tuần nào được đính kèm.</p>'; return; }
    weeks.slice().reverse().forEach(function (w) {
      var row = el('<div class="wk-item"><div class="wk-info"><span class="wk-ky">' + esc(w.ky) + '</span>'
        + (w.tl != null ? '<span class="tl-badge ' + (w.tl >= 20 ? 'g' : (w.tl < 5 ? 'r' : 'a')) + '">' + pc(w.tl) + '</span>' : '') + '</div>'
        + '<button class="wk-dl' + (w.has ? '' : ' off') + '" data-idx="' + w.idx + '">' + (w.has ? '⬇ Tải báo cáo' : 'Chưa có file') + '</button></div>');
      host.appendChild(row);
      var btn = row.querySelector('.wk-dl');
      if (w.has) { btn.addEventListener('click', function () { startDownload('week_idx', w.idx); }); }
      else { btn.disabled = true; }
    });
  })();

  function startDownload(type, idx) {
    dlCancelled = false;
    ov.classList.add('on'); ovProg.style.width = '0'; ovSub.textContent = 'Vui lòng đợi trong giây lát…';
    var seq = [0, 1, 2, 3], i = 0;
    steps(0); ovProg.style.width = '12%';
    function tick() {
      if (dlCancelled) return;
      steps(seq[i]); ovProg.style.width = (18 + i * 24) + '%';
      i++;
      if (i < seq.length) { dlTimer = setTimeout(tick, 850); }
      else { dlTimer = setTimeout(finish, 850); }
    }
    dlTimer = setTimeout(tick, 500);

    function finish() {
      if (dlCancelled) return;
      var fd = new FormData();
      fd.append('action', 'lado_report'); fd.append('nonce', LADO_AI.nonce); fd.append('type', type);
      if (idx != null) { fd.append('idx', idx); }
      fetch(LADO_AI.ajax, { method: 'POST', body: fd }).then(function (r) { return r.json(); }).then(function (res) {
        ovProg.style.width = '100%';
        app.querySelectorAll('.ov-step').forEach(function (s) { s.classList.add('done'); s.classList.remove('on'); });
        if (res && res.success && res.data && res.data.url) {
          ovSub.innerHTML = '✅ Hoàn tất! Đang tải <b>' + esc(res.data.name) + '</b>…';
          var a = document.createElement('a'); a.href = res.data.url; a.download = res.data.name || ''; document.body.appendChild(a); a.click(); a.remove();
          setTimeout(function () { ov.classList.remove('on'); }, 1400);
        } else {
          ovSub.innerHTML = '⚠️ ' + esc((res && res.data && res.data.message) || 'Chưa có file báo cáo.');
          setTimeout(function () { ov.classList.remove('on'); }, 2600);
        }
      }).catch(function () { ovSub.textContent = '⚠️ Lỗi kết nối. Vui lòng thử lại.'; setTimeout(function () { ov.classList.remove('on'); }, 2400); });
    }
  }

  /* ---------- chat ---------- */
  var fab = document.getElementById('lado-fab'), chat = document.getElementById('lado-chat');
  var body = document.getElementById('chat-body'), input = document.getElementById('chat-in'), send = document.getElementById('chat-send');
  var history = [], busy = false, greeted = false;

  fab.addEventListener('click', function () { chat.classList.add('on'); fab.style.display = 'none'; if (!greeted) greet(); input.focus(); });
  document.getElementById('chat-x').addEventListener('click', function () { chat.classList.remove('on'); fab.style.display = 'flex'; });

  function splitRow(s) { s = s.trim().replace(/^\|/, '').replace(/\|$/, ''); return s.split('|').map(function (x) { return x.trim(); }); }
  function inlineMd(t) {
    t = esc(t);
    t = t.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
    t = t.replace(/`([^`]+)`/g, '<code>$1</code>');
    t = t.replace(/(\d[\d.,]*\s?%)/g, '<span class="hl">$1</span>');
    t = t.replace(/\*/g, '');
    return t;
  }
  function mdToHtml(src) {
    var lines = String(src).replace(/\r/g, '').split('\n'), html = [], i = 0;
    while (i < lines.length) {
      var ln = lines[i];
      if (/^\s*$/.test(ln)) { i++; continue; }
      if (ln.indexOf('|') > -1 && i + 1 < lines.length && /^[\s|:\-]+$/.test(lines[i + 1]) && lines[i + 1].indexOf('-') > -1) {
        var head = splitRow(ln); i += 2; var rows = [];
        while (i < lines.length && lines[i].indexOf('|') > -1 && !/^\s*$/.test(lines[i])) { rows.push(splitRow(lines[i])); i++; }
        var t = '<table><thead><tr>' + head.map(function (h) { return '<th>' + inlineMd(h) + '</th>'; }).join('') + '</tr></thead><tbody>';
        rows.forEach(function (r) { t += '<tr>' + r.map(function (c) { var num = /\d/.test(c) && /^[\d.,%\s+\-]+$/.test(c.trim()); return '<td class="' + (num ? 'num' : '') + '">' + inlineMd(c) + '</td>'; }).join('') + '</tr>'; });
        html.push(t + '</tbody></table>'); continue;
      }
      var hm = ln.match(/^\s*#{1,4}\s+(.*)$/);
      if (hm) { html.push('<h4>' + inlineMd(hm[1]) + '</h4>'); i++; continue; }
      if (/^\s*[-*•]\s+/.test(ln)) {
        var items = [];
        while (i < lines.length && /^\s*[-*•]\s+/.test(lines[i])) { items.push(inlineMd(lines[i].replace(/^\s*[-*•]\s+/, ''))); i++; }
        html.push('<ul>' + items.map(function (x) { return '<li>' + x + '</li>'; }).join('') + '</ul>'); continue;
      }
      if (/^\s*\d+[.)]\s+/.test(ln)) {
        var its = [];
        while (i < lines.length && /^\s*\d+[.)]\s+/.test(lines[i])) { its.push(inlineMd(lines[i].replace(/^\s*\d+[.)]\s+/, ''))); i++; }
        html.push('<ol>' + its.map(function (x) { return '<li>' + x + '</li>'; }).join('') + '</ol>'); continue;
      }
      var para = [ln]; i++;
      while (i < lines.length && !/^\s*$/.test(lines[i]) && lines[i].indexOf('|') < 0 && !/^\s*[-*•]\s+/.test(lines[i]) && !/^\s*\d+[.)]\s+/.test(lines[i]) && !/^\s*#{1,4}\s+/.test(lines[i])) { para.push(lines[i]); i++; }
      html.push('<p>' + para.map(inlineMd).join('<br>') + '</p>');
    }
    return html.join('');
  }

  function bubble(text, cls) { var m = el('<div class="msg ' + cls + '"></div>'); if (cls === 'bot') { m.innerHTML = mdToHtml(text); } else { m.textContent = text; } body.appendChild(m); body.scrollTop = body.scrollHeight; return m; }
  function greet() {
    greeted = true;
    bubble('Xin chào! Tôi là ' + NAME + ', trợ lý ảo về giải ngân vốn đầu tư công tỉnh Lâm Đồng. Bạn muốn hỏi điều gì?', 'bot');
    var sug = el('<div class="chips"></div>');
    ['Tỷ lệ giải ngân toàn tỉnh hiện nay?', 'Khối nào giải ngân thấp nhất?', '5 Ban QLDA kém nhất là ai?', 'So với kế hoạch Thủ tướng giao đạt bao nhiêu?'].forEach(function (q) {
      var c = el('<button class="chip"></button>'); c.textContent = q; c.addEventListener('click', function () { input.value = q; doSend(); }); sug.appendChild(c);
    });
    body.appendChild(sug); body.scrollTop = body.scrollHeight;
  }
  input.addEventListener('input', function () { this.style.height = 'auto'; this.style.height = Math.min(90, this.scrollHeight) + 'px'; });
  input.addEventListener('keydown', function (e) { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); doSend(); } });
  send.addEventListener('click', doSend);

  function doSend() {
    var q = input.value.trim(); if (!q || busy) return;
    var chips = body.querySelector('.chips'); if (chips) chips.remove();
    bubble(q, 'me'); history.push({ role: 'user', content: q });
    input.value = ''; input.style.height = 'auto';
    busy = true; send.disabled = true;
    var typ = el('<div class="typing"><span></span><span></span><span></span></div>'); body.appendChild(typ); body.scrollTop = body.scrollHeight;

    var fd = new FormData();
    fd.append('action', 'lado_chat'); fd.append('nonce', LADO_AI.nonce); fd.append('history', JSON.stringify(history));
    fetch(LADO_AI.ajax, { method: 'POST', body: fd }).then(function (r) { return r.json(); }).then(function (res) {
      typ.remove();
      if (res && res.success) { bubble(res.data.reply, 'bot'); history.push({ role: 'assistant', content: res.data.reply }); }
      else { bubble('LaDo-AI gặp lỗi kết nối.', 'err'); }
    }).catch(function () { typ.remove(); bubble('LaDo-AI gặp lỗi kết nối.', 'err'); })
      .finally(function () { busy = false; send.disabled = false; input.focus(); });
  }
})();
