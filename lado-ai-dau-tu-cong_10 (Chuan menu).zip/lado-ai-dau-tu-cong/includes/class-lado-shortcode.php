<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class LaDo_AI_Shortcode {

	public function __construct() {
		add_shortcode( 'lado_ai_dashboard', array( $this, 'render' ) );
	}

	public function render( $atts ) {
		$o = get_option( LADO_AI_OPT, lado_ai_default_settings() );
		$data = json_decode( $o['data'], true );
		if ( ! is_array( $data ) ) { $data = array(); }

		$css_path = LADO_AI_DIR . 'assets/css/lado-app.css';
		$js_path  = LADO_AI_DIR . 'assets/js/lado-app.js';
		$css_ver  = file_exists( $css_path ) ? (string) filemtime( $css_path ) : LADO_AI_VERSION;
		$js_ver   = file_exists( $js_path ) ? (string) filemtime( $js_path ) : LADO_AI_VERSION;

		wp_enqueue_script( 'chartjs', 'https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js', array(), '4.4.1', true );
		wp_enqueue_style( 'lado-app', LADO_AI_URL . 'assets/css/lado-app.css', array(), $css_ver );
		wp_enqueue_script( 'lado-app', LADO_AI_URL . 'assets/js/lado-app.js', array( 'chartjs' ), $js_ver, true );

		$weeks = array();
		foreach ( (array) ( $o['weeks'] ?? array() ) as $i => $wk ) {
			$url = ! empty( $wk['file'] ) ? wp_get_attachment_url( $wk['file'] ) : '';
			$weeks[] = array(
				'ky'   => isset( $wk['ky'] ) ? $wk['ky'] : '',
				'tl'   => isset( $wk['tl'] ) ? (float) $wk['tl'] : 0,
				'idx'  => $i,
				'has'  => $url ? true : false,
				'name' => $url ? basename( $url ) : '',
			);
		}

		$avatar = ! empty( $o['avatar'] ) ? wp_get_attachment_image_url( $o['avatar'], 'thumbnail' ) : '';
		$kn = lado_ai_get_kiennghi();
		$kn_meta = array(
			'has'     => ! empty( $kn['items'] ),
			'total'   => isset( $kn['total'] ) ? (int) $kn['total'] : 0,
			'updated' => isset( $kn['updated'] ) ? $kn['updated'] : '',
			'by_khoi' => isset( $kn['by_khoi'] ) ? $kn['by_khoi'] : array(),
		);

		wp_localize_script( 'lado-app', 'LADO_AI', array(
			'ajax'      => admin_url( 'admin-ajax.php' ),
			'nonce'     => wp_create_nonce( 'lado_ai_front' ),
			'name'      => $o['assistant_name'],
			'avatar'    => $avatar,
			'data'      => $data,
			'has_week'  => ! empty( $o['report_week'] ),
			'has_month' => ! empty( $o['report_month'] ),
			'weeks'     => $weeks,
			'kn'        => $kn_meta,
		) );

		ob_start();
		?>
		<div id="lado-app" class="lado-app" data-assistant="<?php echo esc_attr( $o['assistant_name'] ); ?>">
			<div class="lado-loading"><div class="lado-spinner"></div><p>Đang khởi tạo bảng điều khiển…</p></div>
		</div>
		<?php
		return ob_get_clean();
	}
}
