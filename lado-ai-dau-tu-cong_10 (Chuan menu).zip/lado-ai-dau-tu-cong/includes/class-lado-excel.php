<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Đọc file Excel "Danh mục kế hoạch giải ngân theo tuần" và trích các
 * kiến nghị, đề xuất (cùng khó khăn, vướng mắc) từ 3 sheet chi tiết.
 * Chỉ dùng ZipArchive + regex (không cần thư viện ngoài).
 */
class LaDo_AI_Excel {

	/* Cột cố định theo mẫu (1-based): có dò theo từ khóa để phòng lệch nhẹ */
	const COL = array(
		'ten'  => 2,   // Danh mục dự án / Xã,phường
		'cdt'  => 3,   // Chủ đầu tư
		'nhom' => 225, // Nhóm khó khăn, vướng mắc
		'kk'   => 226, // Khó khăn vướng mắc / Nội dung vướng mắc
		'tq'   => 227, // Thẩm quyền giải quyết
		'kn'   => 228, // Kiến nghị, đề xuất
		'tg'   => 230, // Thời gian hoàn thành giải quyết
		'gc'   => 231, // Ghi chú
	);

	protected static function col_to_idx( $ref ) {
		if ( ! preg_match( '/^([A-Z]+)/', $ref, $m ) ) { return 0; }
		$s = $m[1]; $n = 0;
		$len = strlen( $s );
		for ( $i = 0; $i < $len; $i++ ) { $n = $n * 26 + ( ord( $s[ $i ] ) - 64 ); }
		return $n;
	}

	protected static function load_shared( $zip ) {
		$out = array();
		$xml = $zip->getFromName( 'xl/sharedStrings.xml' );
		if ( ! $xml ) { return $out; }
		if ( preg_match_all( '#<si>(.*?)</si>#s', $xml, $m ) ) {
			foreach ( $m[1] as $si ) {
				$txt = '';
				if ( preg_match_all( '#<t[^>]*>(.*?)</t>#s', $si, $t ) ) { $txt = implode( '', $t[1] ); }
				$out[] = html_entity_decode( wp_strip_all_tags( $txt ), ENT_QUOTES, 'UTF-8' );
			}
		}
		return $out;
	}

	protected static function sheet_map( $zip ) {
		$map = array();
		$wb  = $zip->getFromName( 'xl/workbook.xml' );
		$rel = $zip->getFromName( 'xl/_rels/workbook.xml.rels' );
		if ( ! $wb || ! $rel ) { return $map; }
		$rid = array();
		if ( preg_match_all( '#Id="([^"]+)"[^>]*Target="([^"]+)"#', $rel, $mr, PREG_SET_ORDER ) ) {
			foreach ( $mr as $r ) {
				$t = $r[2];
				if ( $t && '/' !== $t[0] ) { $t = 'xl/' . $t; }
				$rid[ $r[1] ] = $t;
			}
		}
		if ( preg_match_all( '#<sheet[^>]*name="([^"]+)"[^>]*r:id="([^"]+)"#', $wb, $ms, PREG_SET_ORDER ) ) {
			foreach ( $ms as $s ) {
				$name = html_entity_decode( $s[1], ENT_QUOTES, 'UTF-8' );
				if ( isset( $rid[ $s[2] ] ) ) { $map[ $name ] = $rid[ $s[2] ]; }
			}
		}
		return $map;
	}

	protected static function read_sheet( $zip, $file, $shared ) {
		$rows = array();
		$xml  = $zip->getFromName( $file );
		if ( ! $xml ) { return $rows; }
		if ( ! preg_match_all( '#<row[^>]*?r="(\d+)"[^>]*?>(.*?)</row>#s', $xml, $mr, PREG_SET_ORDER ) ) { return $rows; }
		foreach ( $mr as $rm ) {
			$rn = (int) $rm[1];
			$cells = array();
			if ( preg_match_all( '#<c[^>]*?r="([A-Z]+)\d+"([^>]*?)>(.*?)</c>#s', $rm[2], $mc, PREG_SET_ORDER ) ) {
				foreach ( $mc as $cm ) {
					$ci = self::col_to_idx( $cm[1] );
					$attr = $cm[2]; $body = $cm[3]; $val = '';
					if ( preg_match( '#<v>(.*?)</v>#s', $body, $v ) ) {
						$val = $v[1];
						if ( false !== strpos( $attr, 't="s"' ) && ctype_digit( $val ) ) {
							$idx = (int) $val;
							$val = isset( $shared[ $idx ] ) ? $shared[ $idx ] : '';
						}
					} elseif ( preg_match( '#<t[^>]*>(.*?)</t>#s', $body, $t ) ) {
						$val = html_entity_decode( wp_strip_all_tags( $t[1] ), ENT_QUOTES, 'UTF-8' );
					}
					$cells[ $ci ] = trim( (string) $val );
				}
			}
			$rows[ $rn ] = $cells;
		}
		return $rows;
	}

	protected static function is_num( $s ) {
		$s = str_replace( array( '.', ',', ' ' ), '', (string) $s );
		return '' !== $s && ctype_digit( $s );
	}
	protected static function is_junk_nhom( $n ) {
		if ( '' === trim( (string) $n ) ) { return true; }
		if ( self::is_num( $n ) ) { return true; }
		if ( false !== mb_stripos( $n, 'Không có' ) ) { return true; }
		$l = mb_strtolower( trim( $n ) );
		return in_array( $l, array( 'không', 'không có vướng mắc', 'không có' ), true );
	}

	// Dò cột theo từ khóa trong các hàng tiêu đề (phòng khi mẫu đổi cột)
	protected static function detect_cols( $rows ) {
		$kw = array(
			'nhom' => 'Nhóm khó khăn', 'kk' => 'Khó khăn vướng mắc', 'kk2' => 'Nội dung vướng mắc',
			'tq' => 'Thẩm quyền giải quyết', 'kn' => 'Kiến nghị', 'tg' => 'Thời gian hoàn thành giải',
			'ten' => 'Danh mục dự án', 'ten2' => 'Xã/phường', 'cdt' => 'Chủ đầu tư', 'gc' => 'Ghi chú',
		);
		$found = array();
		for ( $rn = 3; $rn <= 9; $rn++ ) {
			if ( empty( $rows[ $rn ] ) ) { continue; }
			foreach ( $rows[ $rn ] as $ci => $v ) {
				if ( '' === $v ) { continue; }
				foreach ( $kw as $k => $w ) {
					if ( ! isset( $found[ $k ] ) && false !== mb_stripos( $v, $w ) ) { $found[ $k ] = $ci; }
				}
			}
		}
		return $found;
	}

	/**
	 * @return array{updated:string,total:int,by_khoi:array,items:array}|null
	 */
	public static function parse_proposals( $path ) {
		if ( ! class_exists( 'ZipArchive' ) ) { return null; }
		$zip = new ZipArchive();
		if ( true !== $zip->open( $path ) ) { return null; }
		$shared = self::load_shared( $zip );
		$map    = self::sheet_map( $zip );

		$items = array();
		$by    = array( 'Ban QLDA' => 0, 'Sở, ngành' => 0, 'Xã, phường, đặc khu' => 0 );
		foreach ( $map as $name => $file ) {
			$khoi = '';
			if ( false !== mb_stripos( $name, 'Ban QLDA' ) ) { $khoi = 'Ban QLDA'; }
			elseif ( false !== mb_stripos( $name, 'Sở' ) ) { $khoi = 'Sở, ngành'; }
			elseif ( false !== mb_stripos( $name, 'Xã' ) ) { $khoi = 'Xã, phường, đặc khu'; }
			else { continue; }

			$rows = self::read_sheet( $zip, $file, $shared );
			if ( empty( $rows ) ) { continue; }

			$c = self::COL;
			$det = self::detect_cols( $rows );
			// dùng cột dò được nếu hợp lệ, nếu không giữ cột mặc định
			if ( isset( $det['kn'] ) ) { $c['kn'] = $det['kn']; }
			if ( isset( $det['nhom'] ) ) { $c['nhom'] = $det['nhom']; }
			if ( isset( $det['tq'] ) ) { $c['tq'] = $det['tq']; }
			if ( isset( $det['tg'] ) ) { $c['tg'] = $det['tg']; }
			if ( isset( $det['kk'] ) ) { $c['kk'] = $det['kk']; } elseif ( isset( $det['kk2'] ) ) { $c['kk'] = $det['kk2']; }
			if ( isset( $det['ten'] ) ) { $c['ten'] = $det['ten']; } elseif ( isset( $det['ten2'] ) ) { $c['ten'] = $det['ten2']; }
			if ( isset( $det['cdt'] ) ) { $c['cdt'] = $det['cdt']; }

			$cur = '';
			$max = max( array_keys( $rows ) );
			for ( $r = 9; $r <= $max; $r++ ) {
				if ( empty( $rows[ $r ] ) ) { continue; }
				$rd  = $rows[ $r ];
				$ten = isset( $rd[ $c['ten'] ] ) ? $rd[ $c['ten'] ] : '';
				$cdt = isset( $rd[ $c['cdt'] ] ) ? $rd[ $c['cdt'] ] : '';
				$stt = isset( $rd[1] ) ? $rd[1] : '';
				if ( self::is_num( $stt ) && '' !== $ten && '' === $cdt ) { $cur = $ten; }
				$nhom = isset( $rd[ $c['nhom'] ] ) ? $rd[ $c['nhom'] ] : '';
				$kk   = isset( $rd[ $c['kk'] ] ) ? $rd[ $c['kk'] ] : '';
				$tq   = isset( $rd[ $c['tq'] ] ) ? $rd[ $c['tq'] ] : '';
				$kn   = isset( $rd[ $c['kn'] ] ) ? $rd[ $c['kn'] ] : '';
				$tg   = isset( $rd[ $c['tg'] ] ) ? $rd[ $c['tg'] ] : '';
				if ( ( '' !== $kn || '' !== $kk ) && ! self::is_junk_nhom( $nhom ) ) {
					$items[] = array(
						'khoi'       => $khoi,
						'don_vi'     => '' !== $cdt ? $cdt : $cur,
						'du_an'      => $ten,
						'nhom'       => $nhom,
						'kho_khan'   => $kk,
						'tham_quyen' => $tq,
						'kien_nghi'  => $kn,
						'thoi_gian'  => $tg,
					);
					if ( isset( $by[ $khoi ] ) ) { $by[ $khoi ]++; }
				}
			}
		}
		$zip->close();
		if ( empty( $items ) ) { return null; }

		return array(
			'updated' => date_i18n( 'd/m/Y H:i' ),
			'total'   => count( $items ),
			'by_khoi' => $by,
			'items'   => $items,
		);
	}
}
