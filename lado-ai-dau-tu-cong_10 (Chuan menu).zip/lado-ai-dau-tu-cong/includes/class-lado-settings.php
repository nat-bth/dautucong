<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class LaDo_AI_Settings {

	public function __construct() {
		add_action( 'admin_menu', array( $this, 'menu' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'assets' ) );
		add_action( 'admin_post_lado_ai_save', array( $this, 'save' ) );
	}

	public function menu() {
		add_menu_page(
			'LaDo-AI', 'LaDo-AI', 'manage_options', 'lado-ai',
			array( $this, 'render' ), 'dashicons-chart-area', 58
		);
	}

	public function assets( $hook ) {
		if ( 'toplevel_page_lado-ai' !== $hook ) { return; }
		wp_enqueue_media();
		$acss = LADO_AI_DIR . 'assets/css/lado-admin.css';
		$ajs  = LADO_AI_DIR . 'assets/js/lado-admin.js';
		wp_enqueue_style( 'lado-admin', LADO_AI_URL . 'assets/css/lado-admin.css', array(), file_exists( $acss ) ? (string) filemtime( $acss ) : LADO_AI_VERSION );
		wp_enqueue_script( 'lado-admin', LADO_AI_URL . 'assets/js/lado-admin.js', array( 'jquery' ), file_exists( $ajs ) ? (string) filemtime( $ajs ) : LADO_AI_VERSION, true );
	}

	public function save() {
		if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'Không đủ quyền.' ); }
		check_admin_referer( 'lado_ai_save' );

		$o = get_option( LADO_AI_OPT, lado_ai_default_settings() );

		$o['api_key']        = isset( $_POST['api_key'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['api_key'] ) ) ) : '';
		$o['model']          = isset( $_POST['model'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['model'] ) ) ) : 'claude-opus-4-8';
		$o['max_tokens']     = isset( $_POST['max_tokens'] ) ? max( 256, min( 8000, (int) $_POST['max_tokens'] ) ) : 1200;
		$o['temperature']    = isset( $_POST['temperature'] ) ? (string) floatval( $_POST['temperature'] ) : '0.2';
		$o['assistant_name'] = isset( $_POST['assistant_name'] ) ? sanitize_text_field( wp_unslash( $_POST['assistant_name'] ) ) : 'LaDo-AI';
		$o['avatar']         = isset( $_POST['avatar'] ) ? (int) $_POST['avatar'] : 0;
		$o['persona']        = isset( $_POST['persona'] ) ? sanitize_textarea_field( wp_unslash( $_POST['persona'] ) ) : '';
		$o['rate_limit']     = isset( $_POST['rate_limit'] ) ? max( 1, (int) $_POST['rate_limit'] ) : 20;
		$o['report_week']    = isset( $_POST['report_week'] ) ? (int) $_POST['report_week'] : 0;
		$o['report_month']   = isset( $_POST['report_month'] ) ? (int) $_POST['report_month'] : 0;

		// Báo cáo theo tuần (danh sách): {ky, tl, file}
		if ( isset( $_POST['weeks_json'] ) ) {
			$rows = json_decode( wp_unslash( $_POST['weeks_json'] ), true );
			$weeks = array();
			if ( is_array( $rows ) ) {
				foreach ( $rows as $r ) {
					$ky = isset( $r['ky'] ) ? sanitize_text_field( $r['ky'] ) : '';
					if ( '' === trim( $ky ) ) { continue; }
					$weeks[] = array(
						'ky'   => $ky,
						'tl'   => isset( $r['tl'] ) ? (float) $r['tl'] : 0,
						'file' => isset( $r['file'] ) ? (int) $r['file'] : 0,
					);
				}
			}
			$o['weeks'] = $weeks;
		}

		// Convert báo cáo Word -> số liệu biểu đồ
		if ( ! empty( $_FILES['data_docx']['name'] ) && empty( $_FILES['data_docx']['error'] ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
			$moved = wp_handle_upload( $_FILES['data_docx'], array( 'test_form' => false, 'mimes' => array( 'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' ) ) );
			if ( isset( $moved['file'] ) ) {
				$parsed = LaDo_AI_Data::parse_report( $moved['file'] );
				@unlink( $moved['file'] );
				if ( $parsed && ( isset( $parsed['tong'] ) || isset( $parsed['khoi'] ) ) ) {
					$cur = json_decode( $o['data'], true );
					if ( ! is_array( $cur ) ) { $cur = array(); }
					$o['data'] = wp_json_encode( array_merge( $cur, $parsed ), JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT );
					$notice = 'imported';
				} else {
					$notice = 'importfail';
				}
			}
		}

		// Convert báo cáo TUẦN -> thống kê kế hoạch tuần
		if ( ! isset( $notice ) && ! empty( $_FILES['tuan_docx']['name'] ) && empty( $_FILES['tuan_docx']['error'] ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
			$moved = wp_handle_upload( $_FILES['tuan_docx'], array( 'test_form' => false, 'mimes' => array( 'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' ) ) );
			if ( isset( $moved['file'] ) ) {
				$tt = LaDo_AI_Data::parse_weekly( $moved['file'] );
				@unlink( $moved['file'] );
				if ( $tt && ( ! empty( $tt['tot']['count'] ) || ! empty( $tt['khong_dk']['count'] ) || ! empty( $tt['dk_0']['count'] ) || ! empty( $tt['phan']['count'] ) ) ) {
					$cur = json_decode( $o['data'], true );
					if ( ! is_array( $cur ) ) { $cur = array(); }
					$cur['tuan_thongke'] = $tt;
					$o['data'] = wp_json_encode( $cur, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT );
					$notice = 'imported_week';
				} else {
					$notice = 'importfail';
				}
			}
		}

		// Convert Excel "Danh mục kế hoạch theo tuần" -> kiến nghị, đề xuất
		if ( ! isset( $notice ) && ! empty( $_FILES['kiennghi_xlsx']['name'] ) && empty( $_FILES['kiennghi_xlsx']['error'] ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
			$moved = wp_handle_upload( $_FILES['kiennghi_xlsx'], array( 'test_form' => false, 'mimes' => array( 'xlsx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' ) ) );
			if ( isset( $moved['file'] ) ) {
				$kn = LaDo_AI_Excel::parse_proposals( $moved['file'] );
				@unlink( $moved['file'] );
				if ( $kn && ! empty( $kn['items'] ) ) {
					update_option( LADO_AI_KN_OPT, $kn, false );
					$notice = 'imported_kn';
				} else {
					$notice = 'importfail_kn';
				}
			}
		}

		// Validate JSON data field (chỉ khi không nhập từ Word ở lần này)
		if ( ! isset( $notice ) && isset( $_POST['data'] ) ) {
			$raw = wp_unslash( $_POST['data'] );
			$decoded = json_decode( $raw, true );
			if ( null !== $decoded ) {
				$o['data'] = wp_json_encode( $decoded, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT );
				$notice = 'saved';
			} else {
				$notice = 'badjson';
			}
		}

		// Knowledge-base file upload (docx/xlsx/csv/txt) -> extract text
		if ( ! empty( $_FILES['kb_file']['name'] ) && empty( $_FILES['kb_file']['error'] ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
			$allowed = array(
				'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
				'xlsx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
				'csv'  => 'text/csv',
				'txt'  => 'text/plain',
			);
			$moved = wp_handle_upload( $_FILES['kb_file'], array( 'test_form' => false, 'mimes' => $allowed ) );
			if ( isset( $moved['file'] ) ) {
				$text = LaDo_AI_Data::extract( $moved['file'] );
				$name = sanitize_file_name( $_FILES['kb_file']['name'] );
				if ( ! empty( $_POST['kb_append'] ) ) {
					$o['kb_text'] = trim( $o['kb_text'] . "\n\n===== " . $name . " =====\n" . $text );
				} else {
					$o['kb_text'] = "===== " . $name . " =====\n" . $text;
					$o['kb_files'] = array();
				}
				$o['kb_files'][] = array( 'name' => $name, 'len' => mb_strlen( $text ) );
				@unlink( $moved['file'] );
			}
		}
		if ( isset( $_POST['kb_clear'] ) ) { $o['kb_text'] = ''; $o['kb_files'] = array(); }

		update_option( LADO_AI_OPT, $o );
		$notice = isset( $notice ) ? $notice : 'saved';
		wp_safe_redirect( admin_url( 'admin.php?page=lado-ai&notice=' . $notice ) );
		exit;
	}

	public function render() {
		$o = get_option( LADO_AI_OPT, lado_ai_default_settings() );
		$notice = isset( $_GET['notice'] ) ? sanitize_text_field( wp_unslash( $_GET['notice'] ) ) : '';
		$week_url  = $o['report_week'] ? wp_get_attachment_url( $o['report_week'] ) : '';
		$month_url = $o['report_month'] ? wp_get_attachment_url( $o['report_month'] ) : '';
		?>
		<div class="wrap lado-admin">
			<h1>⚙️ LaDo-AI — Cấu hình</h1>
			<?php if ( 'saved' === $notice ) : ?>
				<div class="notice notice-success is-dismissible"><p>Đã lưu cấu hình.</p></div>
			<?php elseif ( 'imported' === $notice ) : ?>
				<div class="notice notice-success is-dismissible"><p>✅ Đã nhập số liệu biểu đồ từ báo cáo THÁNG và lưu lại.</p></div>
			<?php elseif ( 'imported_week' === $notice ) : ?>
				<div class="notice notice-success is-dismissible"><p>✅ Đã nhập thống kê kế hoạch tuần từ báo cáo TUẦN và lưu lại.</p></div>
			<?php elseif ( 'imported_kn' === $notice ) : ?>
				<?php $knc = lado_ai_get_kiennghi(); ?>
				<div class="notice notice-success is-dismissible"><p>✅ Đã nhập <strong><?php echo (int) ( $knc['total'] ?? 0 ); ?></strong> kiến nghị, đề xuất từ file Excel.</p></div>
			<?php elseif ( 'importfail_kn' === $notice ) : ?>
				<div class="notice notice-error is-dismissible"><p>Không đọc được kiến nghị từ file Excel. Hãy kiểm tra file đúng mẫu "Danh mục kế hoạch giải ngân theo tuần".</p></div>
			<?php elseif ( 'importfail' === $notice ) : ?>
				<div class="notice notice-error is-dismissible"><p>Không đọc được số liệu từ file Word. Hãy đảm bảo đây là báo cáo có bảng tổng hợp theo khối (dòng "TOÀN TỈNH").</p></div>
			<?php elseif ( 'badjson' === $notice ) : ?>
				<div class="notice notice-error is-dismissible"><p>Dữ liệu JSON không hợp lệ — các mục khác đã lưu, riêng phần số liệu biểu đồ chưa được cập nhật.</p></div>
			<?php endif; ?>

			<p class="lado-help">Chèn bảng điều khiển vào bất kỳ trang nào bằng shortcode: <code>[lado_ai_dashboard]</code></p>

			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" enctype="multipart/form-data">
				<input type="hidden" name="action" value="lado_ai_save" />
				<?php wp_nonce_field( 'lado_ai_save' ); ?>

				<div class="lado-card">
					<h2>1) Kết nối Claude API</h2>
					<table class="form-table">
						<tr><th>API key</th><td>
							<input type="password" name="api_key" value="<?php echo esc_attr( $o['api_key'] ); ?>" class="regular-text" autocomplete="off" placeholder="sk-ant-..." />
							<p class="description">Khóa lưu phía máy chủ, không hiển thị ra trình duyệt người dùng.</p>
						</td></tr>
						<tr><th>Mô hình Claude (nhập thủ công)</th><td>
							<input type="text" name="model" value="<?php echo esc_attr( $o['model'] ); ?>" class="regular-text" placeholder="claude-opus-4-8" />
							<p class="description">Ví dụ: <code>claude-opus-4-8</code>, <code>claude-sonnet-4-6</code>, <code>claude-haiku-4-5-20251001</code>…</p>
						</td></tr>
						<tr><th>max_tokens</th><td><input type="number" name="max_tokens" value="<?php echo esc_attr( $o['max_tokens'] ); ?>" min="256" max="8000" /></td></tr>
						<tr><th>temperature</th><td><input type="number" step="0.1" min="0" max="1" name="temperature" value="<?php echo esc_attr( $o['temperature'] ); ?>" /></td></tr>
						<tr><th>Giới hạn (req/10 phút/IP)</th><td><input type="number" name="rate_limit" value="<?php echo esc_attr( $o['rate_limit'] ); ?>" min="1" /></td></tr>
					</table>
				</div>

				<div class="lado-card">
					<h2>2) Trợ lý ảo</h2>
					<table class="form-table">
						<tr><th>Tên trợ lý</th><td><input type="text" name="assistant_name" value="<?php echo esc_attr( $o['assistant_name'] ); ?>" class="regular-text" /></td></tr>
						<tr><th>Logo / icon trợ lý</th><td>
							<?php $av_url = ! empty( $o['avatar'] ) ? wp_get_attachment_image_url( $o['avatar'], 'thumbnail' ) : ''; ?>
							<input type="hidden" id="avatar" name="avatar" value="<?php echo esc_attr( $o['avatar'] ); ?>" />
							<img id="avatar-preview" src="<?php echo esc_url( $av_url ); ?>" style="<?php echo $av_url ? '' : 'display:none;'; ?>width:46px;height:46px;border-radius:50%;object-fit:cover;vertical-align:middle;margin-right:10px;border:1px solid #cdd9ea" />
							<button type="button" class="button lado-pick-img" data-target="avatar">Chọn ảnh…</button>
							<button type="button" class="button lado-clear-img" data-target="avatar">Xóa</button>
							<p class="description">Ảnh vuông (vd 256×256). Nếu để trống sẽ dùng biểu tượng mặc định.</p>
						</td></tr>
						<tr><th>Tính cách / chỉ dẫn (system prompt)</th><td>
							<textarea name="persona" rows="5" class="large-text"><?php echo esc_textarea( $o['persona'] ); ?></textarea>
						</td></tr>
					</table>
				</div>

				<div class="lado-card">
					<h2>3) Cơ sở dữ liệu ngữ cảnh (Excel / Word)</h2>
					<p class="description">Tải lên file <code>.docx</code>, <code>.xlsx</code>, <code>.csv</code> hoặc <code>.txt</code>. Hệ thống trích xuất văn bản làm ngữ cảnh để LaDo-AI trả lời.</p>
					<p>
						<input type="file" name="kb_file" accept=".docx,.xlsx,.csv,.txt" />
						<label style="margin-left:10px"><input type="checkbox" name="kb_append" value="1" /> Nối thêm vào dữ liệu hiện có</label>
					</p>
					<p><strong>Đã nạp:</strong>
						<?php if ( ! empty( $o['kb_files'] ) ) : ?>
							<?php foreach ( $o['kb_files'] as $f ) : ?>
								<span class="lado-chip"><?php echo esc_html( $f['name'] ); ?> (<?php echo esc_html( number_format_i18n( $f['len'] ) ); ?> ký tự)</span>
							<?php endforeach; ?>
						<?php else : ?> <em>chưa có</em> <?php endif; ?>
					</p>
					<p><label><input type="checkbox" name="kb_clear" value="1" /> Xóa toàn bộ dữ liệu ngữ cảnh</label></p>
				</div>

				<div class="lado-card">
					<h2>4) File báo cáo cho nút tải về</h2>
					<p class="description">Quản trị viên đính kèm file báo cáo định kỳ; người dùng bấm nút để tải.</p>
					<table class="form-table">
						<tr><th>Báo cáo TUẦN (.docx)</th><td>
							<input type="hidden" id="report_week" name="report_week" value="<?php echo esc_attr( $o['report_week'] ); ?>" />
							<button type="button" class="button lado-pick" data-target="report_week">Chọn file…</button>
							<span class="lado-file-name" data-for="report_week"><?php echo $week_url ? esc_html( basename( $week_url ) ) : 'chưa chọn'; ?></span>
						</td></tr>
						<tr><th>Báo cáo THÁNG (.docx)</th><td>
							<input type="hidden" id="report_month" name="report_month" value="<?php echo esc_attr( $o['report_month'] ); ?>" />
							<button type="button" class="button lado-pick" data-target="report_month">Chọn file…</button>
							<span class="lado-file-name" data-for="report_month"><?php echo $month_url ? esc_html( basename( $month_url ) ) : 'chưa chọn'; ?></span>
						</td></tr>
					</table>

					<h3 style="margin:18px 0 6px">📅 Báo cáo theo tuần (tab "Tỷ lệ giải ngân theo tuần")</h3>
					<p class="description">Mỗi dòng là một tuần: nhãn (vd "Tuần 22"), tỷ lệ giải ngân lũy kế toàn tỉnh (%) để vẽ biểu đồ đường, và file .docx để người dùng tải. Sắp xếp từ tuần cũ → tuần mới.</p>
					<input type="hidden" name="weeks_json" id="weeks_json" value="" />
					<table class="widefat lado-weeks" id="lado-weeks" style="max-width:760px;margin-bottom:8px">
						<thead><tr><th style="width:160px">Nhãn tuần</th><th style="width:110px">Tỷ lệ (%)</th><th>File .docx</th><th style="width:60px"></th></tr></thead>
						<tbody>
						<?php foreach ( (array) $o['weeks'] as $wk ) :
							$wurl = ! empty( $wk['file'] ) ? wp_get_attachment_url( $wk['file'] ) : ''; ?>
							<tr class="wk-row">
								<td><input type="text" class="wk-ky" value="<?php echo esc_attr( $wk['ky'] ); ?>" placeholder="Tuần 22" /></td>
								<td><input type="number" step="0.01" class="wk-tl" value="<?php echo esc_attr( $wk['tl'] ); ?>" /></td>
								<td>
									<input type="hidden" class="wk-file" value="<?php echo esc_attr( $wk['file'] ); ?>" />
									<button type="button" class="button wk-pick"><?php echo $wurl ? esc_html( basename( $wurl ) ) : 'Chọn file…'; ?></button>
								</td>
								<td><button type="button" class="button wk-del">✕</button></td>
							</tr>
						<?php endforeach; ?>
						</tbody>
					</table>
					<button type="button" class="button" id="wk-add">➕ Thêm tuần</button>
				</div>

				<div class="lado-card lado-import">
					<h2>5) Cập nhật số liệu (chỉ cần upload báo cáo .docx)</h2>
					<p class="lado-help" style="margin-top:0">⚡ Quy trình chuẩn: mỗi kỳ chỉ cần tải đúng file báo cáo lên, hệ thống tự đọc và cập nhật. Báo cáo cần đúng mẫu (xem skill "lado-ai-capnhat-du-lieu").</p>

					<table class="form-table">
						<tr><th>📅 Báo cáo THÁNG (.docx)</th><td>
							<input type="file" name="data_docx" accept=".docx" />
							<button type="submit" class="button button-primary">Nhập số liệu biểu đồ</button>
							<p class="description">Cập nhật toàn bộ biểu đồ &amp; bảng: tổng tỉnh, theo nhóm, nguồn vốn 2026/2025, kế hoạch giao, xếp hạng, danh sách 0%, bảng chi tiết 196 đơn vị.</p>
						</td></tr>
						<tr><th>🗓️ Báo cáo TUẦN (.docx)</th><td>
							<input type="file" name="tuan_docx" accept=".docx" />
							<button type="submit" class="button button-primary">Nhập thống kê tuần</button>
							<p class="description">Cập nhật thẻ "Thực hiện kế hoạch giải ngân tuần": đơn vị đăng ký &amp; thực hiện tốt, không đăng ký, đăng ký nhưng 0%.</p>
						</td></tr>
						<tr><th>💡 Kiến nghị, đề xuất (.xlsx)</th><td>
							<?php $knc = lado_ai_get_kiennghi(); ?>
							<input type="file" name="kiennghi_xlsx" accept=".xlsx" />
							<button type="submit" class="button button-primary">Nhập kiến nghị, đề xuất</button>
							<p class="description">Tải file Excel "Danh mục kế hoạch giải ngân theo tuần" — tự tổng hợp toàn bộ kiến nghị, đề xuất theo từng dự án/đơn vị (3 khối) hiển thị trên dashboard.
							<?php if ( ! empty( $knc['total'] ) ) : ?> <strong>Hiện có <?php echo (int) $knc['total']; ?> kiến nghị</strong> (cập nhật <?php echo esc_html( $knc['updated'] ?? '' ); ?>).<?php endif; ?></p>
						</td></tr>
					</table>

					<details style="margin-top:6px">
						<summary style="cursor:pointer;font-weight:600;color:#16407a">Chỉnh số liệu thủ công (JSON nâng cao)</summary>
						<p class="description">Đơn vị: triệu đồng. Giữ đúng cấu trúc JSON.</p>
						<textarea name="data" rows="20" class="large-text code" spellcheck="false"><?php echo esc_textarea( $o['data'] ); ?></textarea>
					</details>
				</div>

				<p><button type="submit" class="button button-primary button-hero">💾 Lưu cấu hình</button></p>
			</form>
		</div>
		<?php
	}
}
