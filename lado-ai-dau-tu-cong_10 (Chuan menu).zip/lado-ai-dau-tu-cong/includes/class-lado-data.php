<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Trích xuất văn bản & bảng từ .docx / .xlsx, và chuyển báo cáo Word -> số liệu biểu đồ.
 */
class LaDo_AI_Data {

	public static function extract( $path ) {
		$ext = strtolower( pathinfo( $path, PATHINFO_EXTENSION ) );
		if ( 'docx' === $ext ) { return self::docx( $path ); }
		if ( 'xlsx' === $ext ) { return self::xlsx( $path ); }
		if ( 'csv' === $ext || 'txt' === $ext ) {
			$c = file_get_contents( $path );
			return $c ? self::clean( $c ) : '';
		}
		return '';
	}

	protected static function docx( $path ) {
		if ( ! class_exists( 'ZipArchive' ) ) { return ''; }
		$zip = new ZipArchive();
		if ( true !== $zip->open( $path ) ) { return ''; }
		$out = '';
		$targets = array( 'word/document.xml' );
		for ( $i = 0; $i < $zip->numFiles; $i++ ) {
			$n = $zip->getNameIndex( $i );
			if ( preg_match( '#^word/(header|footer)\d+\.xml$#', $n ) ) { $targets[] = $n; }
		}
		foreach ( $targets as $t ) {
			$xml = $zip->getFromName( $t );
			if ( ! $xml ) { continue; }
			$xml = preg_replace( '#</w:p>#', "\n", $xml );
			$xml = preg_replace( '#<w:tab[^>]*/>#', "\t", $xml );
			$xml = preg_replace( '#<w:br[^>]*/>#', "\n", $xml );
			$txt = wp_strip_all_tags( $xml );
			$out .= html_entity_decode( $txt, ENT_QUOTES, 'UTF-8' ) . "\n";
		}
		$zip->close();
		return self::clean( $out );
	}

	protected static function xlsx( $path ) {
		if ( ! class_exists( 'ZipArchive' ) ) { return ''; }
		$zip = new ZipArchive();
		if ( true !== $zip->open( $path ) ) { return ''; }
		$shared = array();
		$ss = $zip->getFromName( 'xl/sharedStrings.xml' );
		if ( $ss && preg_match_all( '#<si>(.*?)</si>#s', $ss, $m ) ) {
			foreach ( $m[1] as $si ) {
				$txt = wp_strip_all_tags( $si );
				$shared[] = html_entity_decode( $txt, ENT_QUOTES, 'UTF-8' );
			}
		}
		$out = '';
		for ( $i = 0; $i < $zip->numFiles; $i++ ) {
			$n = $zip->getNameIndex( $i );
			if ( ! preg_match( '#^xl/worksheets/sheet\d+\.xml$#', $n ) ) { continue; }
			$sheet = $zip->getFromName( $n );
			if ( ! $sheet ) { continue; }
			if ( preg_match_all( '#<c[^>]*?(t="([^"]*)")?[^>]*>(.*?)</c>#s', $sheet, $cells, PREG_SET_ORDER ) ) {
				$rowbuf = array();
				foreach ( $cells as $c ) {
					$type = isset( $c[2] ) ? $c[2] : '';
					if ( preg_match( '#<v>(.*?)</v>#s', $c[3], $v ) ) {
						$val = $v[1];
						if ( 's' === $type ) {
							$idx = (int) $val;
							$val = isset( $shared[ $idx ] ) ? $shared[ $idx ] : '';
						} elseif ( preg_match( '#<t[^>]*>(.*?)</t>#s', $c[3], $t ) ) {
							$val = html_entity_decode( wp_strip_all_tags( $t[1] ), ENT_QUOTES, 'UTF-8' );
						}
						if ( '' !== trim( (string) $val ) ) { $rowbuf[] = trim( (string) $val ); }
					}
				}
				if ( $rowbuf ) { $out .= implode( ' | ', $rowbuf ) . "\n"; }
			}
		}
		$zip->close();
		return self::clean( $out );
	}

	protected static function clean( $s ) {
		$s = preg_replace( "/[ \t]+/u", ' ', $s );
		$s = preg_replace( "/\n{2,}/u", "\n", $s );
		return trim( $s );
	}

	/* ---------------- Đọc bảng từ .docx ---------------- */
	public static function docx_tables( $path ) {
		$tables = array();
		if ( ! class_exists( 'ZipArchive' ) ) { return $tables; }
		$zip = new ZipArchive();
		if ( true !== $zip->open( $path ) ) { return $tables; }
		$xml = $zip->getFromName( 'word/document.xml' );
		$zip->close();
		if ( ! $xml ) { return $tables; }
		if ( ! preg_match_all( '#<w:tbl[ >].*?</w:tbl>#s', $xml, $mt ) ) { return $tables; }
		foreach ( $mt[0] as $tbl ) {
			$rows = array();
			if ( preg_match_all( '#<w:tr[ >].*?</w:tr>#s', $tbl, $mtr ) ) {
				foreach ( $mtr[0] as $tr ) {
					$cells = array();
					if ( preg_match_all( '#<w:tc[ >].*?</w:tc>#s', $tr, $mtc ) ) {
						foreach ( $mtc[0] as $tc ) {
							$txt = '';
							if ( preg_match_all( '#<w:t[^>]*>(.*?)</w:t>#s', $tc, $wt ) ) {
								$txt = implode( '', $wt[1] );
							}
							$txt = html_entity_decode( wp_strip_all_tags( $txt ), ENT_QUOTES, 'UTF-8' );
							$cells[] = trim( preg_replace( '/\s+/u', ' ', $txt ) );
						}
					}
					if ( $cells ) { $rows[] = $cells; }
				}
			}
			if ( $rows ) { $tables[] = $rows; }
		}
		return $tables;
	}

	protected static function pnum( $s ) {
		$s = preg_replace( '/[^0-9]/', '', (string) $s );
		return '' === $s ? null : (int) $s;
	}
	protected static function ppct( $s ) {
		if ( false === strpos( (string) $s, '%' ) ) { return null; }
		$s = str_replace( array( '.', ' ', '%' ), array( '', '', '' ), (string) $s );
		$s = str_replace( ',', '.', $s );
		$s = preg_replace( '/[^0-9.\-]/', '', $s );
		return '' === $s ? null : (float) $s;
	}
	protected static function has( $cell, $needle ) { return false !== mb_stripos( $cell, $needle ); }
	protected static function pct_idx( $row ) {
		foreach ( $row as $i => $c ) { if ( false !== strpos( $c, '%' ) ) { return $i; } }
		return -1;
	}

	/* ---------------- Chuyển báo cáo Word -> số liệu biểu đồ ---------------- */
	public static function parse_report( $path ) {
		$tables = self::docx_tables( $path );
		$text   = self::extract( $path );
		if ( empty( $tables ) ) { return null; }
		$out = array();

		// 1) Bảng tổng hợp theo khối (có dòng "TOÀN TỈNH")
		foreach ( $tables as $tb ) {
			$has_toan = false;
			foreach ( $tb as $r ) { if ( isset( $r[0] ) && self::has( $r[0], 'TOÀN TỈNH' ) ) { $has_toan = true; break; } }
			if ( ! $has_toan ) { continue; }
			$khoi = array();
			foreach ( $tb as $r ) {
				if ( count( $r ) < 3 ) { continue; }
				$name = $r[0];
				$pi   = self::pct_idx( $r );
				if ( $pi < 1 ) { continue; }
				$tl = self::ppct( $r[ $pi ] );
				$gn = self::pnum( $r[ $pi - 1 ] );
				$kh = self::pnum( $r[1] );
				$gn26 = ( $pi - 1 >= 3 ) ? self::pnum( $r[2] ) : null;
				$gnkd = ( $pi - 1 >= 3 ) ? self::pnum( $r[3] ) : null;
				if ( self::has( $name, 'TOÀN TỈNH' ) ) {
					$tang = null; $tangpc = null;
					if ( $pi + 1 < count( $r ) ) {
						$parts = preg_split( '#[/]#', $r[ $pi + 1 ] );
						$tang = self::pnum( $parts[0] );
						if ( isset( $parts[1] ) ) { $tangpc = self::ppct( $parts[1] . '%' ); }
					}
					$tong = array( 'kh' => $kh, 'gn' => $gn, 'tl' => $tl );
					if ( null !== $tang ) { $tong['tang'] = $tang; }
					if ( null !== $tangpc ) { $tong['tang_pc'] = $tangpc; }
					$out['tong'] = $tong;
					if ( null !== $gn26 || null !== $gnkd ) {
						$out['nguon'] = array(
							array( 'ten' => 'Vốn năm 2026', 'gn' => $gn26 ),
							array( 'ten' => 'Vốn kéo dài 2025', 'gn' => $gnkd ),
						);
					}
				} elseif ( self::has( $name, 'Ban QLDA' ) || self::has( $name, 'Ban Quản lý' ) ) {
					$khoi[] = array( 'ten' => 'Ban QLDA', 'kh' => $kh, 'gn' => $gn, 'tl' => $tl );
				} elseif ( self::has( $name, 'Sở' ) && self::has( $name, 'ngành' ) ) {
					$khoi[] = array( 'ten' => 'Sở, ngành, đơn vị', 'kh' => $kh, 'gn' => $gn, 'tl' => $tl );
				} elseif ( self::has( $name, 'Xã' ) || self::has( $name, 'phường' ) ) {
					$khoi[] = array( 'ten' => 'Xã, phường, đặc khu', 'kh' => $kh, 'gn' => $gn, 'tl' => $tl );
				}
			}
			if ( $khoi ) { $out['khoi'] = $khoi; }
			break;
		}

		// 2) Bảng kế hoạch giao
		foreach ( $tables as $tb ) {
			$hit = array();
			foreach ( $tb as $r ) {
				if ( ! isset( $r[0] ) ) { continue; }
				$pi = self::pct_idx( $r ); if ( $pi < 1 ) { continue; }
				if ( self::has( $r[0], 'Thủ tướng' ) ) { $hit[] = array( 'ten' => 'Thủ tướng Chính phủ giao', 'kh' => self::pnum( $r[1] ), 'tl' => self::ppct( $r[ $pi ] ) ); }
				elseif ( self::has( $r[0], 'HĐND' ) ) { $hit[] = array( 'ten' => 'HĐND tỉnh giao', 'kh' => self::pnum( $r[1] ), 'tl' => self::ppct( $r[ $pi ] ) ); }
				elseif ( self::has( $r[0], 'UBND' ) ) { $hit[] = array( 'ten' => 'UBND tỉnh phân bổ', 'kh' => self::pnum( $r[1] ), 'tl' => self::ppct( $r[ $pi ] ) ); }
			}
			if ( count( $hit ) >= 2 ) { $out['kehoach_giao'] = $hit; break; }
		}

		// 3) Bảng chi tiết Ban -> all/top/bottom
		$ban_rows = array();
		foreach ( $tables as $tb ) {
			$tmp = array();
			foreach ( $tb as $r ) {
				$ni = -1;
				if ( isset( $r[1] ) && self::has( $r[1], 'Ban QLDA ĐTXD' ) ) { $ni = 1; }
				elseif ( isset( $r[0] ) && self::has( $r[0], 'Ban QLDA ĐTXD' ) ) { $ni = 0; }
				if ( $ni < 0 ) { continue; }
				$pi = self::pct_idx( $r ); if ( $pi < 1 ) { continue; }
				$nm = trim( preg_replace( '/\s+/u', ' ', str_replace( array( 'Ban QLDA ĐTXD', 'khu vực' ), array( '', 'KV' ), $r[ $ni ] ) ) );
				$tmp[] = array(
					'ten' => ( 0 === mb_stripos( $nm, 'KV' ) || 0 === mb_stripos( $nm, 'số' ) ? $nm : 'KV ' . $nm ),
					'kh'  => isset( $r[ $ni + 1 ] ) ? self::pnum( $r[ $ni + 1 ] ) : null,
					'gn'  => self::pnum( $r[ $pi - 1 ] ),
					'tl'  => self::ppct( $r[ $pi ] ),
				);
			}
			if ( count( $tmp ) > count( $ban_rows ) ) { $ban_rows = $tmp; }
		}
		$ban_rows = array_values( array_filter( $ban_rows, function ( $x ) { return null !== $x['tl']; } ) );
		if ( count( $ban_rows ) >= 6 ) {
			usort( $ban_rows, function ( $a, $b ) { return $b['tl'] <=> $a['tl']; } );
			$out['all_ban'] = $ban_rows;
			$out['top_ban'] = array_slice( $ban_rows, 0, 6 );
			$bottom = array_slice( $ban_rows, -5 );
			usort( $bottom, function ( $a, $b ) { return $a['tl'] <=> $b['tl']; } );
			$out['bottom_ban'] = $bottom;
		}

		// 4) Bảng chi tiết Sở -> top_so + 0% (chọn bảng nhiều dòng nhất = bảng đầy đủ 41 đơn vị)
		$best_all = array(); $best_zero = array();
		foreach ( $tables as $tb ) {
			$zero = array(); $all = array(); $ok = false;
			foreach ( $tb as $r ) {
				if ( ! isset( $r[1] ) ) { continue; }
				$pi = self::pct_idx( $r ); if ( $pi < 1 ) { continue; }
				$name = $r[1];
				if ( self::has( $name, 'Chủ đầu tư' ) ) { continue; }
				if ( self::has( $name, 'Chính sách xã hội' ) || self::has( $name, 'Sở ' ) || self::has( $name, 'Ban QLR' ) || self::has( $name, 'Công ty' ) ) { $ok = true; }
				$tl = self::ppct( $r[ $pi ] ); if ( null === $tl ) { continue; }
				$all[] = array( 'ten' => $name, 'gn' => self::pnum( $r[ $pi - 1 ] ), 'tl' => $tl );
				if ( $tl <= 0.0001 ) { $zero[] = $name; }
			}
			if ( $ok && count( $all ) > count( $best_all ) ) { $best_all = $all; $best_zero = $zero; }
		}
		if ( $best_all ) {
			$sorted = $best_all;
			usort( $sorted, function ( $a, $b ) { return $b['tl'] <=> $a['tl']; } );
			$out['all_so'] = $sorted;
			$out['top_so'] = array_slice( $sorted, 0, 5 );
			$out['zero_list_so'] = array_values( $best_zero );
		}

		// 5) Bảng chi tiết Xã -> top_xa + 0% (chọn bảng nhiều dòng nhất = 124 đơn vị)
		$best_all = array(); $best_zero = array();
		foreach ( $tables as $tb ) {
			$zero = array(); $all = array(); $ok = false;
			foreach ( $tb as $r ) {
				if ( ! isset( $r[1] ) ) { continue; }
				$pi = self::pct_idx( $r ); if ( $pi < 1 ) { continue; }
				$name = $r[1];
				if ( self::has( $name, '/ phường' ) || self::has( $name, 'Xã /' ) ) { continue; }
				if ( self::has( $name, 'Xã ' ) || self::has( $name, 'Phường ' ) || self::has( $name, 'Đặc khu' ) ) { $ok = true; } else { continue; }
				$tl = self::ppct( $r[ $pi ] ); if ( null === $tl ) { continue; }
				$all[] = array( 'ten' => $name, 'kh' => ( $pi - 2 >= 0 ? self::pnum( $r[ $pi - 2 ] ) : null ), 'gn' => self::pnum( $r[ $pi - 1 ] ), 'tl' => $tl );
				if ( $tl <= 0.0001 ) { $zero[] = $name; }
			}
			if ( $ok && count( $all ) > count( $best_all ) ) { $best_all = $all; $best_zero = $zero; }
		}
		if ( count( $best_all ) >= 10 ) {
			$sorted = $best_all;
			usort( $sorted, function ( $a, $b ) { return $b['tl'] <=> $a['tl']; } );
			$out['all_xa'] = $sorted;
			$out['top_xa'] = array_slice( $sorted, 0, 5 );
			$out['zero_list_xa'] = array_values( $best_zero );
		}

		$zso = isset( $out['zero_list_so'] ) ? count( $out['zero_list_so'] ) : 0;
		$zxa = isset( $out['zero_list_xa'] ) ? count( $out['zero_list_xa'] ) : 0;
		if ( $zso || $zxa ) { $out['zero'] = array( 'tong' => $zso + $zxa, 'so' => $zso, 'xa' => $zxa ); }

		if ( preg_match( '#đến ngày\s*([0-9]{1,2}/[0-9]{1,2}/[0-9]{4})#u', $text, $md ) ) { $out['as_of'] = $md[1]; }
		$out['tinh'] = 'Lâm Đồng';
		$out['unit'] = 'triệu đồng';

		if ( isset( $out['nguon'][1] ) ) {
			$kd = null;
			if ( preg_match( '#kéo dài[^%]{0,120}?([0-9][0-9\.]{6,})\s*(?:triệu đồng\s*)?(?:trên|/)\s*([0-9][0-9\.]{6,})#u', $text, $mm ) ) {
				$kd = self::pnum( $mm[2] );
			}
			if ( $kd && $kd > 0 ) {
				$out['nguon'][1]['kh'] = $kd;
				if ( ! empty( $out['nguon'][1]['gn'] ) ) {
					$out['nguon'][1]['tl'] = round( $out['nguon'][1]['gn'] / $kd * 100, 2 );
				}
				if ( isset( $out['tong']['kh'] ) ) {
					$kh26 = $out['tong']['kh'] - $kd;
					if ( $kh26 > 0 ) {
						$out['nguon'][0]['kh'] = $kh26;
						if ( ! empty( $out['nguon'][0]['gn'] ) ) {
							$out['nguon'][0]['tl'] = round( $out['nguon'][0]['gn'] / $kh26 * 100, 2 );
						}
					}
				}
			}
		}
		return $out;
	}

	/* ---------------- Thống kê kế hoạch tuần từ báo cáo tuần ---------------- */
	public static function parse_weekly( $path ) {
		$tables = self::docx_tables( $path );
		$text   = self::extract( $path );
		if ( empty( $tables ) ) { return null; }

		$tot = array(); $phan = array(); $khong = array(); $dk0 = array();
		foreach ( $tables as $tb ) {
			if ( empty( $tb ) ) { continue; }
			$head = $tb[0];
			if ( false === mb_stripos( implode( ' | ', $head ), 'KH tuần' ) ) { continue; }
			$ni = 0;
			foreach ( $head as $i => $h ) {
				if ( self::has( $h, 'Chủ đầu tư' ) || self::has( $h, 'Xã' ) || self::has( $h, 'phường' ) || self::has( $h, 'đơn vị' ) ) { $ni = $i; break; }
			}
			$ki = -1; $ti = -1;
			foreach ( $head as $i => $h ) {
				if ( $ki < 0 && self::has( $h, 'KH tuần' ) ) { $ki = $i; }
				elseif ( $ti < 0 && self::has( $h, 'TH tuần' ) ) { $ti = $i; }
			}
			if ( $ki < 0 ) { continue; }
			foreach ( array_slice( $tb, 1 ) as $r ) {
				if ( ! isset( $r[ $ni ] ) || '' === trim( $r[ $ni ] ) ) { continue; }
				if ( self::has( $r[ $ni ], 'TOÀN TỈNH' ) || self::has( $r[ $ni ], 'Khối ' ) ) { continue; }
				$name = $r[ $ni ];
				$kh   = isset( $r[ $ki ] ) ? self::pnum( $r[ $ki ] ) : null;
				$th   = ( $ti >= 0 && isset( $r[ $ti ] ) ) ? self::pnum( $r[ $ti ] ) : null;
				$pc   = self::ppct( end( $r ) );
				if ( null === $kh ) { continue; }
				if ( 0 === $kh ) { $khong[] = $name; }
				elseif ( ( null !== $th && 0 === $th ) || ( null !== $pc && $pc <= 0.0001 ) ) { $dk0[] = $name; }
				elseif ( null !== $pc && $pc >= 80 ) { $tot[] = $name; }
				else { $phan[] = $name; }
			}
		}
		$u = function ( $a ) { return array_values( array_unique( $a ) ); };
		$ky = '';
		if ( preg_match( '#Tuần\s*([0-9]+)#u', $text, $m ) ) { $ky = 'Tuần ' . $m[1]; }
		$mk = function ( $a ) use ( $u ) { $a = $u( $a ); return array( 'count' => count( $a ), 'list' => $a ); };
		return array(
			'ky'       => $ky,
			'tot'      => $mk( $tot ),
			'phan'     => $mk( $phan ),
			'khong_dk' => $mk( $khong ),
			'dk_0'     => $mk( $dk0 ),
		);
	}
}
